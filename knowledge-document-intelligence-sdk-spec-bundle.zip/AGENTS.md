# Coding Assistant Instructions — Enterprise Document Intelligence SDK

This repository implements the reusable Python Document Intelligence SDK described in [`knowledge-document-intelligence-sdk-spec.md`](knowledge-document-intelligence-sdk-spec.md). **Read the complete specification before changing code.** If this file is placed in an existing Knowledge Manager repository, also read the existing root README, AGENTS instructions and ADRs and preserve local conventions.

## Goal

Build one independent, versioned SDK (`knowledge_docs`) that extracts structured documents and provenance, applies adaptive parsing and hybrid chunking, and emits canonical reusable knowledge artifacts. Knowledge Manager integration, PostgreSQL/pgvector, Elasticsearch, FalkorDB, GCS, hosted REST and cloud execution are **optional adapters**. The SDK core must work without any of them.

## Start here

1. Inspect the existing repository and report anything that can be reused. Do not overwrite existing implementations without understanding them.
2. Read specification sections 1–6, 13, 14 and 20–21 before any implementation.
3. Implement **M0 only**, then run all M0 tests. Do not jump directly to full enterprise ingestion.
4. After M0 passes, implement M1 → M2 → M3 → M4 → M5 → M6 in order, with separately testable deliverables.
5. At every milestone, produce a concise implementation report with files changed, architecture decisions, test commands/results, performance measurements, and outstanding issues.

## Hard constraints

- Python 3.11+; explicit Pydantic/JSON schema contracts; public sync and async SDK methods.
- Stable source/document/chunk IDs, 1-based normalized page numbers, PDF-point coordinates, document version hashes, block and region evidence.
- All non-synthetic chunks map to source evidence; do not hallucinate text, numeric values, table units, citations, or relationships.
- Adaptive parser selection must be observable and benchmarkable; never run OCR/visual models across all pages without demonstrated need.
- Hybrid chunking must be heading-, table-, exception- and provenance-aware. Do not use fixed token splitting as the production default.
- Tenant/workspace/source policy metadata must not be inferred from untrusted PDF content. Policy evaluation and publication are owned by the host.
- Published Knowledge Product entitlements are separate from workspace membership; preserve source ACL and Knowledge Product RBAC/ABAC throughout retrieval, graph expansion and evidence fetch.
- Maintain existing Postgres+pgvector / Elasticsearch / FalkorDB stack. No Qdrant/Chroma or additional databases.
- Source artifacts are immutable; search and graph projections are versioned and release-manifest pinned, with old release safe on projection failure.
- Keep LLM, OCR, embedding, storage, API and telemetry integrations outside the core dependency path.
- No unapproved network egress or cloud model processing; licensing and model weights require explicit review.
- No unbounded memory, concurrency, retries, parse duration or model calls.
- Implement explicit partial/failure states, cancellation, retries, backpressure and safe errors.
- Use tests and measured benchmark results rather than claims about accuracy or latency.

## Initial M0 implementation tasks

- Create `pyproject.toml`, `src/knowledge_docs/`, `tests/`, and `examples/`.
- Implement `SourceDescriptor`, `ProcessingContext`, `DocumentArtifact`, `Page`, `ContentBlock`, `EvidenceRegion`, `TableArtifact`, `Chunk`, `ChunkSet`, `QualityReport`, and typed errors.
- Implement `ParserPlugin`, `ChunkerPlugin`, registry and fake parser for offline CI.
- Implement stable hashing, JSON schema validation, provenance invariants and source policy metadata propagation.
- Implement basic `DocumentClient` sync/async facade and deterministic parent-aware chunker.
- Implement CLI inspect/parse/chunk/validate with machine-readable output.
- Include one real approved parser adapter behind optional install extra, not imported at SDK startup.
- Run lint, typecheck, unit and golden tests; note every skipped test and why.

## Performance discipline

Instrument each stage (preflight, router, parser, normalization, chunking, embedding, projection). Measure queue wait separately from compute. Establish reference hardware/dataset before calling a latency number an SLO. Report p50/p95/p99, throughput/pages per second, memory peak, failure/partial rate and business retrieval correctness. Optimize total time-to-trusted-knowledge, not only time-to-Markdown.

## Definition of done for every change

Implementation + tests + schema/contract updates + docs + relevant security checks + latency impact note. Keep `specs/openapi.yaml` synchronized with the service where applicable. Record material departures from the specification in ADRs. If an external dependency/model isn't available, use a tested fake/adapter boundary and report the limitation; **do not claim tests passed if they were not run**.

## First response to user after M0

Provide a short report containing:

- Implemented modules and public APIs
- Updated files
- Commands executed and actual results
- Golden examples and output
- Performance baseline / limitations
- ADRs or proposed deviations
- Next milestone plan (M1)
