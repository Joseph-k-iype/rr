# Enterprise Document Intelligence SDK — Engineering Specification

**Document ID:** KM-DOCSDK-001  
**Status:** Implementation-ready design proposal; defaults and performance targets require benchmark validation  
**Version:** 1.0.0-draft  
**Date:** 2026-11-19  
**Audience:** Coding assistants, platform engineers, ML/IR engineers, security engineers, SREs, Knowledge Product owners  
**Primary runtime:** Python 3.11+; FastAPI service adapter; Kubernetes on GCP  
**Existing data stack:** PostgreSQL + pgvector, Elasticsearch, FalkorDB, object storage (GCS)  
**Scope:** Reusable standalone SDK plus optional worker, REST service, and Knowledge Manager integration adapters

> **The contract:** Create a reusable, storage-agnostic SDK that turns documents into structured, evidence-linked, policy-carrying, quality-assessed knowledge artifacts. The SDK itself must not require Elasticsearch, PostgreSQL, FalkorDB, cloud credentials, LangChain, or an LLM. All external integrations are optional adapters. Document content must never silently lose evidence, provenance, or inherited security classification.

---

## Contents

1. [Executive decisions and success criteria](#1-executive-decisions-and-success-criteria)
2. [System boundaries and architecture](#2-system-boundaries-and-architecture)
3. [Requirements and non-goals](#3-requirements-and-non-goals)
4. [Repository and package structure](#4-repository-and-package-structure)
5. [Public SDK contract](#5-public-sdk-contract)
6. [Canonical document model](#6-canonical-document-model)
7. [Preflight, adaptive routing, and parsing](#7-preflight-adaptive-routing-and-parsing)
8. [Hybrid chunking engine](#8-hybrid-chunking-engine)
9. [Knowledge enrichment and typed extraction](#9-knowledge-enrichment-and-typed-extraction)
10. [Storage adapters and publication integration](#10-storage-adapters-and-publication-integration)
11. [Hybrid and graph-aware retrieval](#11-hybrid-and-graph-aware-retrieval)
12. [Workflows, jobs, and state machines](#12-workflows-jobs-and-state-machines)
13. [Security, multi-tenancy, and governance](#13-security-multi-tenancy-and-governance)
14. [Latency, throughput, and capacity engineering](#14-latency-throughput-and-capacity-engineering)
15. [Deployment and operations](#15-deployment-and-operations)
16. [Observability, quality, and evaluation](#16-observability-quality-and-evaluation)
17. [Error taxonomy and resilience](#17-error-taxonomy-and-resilience)
18. [Configuration and feature flags](#18-configuration-and-feature-flags)
19. [API and event contracts](#19-api-and-event-contracts)
20. [Implementation milestones and acceptance tests](#20-implementation-milestones-and-acceptance-tests)
21. [Coding-assistant execution instructions](#21-coding-assistant-execution-instructions)
22. [Risks, ADRs, and unresolved choices](#22-risks-adrs-and-unresolved-choices)
23. [Authoritative references](#23-authoritative-references)

---

## 1. Executive decisions and success criteria

### 1.1 Non-negotiable architecture decisions

| ID | Decision | Consequence |
|---|---|---|
| D-01 | SDK core is **pure Python and storage-agnostic** | Parsing and chunking work offline with zero cloud/database dependencies. |
| D-02 | **Canonical intermediate representation (CIR)** is mandatory | Parser implementations are replaceable without changing downstream consumers. |
| D-03 | Preserve **page- and region-level provenance** | Every chunk/claim links to evidence in a versioned source file. |
| D-04 | **Adaptive routing**, not a one-parser mandate | Fast extraction is attempted where eligible; OCR/ML/layout fallback is conditional. |
| D-05 | **Structure-aware chunking** precedes semantic splitting | Never let token budgets destroy clause, exception, table, or heading context without explicit overlap/parent references. |
| D-06 | Parsing, semantic enrichment, embeddings, and indexing are **independent stages** | Expensive/retryable work is isolated, cacheable, and observable. |
| D-07 | Existing PostgreSQL/pgvector, Elasticsearch, and FalkorDB are supported via optional adapters | No new database is required. |
| D-08 | Publish only **complete, validated index generations** | Avoid mixed-version retrieval during partial indexing. |
| D-09 | Default **fail-closed authorization** | Workspace access never implies Knowledge Product consumption permission. |
| D-10 | Treat latency and cost as **first-class functional outcomes** | Every pipeline stage has deadlines, instrumentation, and a fallback policy. |
| D-11 | No irreversible model extraction without **evidence and review state** | Business rules and relationships are assertions/candidates until verified. |
| D-12 | SDK is **sync + async**, batch-capable, cancellable, versioned | Other applications can use it as a library, local CLI, worker, or API service. |

### 1.2 Product positioning

The SDK is a **Document Intelligence Foundation** used by Knowledge Manager and unrelated projects. It outputs structured documents, chunks, evidence, optional candidate business entities/relations, and quality reports. The **Knowledge Manager platform** remains responsible for workspace/domain ownership, approval workflows, ontology management, authorization, Knowledge Product publication, release promotion, retrieval and inference orchestration. Never embed Knowledge Manager-specific business state into SDK internals; pass it as typed context or implement it in adapters.

**Primary outputs:** `DocumentArtifact`, `ChunkSet`, `EvidenceBundle`, `ParseQualityReport`, optionally `CandidateAssertionSet`. The source PDF and binary derivatives live in an artifact store owned by the host application, not implicitly within the SDK.

### 1.3 Definition of success

1. A standalone project can `pip install` the core SDK, parse a local PDF, chunk it, and export JSON/Markdown with no enterprise infrastructure.
2. Knowledge Manager can invoke the same core SDK via an async worker, attach workspace/release security context, and project artifacts into existing stores.
3. Clear scanned, text-heavy, multi-column, financial-table, and mixed PDFs are automatically routed to appropriate parsers, with bounded fallback.
4. Pipeline is deterministic for pinned engine/model/config versions; stable IDs permit incremental reprocessing.
5. Document-level and page-level provenance survives normalization, chunking, graph extraction, and retrieval.
6. SLO dashboards explain ingestion latency **by stage, document class, tenant, and parser**, without leaking sensitive content.
7. A review and benchmark suite demonstrates measurable improvements against the existing PyPDF/fixed-token baseline.
8. Authorization, tenant isolation, deletion/retention, and index-generation consistency are proven by automated tests.

### 1.4 Example consumer applications

- Knowledge Manager document/Knowledge Product builder and retrieval layer.
- Contract analysis, compliance policy extraction, annual report search, operational resilience intelligence.
- Standalone RAG ingestion, notebook workflows, batch ETL, document QA services.
- Enterprise document review, search, extraction, reporting, and agent-tool integrations.

---

## 2. System boundaries and architecture

### 2.1 Logical boundaries

**Core SDK** owns formats, document profiling, parsing abstractions, layout normalization, chunk generation, evidence, quality checks, pure-Python exports, and plugin interfaces. **Optional extensions** own heavy parsers/OCR, embedding providers, enrichment, storage adapters, telemetry, and service transport. **Host platform** owns auth, workspace/domain lifecycle, source connector permissions, tenancy, approval decisions, ontology/semantic registry, catalog, publication, and serving.

```mermaid
flowchart LR
  subgraph Consumers["Consumers"]
    KM["Knowledge Manager"]
    APP["Other Python Services"]
    CLI["CLI / Batch Jobs"]
    NOTE["Notebooks"]
  end
  subgraph SDK["knowledge-docs SDK (reusable package)"]
    ENTRY["Public API / Pipeline"]
    PROFILE["Preflight / Router"]
    PARSE["Parser Plugins"]
    CIR["Canonical Document Model"]
    CHUNK["Adaptive Hybrid Chunker"]
    QUALITY["Evidence + Quality"]
    ENTRY --> PROFILE --> PARSE --> CIR --> CHUNK --> QUALITY
  end
  subgraph Optional["Optional integrations (separate extras/packages)"]
    OCR["OCR / Visual Models"]
    ENRICH["Entity + Rule Enrichment"]
    EMBED["Embeddings / Reranking"]
    ADAPT["Storage / Events / Observability"]
  end
  KM --> ENTRY
  APP --> ENTRY
  CLI --> ENTRY
  NOTE --> ENTRY
  PARSE -.-> OCR
  CHUNK -.-> ENRICH
  QUALITY -.-> ADAPT
  CHUNK -.-> EMBED
```

### 2.2 End-to-end Knowledge Manager integration

```mermaid
flowchart TB
  SRC["PDF / DOCX / Connector Source"] --> INTAKE["Knowledge Manager Intake API"]
  INTAKE --> AUTH["Workspace + Source Policy Validation"]
  AUTH --> OBJ["GCS: immutable source bytes"]
  AUTH --> JOB["PostgreSQL: ingest job + outbox"]
  JOB --> QUEUE["Pub/Sub / Queue / Workflow Engine"]
  QUEUE --> W["Document Intelligence Worker"]
  OBJ --> W
  subgraph SDK["Reusable Document Intelligence SDK"]
    PRE["Preflight + Adaptive Router"] --> PAR["Parsers / OCR Fallback"]
    PAR --> NOR["CIR + Evidence Normalization"]
    NOR --> CH["Structure/Semantic/Table/Rule Chunking"]
    CH --> QA["Validation + Quality Report"]
  end
  W --> PRE
  QA --> ART["GCS: versioned artifacts"]
  QA --> META["PostgreSQL: metadata/chunks/embeddings"]
  META --> OUT["Transactional outbox / projection workers"]
  OUT --> ES["Elasticsearch: lexical search"]
  OUT --> FG["FalkorDB: verified/candidate graph"]
  ES --> GATE["Index-generation quality gate"]
  FG --> GATE
  META --> GATE
  GATE --> PUB["Knowledge Manager: versioned release manifest"]
  PUB --> CTX["Authorized Context / Inference API"]
```

### 2.3 Knowledge Manager boundary principles

- **Workspace = private authoring and isolation boundary**; domain/subdomain = governance boundary; published product = separately authorized immutable release.
- A product can contain parsed evidence, structured assertions, graph projections, and vector/lexical retrieval artifacts. Consumer entitlement is independent of workspace membership.
- Knowledge Product owners, domain owners, and approved builders can author RBAC/ABAC policy subject to the platform's validation/approval model. The SDK **carries** policy references and labels; it never grants access.
- Product release manifests pin source document version, CIR schema version, parser+model versions, chunker configuration, embedding model, index generations, ontology/policy versions and quality approvals.
- Previously discussed GCP deployment, Kubernetes, DataHub, Trino, and GCS can be integrated through adapters but **must not be imported by the SDK core**.

### 2.4 Dataflow sequence: synchronous SDK versus hosted job

```mermaid
sequenceDiagram
  autonumber
  participant Client as Consumer
  participant API as Ingest API
  participant DB as PostgreSQL
  participant Obj as GCS
  participant Queue as Queue
  participant Worker as SDK Worker
  participant Stores as ES / FalkorDB
  Client->>API: Submit source + workspace + idempotency key
  API->>API: Authenticate, authorize, validate source
  API->>Obj: Store immutable source bytes
  API->>DB: Create job + transactional outbox
  API-->>Client: 202 Accepted, job_id
  DB-->>Queue: Publish outbox event
  Queue->>Worker: Process job (at least once)
  Worker->>Obj: Download source and verify content hash
  Worker->>Worker: Profile, route, parse, normalize, chunk, QA
  Worker->>DB: Upsert artifacts + new outbox events
  DB-->>Queue: Project(index_generation) events
  Queue->>Stores: Idempotent projections
  Stores-->>API: Generation readiness status
  API->>DB: Gate approvals then activate release pointer
  Client->>API: Request status/results with own auth
  API-->>Client: Manifest + evidence references
```

**Synchronous API** is restricted to small bounded documents, internal testing, and low-latency eligible workloads. Long/large/complex ingestion returns a job handle; no HTTP request should wait indefinitely for OCR/model processing.

---

## 3. Requirements and non-goals

### 3.1 Functional requirements

| ID | Requirement | Priority | Acceptance evidence |
|---|---|---|---|
| F-01 | Accept file paths, bytes, seekable streams, and artifact references | P0 | Unit and integration tests |
| F-02 | Support PDF first; DOCX/HTML/text later via format plugins | P0/P1 | Capability matrix |
| F-03 | Extract native text, headings, reading order, tables, lists, footnotes, images, captions, page coordinates | P0 core/P1 advanced | Golden fixtures |
| F-04 | Detect scanned and mixed-content pages; selective OCR fallback | P0 | Mixed-page tests |
| F-05 | Parser registry, capability discovery, explicit engine selection and automatic routing | P0 | Plugin contract tests |
| F-06 | Canonical schema with source/page/block/region provenance and versioning | P0 | Schema conformance tests |
| F-07 | Hierarchical, token-aware, parent-child, table-aware chunking | P0 | Chunk invariants |
| F-08 | Semantic, contextual, rule-aware, multimodal and late chunking as configurable plugins | P1/P2 | Retrieval benchmarks |
| F-09 | Streaming page results, cancellation and bounded memory | P1 | Integration stress tests |
| F-10 | Per-document/per-page quality reports and escalation decisions | P0 | Evaluations |
| F-11 | Async batch processing with idempotency, retries and DLQ | P0 hosted | Chaos tests |
| F-12 | Optional adapters for Postgres, pgvector, Elasticsearch, FalkorDB | P0 hosted | Contract tests |
| F-13 | Evidence-preserving indexing and retrieval contract | P0 hosted | End-to-end citations |
| F-14 | Document version diffs and incremental reindexing | P1 | Differential tests |
| F-15 | No external data transmission unless explicitly enabled | P0 | Network isolation tests |

### 3.2 Non-functional requirements

- **Determinism:** identical source bytes, pinned implementation/model versions, and config produce equivalent CIR/chunk identities; nondeterministic enrichment is explicitly marked.
- **Reliability:** partial extraction must be visible as partial, never as success. System can replay jobs without duplicate active records.
- **Scale:** independent worker pools for lightweight text extraction and GPU/OCR-heavy processing; per-tenant fairness.
- **Interoperability:** stable JSON schema, explicit schema migrations, typed errors, semver Python SDK and OpenAPI for hosted adapter.
- **Operability:** traces, per-stage timings, routing audit, parser fallback count, OCR demand, QA metrics, cost attribution.
- **Privacy:** source bytes and text never appear in default logs, trace attributes, event payloads, or metrics labels.
- **Safety:** document input treated as untrusted; malware checks, zip/decompression limits, resource isolation, and prompt-injection resistance.
- **Quality:** benchmarking includes actual search/evidence utility, not solely parser-generated Markdown aesthetics.

### 3.3 Non-goals for SDK v1

- Owning Knowledge Manager workspaces, domain permissions, user accounts, catalog, approval decisions, or release policy authoring.
- Replacing the enterprise semantic registry, ontology editor, rule engine or inference service.
- Building a proprietary LLM or OCR model from scratch.
- Introducing a fourth search/vector database.
- Guaranteeing exact table extraction on every PDF; report ambiguity and require review.
- Guaranteeing fixed latency on scanned/complex documents regardless of hardware or file size.
- Running unsupported arbitrary code or HTTP requests embedded in source documents.

---

## 4. Repository and package structure

### 4.1 Proposed monorepo

```text
knowledge-document-intelligence/
├── README.md
├── AGENTS.md
├── pyproject.toml
├── uv.lock                         # or equivalent reproducible lock
├── LICENSE                         # internal/company choice; audit dependency licenses
├── CHANGELOG.md
├── docs/
│   ├── architecture.md
│   ├── schema-contracts.md
│   ├── parser-benchmark.md
│   ├── security-threat-model.md
│   ├── latency-and-slos.md
│   ├── plugin-development.md
│   └── decisions/                  # ADR-0001 onward
├── specs/
│   ├── openapi.yaml
│   ├── schemas/
│   │   ├── document-artifact.v1.schema.json
│   │   ├── chunk.v1.schema.json
│   │   ├── quality-report.v1.schema.json
│   │   └── events.v1.schema.json
│   └── example-artifacts/
├── src/knowledge_docs/
│   ├── __init__.py                 # minimal stable public API
│   ├── api.py                      # sync and async facade
│   ├── config.py                   # validated config
│   ├── contracts/
│   │   ├── source.py
│   │   ├── document.py
│   │   ├── evidence.py
│   │   ├── chunk.py
│   │   ├── quality.py
│   │   ├── events.py
│   │   └── errors.py
│   ├── preflight/
│   │   ├── sniff.py
│   │   ├── profile.py
│   │   ├── safety.py
│   │   └── scoring.py
│   ├── routing/
│   │   ├── registry.py
│   │   ├── policy.py
│   │   └── fallback.py
│   ├── parsers/
│   │   ├── base.py
│   │   ├── pypdf_fallback.py       # optional reference/fallback only
│   │   └── adapters/               # no heavy imports in top-level __init__
│   │       ├── docling.py
│   │       ├── pymupdf.py
│   │       ├── marker.py
│   │       └── mineru.py
│   ├── normalize/
│   │   ├── pages.py
│   │   ├── blocks.py
│   │   ├── tables.py
│   │   ├── coordinates.py
│   │   └── identities.py
│   ├── chunkers/
│   │   ├── base.py
│   │   ├── hierarchy.py
│   │   ├── parent_child.py
│   │   ├── semantic.py
│   │   ├── tables.py
│   │   ├── business_rules.py
│   │   └── hybrid.py
│   ├── evaluation/
│   │   ├── extraction.py
│   │   ├── structure.py
│   │   ├── provenance.py
│   │   └── quality_gate.py
│   ├── export/
│   │   ├── json.py
│   │   ├── markdown.py
│   │   └── parquet.py
│   └── plugins.py
├── extensions/
│   ├── knowledge-docs-ocr/
│   ├── knowledge-docs-embeddings/
│   ├── knowledge-docs-enrichment/
│   ├── knowledge-docs-postgres/
│   ├── knowledge-docs-elasticsearch/
│   ├── knowledge-docs-falkordb/
│   ├── knowledge-docs-gcs/
│   └── knowledge-docs-otel/
├── services/
│   ├── api/                        # FastAPI wrapper only
│   ├── worker/                     # job execution
│   └── projector/                  # index generation workers
├── deploy/
│   ├── helm/
│   ├── k8s/
│   └── dashboards/
├── examples/
│   ├── 01_local_pdf.py
│   ├── 02_batch_async.py
│   ├── 03_custom_parser.py
│   ├── 04_custom_chunking.py
│   ├── 05_postgres_elastic_falkor.py
│   └── 06_knowledge_manager_host.py
├── benchmarks/
│   ├── fixtures_manifest.yaml
│   ├── run_parser_matrix.py
│   ├── run_chunker_matrix.py
│   └── reports/
└── tests/
    ├── unit/
    ├── property/
    ├── contract/
    ├── integration/
    ├── security/
    ├── performance/
    ├── golden/
    └── chaos/
```

### 4.2 Distribution strategy

- Publish internal wheel `knowledge-docs` for core; optional extras are `knowledge-docs[docling]`, `[pymupdf]`, `[ocr]`, `[all-local]`, `[api]`, or separate adapter distributions when dependency isolation is material.
- **License gates:** PyMuPDF AGPL/commercial considerations, Marker model-weight licensing, and MinerU licensing must be reviewed before enabling inside enterprise deployments. Core must function with a legal/approved parser choice.
- Plugins advertise capabilities and model footprint; installing the core must not download multi-GB model weights.
- Support **semver** with deprecation warnings, a migration guide, JSON schema versioning and compatibility tests.
- Pin parser model weights by digest/version and maintain an SBOM; never trust `latest` for production.

---

## 5. Public SDK contract

### 5.1 Required developer experience

```python
from knowledge_docs import DocumentClient, ParseOptions, ChunkOptions

client = DocumentClient.from_config("knowledge_docs.yaml")
result = client.process(
    "./policy.pdf",
    parse=ParseOptions(strategy="auto"),
    chunk=ChunkOptions(strategy="hybrid", target_tokens=450),
)

print(result.document.document_id)
for chunk in result.chunks:
    print(chunk.chunk_id, chunk.text, chunk.evidence_refs)
```

**Asynchronous example** (host supplies tenant context; SDK does not authenticate users):

```python
async with DocumentClient.from_config("knowledge_docs.yaml") as client:
    result = await client.aprocess(
        source,
        context=ProcessingContext(
            tenant_id="org-a", workspace_id="risk-ws",
            source_policy_ref="policy-123",
            trace_id="trace-abc",
        ),
        deadline_seconds=30,
    )
```

### 5.2 Public objects and methods

| API | Contract | Notes |
|---|---|---|
| `DocumentClient.process(source, *, parse, chunk, context, deadline_seconds)` | `ProcessingResult` | Bounded sync path |
| `DocumentClient.aprocess(...)` | `ProcessingResult` | Async facade; uses cancellable workers for blocking parsers |
| `DocumentClient.process_batch(iterable, concurrency)` | Results/errors per source | Bounded memory and concurrency |
| `DocumentClient.astream(source, ...)` | Async iterator of `ProcessingEvent` | Partial page output and stage progress, terminal status |
| `DocumentClient.profile(source)` | `DocumentProfile` | Fast and bounded preflight |
| `DocumentClient.parse(source, engine="auto")` | `DocumentArtifact` | No chunking required |
| `DocumentClient.chunk(document, config)` | `ChunkSet` | Run without source reparse |
| `DocumentClient.rechunk(document_id, artifact, config)` | `ChunkSet` | New chunk generation, unchanged source |
| `DocumentClient.inspect_capabilities()` | Engine descriptors | No implicit model load |
| `DocumentClient.export(result, format)` | Bytes or stream | JSON, Markdown (lossy), optional Parquet |
| `ParserRegistry.register(plugin)` | None | Versioned capability interface |
| `ChunkerRegistry.register(plugin)` | None | Custom strategy interface |

SDK implementations must support dependency injection: parser registry, tokenizer, object loader, executor, cache, quality gate, trace provider, clock, and logger. Business-specific integrations must be supplied externally.

### 5.3 Core protocol sketches

```python
from dataclasses import dataclass
from typing import Protocol, BinaryIO, AsyncIterator, Literal

@dataclass(frozen=True)
class ParserCapabilities:
    engine_id: str
    version: str
    formats: frozenset[str]
    native_text: bool
    ocr: bool
    tables: bool
    bounding_boxes: bool
    gpu: bool
    max_pages: int | None = None

class ParserPlugin(Protocol):
    @property
    def capabilities(self) -> ParserCapabilities: ...
    def parse(self, source: BinaryIO, options: "ParseOptions") -> "DocumentArtifact": ...

class ChunkerPlugin(Protocol):
    @property
    def strategy_id(self) -> str: ...
    def chunk(self, document: "DocumentArtifact", options: "ChunkOptions") -> "ChunkSet": ...

class EmbeddingProvider(Protocol):
    async def embed_documents(self, texts: list[str], model: str) -> list[list[float]]: ...
    async def embed_query(self, text: str, model: str) -> list[float]: ...

class ArtifactStore(Protocol):
    async def put(self, key: str, payload: bytes, content_type: str) -> str: ...
    async def get(self, key: str) -> bytes: ...
```

These are **normative interface sketches**, not a full copy-paste implementation. The coding assistant must supply concrete versioned Pydantic models, accurate type hints, test doubles, lifecycle management, proper bounded I/O, and explicit exception types.

### 5.4 API compatibility guarantees

- Public imports only from `knowledge_docs.__init__` / documented modules; internal paths may change.
- New CIR schema fields are additive within major version; breaking semantics or removed required fields require major version bump.
- Unknown future schema fields must round-trip where feasible; unknown enum values must not crash generic export readers.
- Engine-specific metadata under `extensions["engine_id"]`, never in shared canonical fields without a schema review.
- Avoid global mutable registries in shared worker processes; use per-client plugin registries.
- Core must support no-GPU, no-internet, no-cloud local execution.

---

## 6. Canonical document model

### 6.1 Structural hierarchy

```mermaid
classDiagram
  class DocumentArtifact {
    +document_id
    +source_sha256
    +schema_version
    +pages[]
    +blocks[]
    +sections[]
    +tables[]
    +quality
  }
  class Page {
    +page_number
    +width_pt
    +height_pt
    +rotation_degrees
  }
  class ContentBlock {
    +block_id
    +type
    +text
    +reading_order
    +parent_section_id
  }
  class EvidenceRegion {
    +page_number
    +bbox_pt
    +source_engine
  }
  class Chunk {
    +chunk_id
    +kind
    +text
    +section_path[]
    +evidence_refs[]
  }
  class TableArtifact {
    +table_id
    +cells[]
    +header_rows[]
    +units
  }
  DocumentArtifact "1" *-- "1..*" Page
  DocumentArtifact "1" *-- "0..*" ContentBlock
  DocumentArtifact "1" *-- "0..*" TableArtifact
  ContentBlock "1" o-- "1..*" EvidenceRegion
  Chunk "1" --> "1..*" EvidenceRegion
  Chunk "0..*" --> "0..*" ContentBlock
```

### 6.2 Core entities

**`SourceDescriptor`:** source URI or host artifact ID, media type, safe filename, bytes length, SHA-256, timestamp, source system, original ACL/policy reference, tenant/workspace context. Never store credentials in it.

**`DocumentArtifact`:** immutable logical parse result: source fingerprint, parser decisions, schema version, pages, sections, typed blocks, tables, images, evidence, extraction warnings, quality scores, artifact fingerprint and normalizer version.

**`Page`:** 1-based page number, physical dimensions in PDF points (1/72 inch), rotation, text coverage, image coverage, region statistics, OCR treatment, status and warnings.

**`ContentBlock`:** type enum (`heading`, `paragraph`, `list_item`, `table`, `caption`, `footnote`, `header`, `footer`, `figure`, `formula`, `code`, `unknown`), hierarchical parent, reading-order rank, raw/normalized text, language, metadata, source region references.

**`TableArtifact`:** table coordinates, title/caption, column count, row count, logical grid of cells, explicit headers, merged-cell spans, numbers/units, confidence and ambiguity flags; maintain original cell text, not only Markdown.

**`EvidenceRegion`:** source document ID+version, page, bbox, coordinate system, region type, optional text offsets, optional image crop artifact URI, source engine and extracted block IDs.

**`Chunk`:** deterministic ID, chunk generation, text to embed, display text, context prefix, chunk type, parent/child IDs, block refs, evidence refs, section path, estimated tokens, semantic metadata, policy refs, annotations.

**`QualityReport`:** success/partial/failed, severity-rated findings, applied engines and fallbacks, extraction completeness, table sanity, OCR confidence (when available), provenance completeness and human review flags.

### 6.3 Required canonical invariants

1. Coordinates use `PDF_POINTS`, origin **top-left**, page after normalization to displayed orientation. Store the original rotation separately and record transform from engine coordinates when available.
2. `page_number` is **1-based** everywhere in CIR, SDK, and public API. Adapter converts engine-specific 0-based indices.
3. Every non-empty block carries at least one evidence region unless `synthetic=true`; synthetic blocks must explain their source lineage.
4. Every non-synthetic chunk maps back to one or more existing block IDs and evidence refs; chunk text cannot silently include material unsupported by the original source.
5. Sections and block reading-order ranks form an acyclic parent hierarchy; blocks in a page have stable order.
6. Tables preserve rows, columns, merged spans, heading association and units where present; ambiguity reported rather than guessed.
7. Any model-inferred field is tagged `origin="model_inferred"` and must never override a source-extracted fact without explicit reconciliation.
8. Identifiers are immutable within a fixed source+config+schema generation. Use deterministic hashes of canonicalized inputs, not only sequential integers.
9. Save source SHA-256 and a content-addressed source artifact reference. Never use filenames as document identifiers.
10. Security labels and source policy references propagate from source → document → block → chunk → assertion; reduction of restrictions requires explicit authorized host action.
11. Each artifact includes `created_at`, `schema_version`, `engine_provenance`, `normalizer_version`, `config_digest`, and `content_digest`.
12. Unknown/partial parse states remain explicit and cannot satisfy publication quality gates by default.

### 6.4 Example JSON contract (illustrative, abridged)

```json
{
  "schema_version": "1.0",
  "document_id": "doc_4e18",
  "source": {
    "uri": "gcs://bucket/tenant-a/sources/sha256-...pdf",
    "sha256": "f7...",
    "media_type": "application/pdf",
    "tenant_id": "tenant-a",
    "workspace_id": "risk-workspace",
    "policy_ref": "src-policy-112"
  },
  "processing": {
    "parser": "docling",
    "parser_version": "<pinned>",
    "config_digest": "sha256:...",
    "status": "succeeded",
    "warnings": []
  },
  "pages": [
    { "page_number": 12, "width_pt": 612, "height_pt": 792, "rotation_degrees": 0 }
  ],
  "blocks": [
    {
      "block_id": "block_21",
      "type": "paragraph",
      "parent_section_id": "sec_4_2",
      "reading_order": 31,
      "text": "Critical providers must notify within 24 hours...",
      "evidence_refs": ["ev_21"]
    }
  ],
  "evidence": [
    {
      "evidence_id": "ev_21",
      "page_number": 12,
      "bbox_pt": [70, 190, 540, 247],
      "coordinate_system": "PDF_POINTS_TOP_LEFT"
    }
  ],
  "quality": { "status": "accepted", "provenance_coverage": 1.0 }
}
```

### 6.5 Stable ID and hashing design

- `source_version_id = SHA256(source_bytes)`.
- `parse_generation_id = SHA256(source_version_id || engine_id/version || model_digests || parse_config_digest || CIR_schema_major)`.
- `block_id = SHA256(parse_generation_id || normalized_page || block_path || canonical_block_content || stable_region_key)`.
- `chunk_generation_id = SHA256(parse_generation_id || chunker_id/version || tokenizer_id/version || chunk_config_digest)`.
- `chunk_id = SHA256(chunk_generation_id || ordered_block_refs || normalized_segment_span || segment_content_digest)`.
- `embedding_generation_id = SHA256(chunk_generation_id || embedding_model_id || model_revision || normalization_config)`.

Avoid using floats directly in hashes without canonical rounding rules. Normalize Unicode (`NFC` by default), whitespace only where safe, and serialize JSON with canonical ordering. Distinguish *identity for changed content* from *semantic matching across versions*: cross-version alignment is a separate diff service.

## 7. Preflight, adaptive routing, and parsing

### 7.1 Parser candidates and selection policy

The SDK supports an explicit registry with **Docling**, **PyMuPDF4LLM**, and optional **Marker**, **MinerU**, or managed OCR/layout adapters. This is a candidate roster, not a promise that all engines will be enabled in an enterprise build. The selected engine must have approved licensing, hardware footprint, privacy controls, and pinned tested versions.

| Engine | Role | Advantages | Risks / trade-offs |
|---|---|---|---|
| PyMuPDF4LLM | Fast, native-text PDF path | CPU-efficient, page-oriented, basic table/layout extraction | Licensing decision, layout ambiguity for difficult PDFs |
| Docling | Default structured-document path | Document hierarchy, provenance and built-in HybridChunker | Model loading and complex-page latency |
| Marker | Optional high-fidelity fallback | Visual/complex PDF handling | Model weights license, memory/GPU needs |
| MinerU | Optional complex-format fallback | OCR/layout and structured result formats | Version-specific APIs, model resources/license audit |
| Managed Document AI | Explicitly approved managed fallback | Scalable cloud OCR and layout | Network/data residency, pricing, service dependence |

**Policy:** never invoke a paid or external model merely because a local model is uncertain. The host must opt in to external processing by configuration and data-classification policy; unapproved sensitive documents must remain within the permitted environment.

### 7.2 Bounded preflight profile

Profile the document without fully parsing it. Recommended fields:

```text
DocumentProfile
  ├── metadata: sha256, byte_size, media_type, extension_match
  ├── pdf: page_count, encrypted, pdf_version, linearized, attachments
  ├── native_text: sample_coverage, glyph_density, replacement_char_rate
  ├── layout: columns_estimate, text_block_overlap, rotation_distribution
  ├── visuals: image_coverage, figure_density, vector_graphics_estimate
  ├── tables: sampled_table_density, ruled/borderless_table_likelihood
  ├── scripts: language_hints, unsupported_script_flags
  ├── safety: quarantine_status, input_limit_violations
  ├── business: requested_accuracy_tier, expected_document_type
  └── scores: native_text_suitability, complexity, ocr_need, table_risk
```

Sampling must be **deterministic** (e.g. first, last, middle, plus uniformly spaced pages) with configurable limits, rather than only the first page. For short PDFs, sample all pages. Preflight should not render full-resolution images unless necessary. Calculate image coverage, extracted text coverage, rough columns and table flags from low-cost primitives. Dynamic selection may use uncertainty estimates calibrated on the benchmark set.

**Hard limit examples** (initial, configurable—not universal): 200 MB source, 2,000 pages/document in hosted default, 15 seconds preflight ceiling, OCR render pixel bounds, 512 MB uncompressed object limit. Enterprise tenants can have lower/higher quotas; preflight rejects or schedules special processing before resource exhaustion.

### 7.3 Adaptive routing decision tree

```mermaid
flowchart TD
  A["Ingest + safety checks"] --> B["Sample pages + profile"]
  B --> C{"Allowed + within limits?"}
  C -- No --> X["Reject / quarantine with typed reason"]
  C -- Yes --> D{"Native text reliable and simple?"}
  D -- Yes --> E["Fast engine: PyMuPDF4LLM"]
  D -- No --> F{"Scanned / image dominant?"}
  F -- Yes --> G["Approved OCR-capable engine"]
  F -- No --> H["Docling structured parsing"]
  E --> Q["Run page/block quality checks"]
  G --> Q
  H --> Q
  Q --> R{"Meets quality threshold?"}
  R -- Yes --> S["Normalize into CIR"]
  R -- No --> T{"Budget + policy allow fallback?"}
  T -- No --> P["Partial / review required"]
  T -- Yes --> U["Escalate affected pages to alternate engine"]
  U --> V["Merge with evidence-preserving reconciliation"]
  V --> Q
  S --> W["Chunking + quality gate"]
```

Routing algorithm (implement as an interpretable rule-based baseline; optional learned scorer later):

```python
if source_blocked_by_security or violates_hard_limits:
    reject()
elif forced_engine:
    verify_capability_and_approval(forced_engine)
    route(forced_engine)
elif profile.native_text_suitability >= 0.90 and profile.complexity <= 0.25:
    route("pymupdf4llm")
elif profile.ocr_need >= 0.70:
    route("approved_ocr")
else:
    route("docling")

# All thresholds are starting hypotheses: calibrate against evaluated samples.
# If ambiguous pages fail measurable checks, escalate only those pages,
# within the document's wall-clock/cost budget and classification policy.
```

### 7.4 Page-level escalation

- **Eligibility:** page-level parser override must be supported by adapter. Otherwise route a complete bounded document to the alternative parser and reconcile.
- **Quality triggers:** missing text when page contains visible text, corrupted Unicode, contradictory reading order, suspiciously empty tables, impossible numeric column layouts, OCR confidence under calibrated threshold, missing provenance, excessive overlap.
- **Escalation granularity:** page or page range, not entire document unless needed. Preserve original page numbers and original source regions.
- **Reconciliation:** tag each block with engine provenance; compare candidate extractions before choosing. Do not concatenate competing extractions and duplicate content.
- **Budget:** configurable `max_fallback_pages`, `max_fallback_attempts`, `max_cost_usd`, `hard_deadline_seconds`, `max_gpu_seconds`.
- **Completion:** pages can be `accepted`, `accepted_with_warnings`, `review_required`, `failed`. Overall status is derived, never a blanket success from one parser exit code.
- **Review:** low-confidence pages contribute to review tasks and prevent strict publication profiles from passing.

### 7.5 Content-specific extraction details

**Text & layout**
- Preserve span source offsets, Unicode normalization, paragraphs, lists, headings, indentation, superscript/subscript markers when representable.
- Remove repeated headers/footers only as a *view*, maintaining original blocks and provenance. Use cross-page repetition detection; never delete policy exceptions by heuristic.
- Multi-column order must be evaluated explicitly; do not use naive x/y sorting alone.
- Handle page rotation, text written vertically, ligatures, hyphenation, invisible overlay text, and repeated OCR text layers.

**Tables**
- Extract a normalized cell grid, row/column indexes, merges, explicit headers, spanning headers, caption and units; distinguish `blank`, `not_applicable`, and `extraction_missing`.
- Validate dimensional consistency and numeric type parsing with locale awareness; avoid converting strings such as identifiers and `001234` into numbers.
- Link table slices crossing pages; preserve original page-region evidence for each segment and carry repeatable headers in chunk views.
- Output both canonical cells and optional HTML/Markdown renderings. Downstream calculations should use typed cell values after validation.

**Scanned PDFs & OCR**
- Respect privacy policy and data location; choose on-prem/local or managed engines accordingly.
- Apply deskew/rotation/contrast only if quality benefit is proven and never overwrite original evidence images.
- Persist OCR language/model selection, confidence when the engine provides calibrated signals, and region coordinates.
- Detect text already present to avoid double OCR, except when native text is clearly corrupt.

**Images/diagrams/formulas**
- Record figure position and caption as separate related elements; optional multimodal interpretation is a *candidate description*, not source text.
- Preserve mathematical notation using LaTeX or a typed formula representation where supported; mark conversion loss explicitly.
- No silently generated image captions, legend interpretation, or chart numeric facts without provenance and confidence status.

**Encrypted, malformed, and signed PDFs**
- Handle encrypted/password-protected PDFs with host-provided ephemeral decryption secrets; never log or persist passwords.
- Verify parse permissions and enterprise legal requirements; detect signatures where feasible and do not claim to verify signatures unless a dedicated validated implementation is present.
- Reject unsupported corrupt PDFs or salvage explicitly as `partial` with page failures.

### 7.6 Parser lifecycle and latency

- Use warm parser instances per worker pool, but isolate native-library crashes with process boundaries where justified.
- Lazy-load costly models and share read-only model weights across workers only where implementation supports it safely.
- Do not use Python threads to assume CPU/GPU-bound code becomes parallel. Benchmark process pools and native library behavior; honor GPU concurrency limits.
- For small fast-path documents, co-locate profiling and parsing to avoid an extra queue round-trip.
- Do not retrigger OCR to improve an already accepted source without explicit quality benefit threshold.
- Record `engine_selected`, `reason`, `model_digest`, `pages_escalated`, `fallback_reason`, `queue_wait_ms`, `load_ms`, and `parse_ms`.

---

## 8. Hybrid chunking engine

### 8.1 Design intent

The chunker must support multiple independent intents:

1. **Retrieval chunks:** concise, high-precision passages suitable for lexical/vector indexing.
2. **Parent sections:** larger navigable context for response synthesis.
3. **Structured table chunks:** intact tables or slices with headers, units and page links.
4. **Business assertion views:** obligations, definitions, exceptions, actions and dependency candidates.
5. **Multimodal/figure references:** region references and approved descriptions where available.

**Do not equate chunks with source truth.** Chunks are reproducible views over canonical document elements. Multiple chunk sets may coexist for a document version, indexed under distinct generations.

### 8.2 Chunking pipeline

```mermaid
flowchart TD
  A["Canonical Document Model"] --> B["Build section/heading tree"]
  B --> C["Classify paragraphs, tables, clauses, figures"]
  C --> D{"Special element?"}
  D -- "Table" --> T["Table-preserving slicer"]
  D -- "Rule / exception" --> R["Clause + exception packer"]
  D -- "Ordinary prose" --> H["Hierarchical paragraph packer"]
  T --> E["Tokenizer budget + ancestry metadata"]
  R --> E
  H --> E
  E --> F{"Semantic splitting enabled?"}
  F -- Yes --> G["Safe topic-boundary refinement"]
  F -- No --> I["Parent-child / overlap mapping"]
  G --> I
  I --> J["Context prefix and lexical metadata"]
  J --> K["Evidence/ACL propagation"]
  K --> L["Token + integrity validation"]
  L --> M["ChunkSet with generation ID"]
```

### 8.3 Chunking strategy matrix

| Strategy | Key behavior | Primary benefit | Guardrail |
|---|---|---|---|
| Fixed token | Pack up to token budget | Baseline and simple text | Not default for policies/tables |
| Heading-aware | Section tree groups paragraphs | Coherent context | No invented headings |
| Parent-child | Child for retrieval, parent for evidence expansion | Precision + context | Expand under same authorization |
| Semantic | Embedding-based topic boundary detection | Long narrative shifts | Split only at safe boundaries |
| Table-aware | Slice at row groups with headers/units | Financial fidelity | No orphaned numeric value |
| Rule/exception-aware | Keep actor/requirement/condition/exception together | Better compliance retrieval | Mark unresolved cross-refs |
| Contextual | Prefix source title/section/domain metadata | Disambiguation | Context is metadata, not source quote |
| Late chunking | Contextualized embeddings from long encoding windows | Cross-section semantic signal | Experimental; compatible model only |
| Multimodal | Link figure region and optional image embedding | Diagram retrieval | Preserve source/evidence, cost guard |

### 8.4 Concrete default policy profiles

These are **starting configurations to benchmark**, not empirically guaranteed optima.

| Profile | Child target | Soft max | Parent target | Overlap | Special handling |
|---|---:|---:|---:|---:|---|
| `general_search` | 450 tokens | 650 | 1,600 | 60 tokens | Heading hierarchy |
| `regulatory_policy` | 350 | 650 | 1,400 | 40 | Obligation + exception atomicity |
| `contracts` | 450 | 750 | 1,800 | 50 | Clause/definition/cross-ref grouping |
| `financial_tables` | variable | 900 | full logical table | 0 rows; repeat headers | Typed cells + period/unit |
| `technical_manual` | 500 | 800 | 1,800 | 80 | Code/formula/figure association |
| `speed_optimized` | 600 | 900 | 2,000 | 30 | Skip semantic embedding boundary search |

`target_tokens` is the ordinary desired size, not a command to break atomic units. Use the actual embedding tokenizer where available; otherwise use a conservative approximation and mark it so. For an atomic clause larger than max: split along internal subclauses with duplicated *references* and explicit `oversized_atomic_group=true`. There is no unconditional hard split that loses exception context.

### 8.5 Detailed deterministic algorithm

```text
INPUT: DocumentArtifact D, ChunkingProfile P, tokenizer T
1. Validate D against CIR invariants and policy propagation.
2. Build a section tree from explicit headings, TOC, and structural blocks.
3. Infer heading levels only where parser provides defensible evidence; emit ambiguity otherwise.
4. Associate definitions, footnotes, captions, tables, figures and references with nearby anchors.
5. Mark protected atomic groups:
   a. clause + immediately linked exception/condition,
   b. list introduction + nested items,
   c. table header+units+row group,
   d. formula+variable definitions,
   e. referenced cross-page continuation.
6. For each section in reading order, generate candidate atomic groups.
7. Pack candidate groups until target_tokens reached; stop at structural boundaries.
8. If group > soft_max, try safe logical internal boundaries.
9. If P.semantic_enabled, compute boundary signal only between safe candidate groups;
   split where calibrated semantic discontinuity improves evaluation.
10. Attach parent_section_id; create child-to-parent maps and evidence spans.
11. Create contextual prefix: document title + section path + allowed business metadata.
12. Render `text` and `display_text` separately; prefix is not presented as a quote.
13. Validate: token count, evidence coverage, ACL label monotonicity, parent links,
    no duplicated span except declared overlap, stable hash, table integrity.
14. Return immutable ChunkSet; include algorithm version and config digest.
```

### 8.6 Parent-child retrieval contract

`child_chunk` is indexed; `parent_section` may be stored in Postgres as canonical retrieval context and optionally indexed. Upon retrieval:

1. Candidate child carries `parent_id`, source version, evidence refs and security label.
2. Resolver verifies caller's **product and source** entitlement before fetching the parent.
3. Parent expansion has a token budget and deduplicates repeated parent sections.
4. Result includes `retrieved_child_ids`, `expanded_parent_ids`, original page citations and all policy constraints.
5. Never expand into inaccessible neighbor sections; parent boundaries may cross security domains only if labels allow it, else split the parent at the security boundary.

### 8.7 Table-specific chunking

For an illustrative income statement:

```text
Table: Financial Results — FY2026
Unit: INR millions
Columns: Metric | FY2025 | FY2026
Revenue  |  1200 | 1450
Costs    |   860 |  940
```

Produce a typed `TableArtifact` and one or more retrieval views, e.g.:

```json
{
  "chunk_kind": "table_slice",
  "table_id": "tbl-17",
  "header_context": ["Metric", "FY2025", "FY2026"],
  "unit_context": "INR millions",
  "row_range": [1, 2],
  "display_text": "Revenue: FY2025 1200, FY2026 1450 ...",
  "source_cell_refs": ["tbl-17:r1:c1", "tbl-17:r1:c2"],
  "evidence_refs": ["ev-table-17"]
}
```

A chunk **must not** convert `FY2025` into `FY2026`, change `millions` to `units`, or separate the table heading/units from values. Row-slice chunking repeats header metadata as a reference; duplicate literal text only in the index view.

### 8.8 Business rule chunking

Regulatory/legal/contract clauses require richer objects:

```text
ObligationCandidate
  actor, action, object, deadline, temporal_trigger,
  preconditions, exceptions, negations, effective_period,
  jurisdiction, cross_references, evidence_refs,
  extraction_method, confidence, review_state
```

A single chunk may cite multiple pages. If the exception is on a separate page, use linked evidence refs and a `depends_on_chunk_id`; do not rely on text overlap alone.

### 8.9 Contextual retrieval and semantic splitting

- **Contextual retrieval:** Add deterministic title/heading/domain/date prefixes to embedding and lexical index views. Optional model-generated contextual notes are visibly labeled and require source-bound grounding and review policy.
- **Semantic chunking:** Compare group embeddings using a configurable provider. Compute breakpoints only where structural rules permit them. Cache candidate-group embeddings keyed by content/model; do not call model per token or per sentence without an explicit budget.
- **Late chunking:** Keep behind feature flag and benchmark because embedding models have different long-context capabilities and pooling semantics. Never use a chunker that assumes a long-context embedding encoder if the selected model does not support it.
- **Hybrid** means combining meaningful structure and semantic heuristics; **hybrid retrieval** is a separate step combining retrieval signals. Keep these terms distinct in code and documentation.

### 8.10 Chunk integrity tests

- Every source block is either represented in retrieval/chunk output, explicitly excluded with a reason (e.g. decorative footer), or preserved via reachable parent/context evidence.
- Protected clause + exception atomicity holds, or an explicit linked representation is used.
- Chunk token count below configured limit except explicitly audited oversized atomic groups.
- All chunk IDs and parent mappings are stable under repeated runs.
- Policy and source lineage never become less restrictive downstream.
- Table values and header/units are preserved with exact-string tests on gold fixtures.
- Rechunking does not parse source bytes again unless the original CIR is unavailable/incompatible.

---

## 9. Knowledge enrichment and typed extraction

The SDK core ends at **evidence-preserving structure + chunks**. Enterprise enrichment is an optional plugin stage with typed candidate outputs, explicit model dependencies, and no automatic promotion to business truth.

### 9.1 Enrichment modules

| Module | Inputs | Outputs | Default |
|---|---|---|---|
| Language/NER | Blocks, section metadata | Entity mentions with offsets | Optional |
| Entity resolution | Mentions + host ontology/catalog adapters | Candidate canonical entity links | Optional |
| Obligation/rule extraction | Clauses, conditions, definitions | Typed `ObligationCandidate` | Optional |
| Relation extraction | Entity mentions, blocks, tables | Candidate subject–predicate–object relations | Optional |
| Temporal extraction | Dates, effective clauses, version context | Temporal validity candidates | Optional |
| Table semantics | Table cells, labels, headings | Metric/period/unit annotations | Optional |
| Visual interpretation | Figure region + permitted model | Caption/diagram candidates | Disabled by default |
| Embedding generation | Chunk index text | Embedding vectors with model version | Optional adapter |

### 9.2 Assertion contract

An `Assertion` or `CandidateAssertion` must include:

- Subject, predicate, object as typed semantic IDs or unresolved mentions.
- Source document/chunk/region refs; inference/extraction algorithm and model version.
- Assertion status: `candidate`, `verified`, `rejected`, `superseded`, `retracted`.
- Evidential confidence plus calibration scope. **Confidence is not a truth guarantee**.
- Effective-time validity, document-version validity and semantic ontology version.
- Source policy reference and sensitivity. Graph projection must not expose evidence beyond caller policy.
- Reviewer ID and approval decision where applicable, recorded in host platform.

### 9.3 Human review workflow

```mermaid
stateDiagram-v2
  [*] --> Candidate
  Candidate --> AutoAccepted: passes conservative policy
  Candidate --> NeedsReview: ambiguity / criticality
  NeedsReview --> Verified: reviewer approves
  NeedsReview --> Rejected: reviewer rejects
  AutoAccepted --> Verified: subsequent verification
  Verified --> Superseded: source version changes
  Verified --> Retracted: correction / policy withdrawal
  Rejected --> [*]
  Superseded --> [*]
  Retracted --> [*]
```

The host defines when auto-accept is permitted. For high-stakes regulatory obligations and numerical facts, default to evidence-backed review rather than automatic authoritative graph writes.

### 9.4 Prompt injection and LLM use

Documents are untrusted *data*, never instructions. All LLM-assisted enrichment must use hardened templates that keep untrusted document content in data fields, disable tool execution from document text, constrain output to validated schemas, and limit token/cost budgets. Do not allow a PDF instruction such as “ignore previous instructions” to modify parser routing, auth, external calls, or indexing policy. Store model-generated metadata separately from extracted text.

---

## 10. Storage adapters and publication integration

### 10.1 Source-of-truth distinction

- **GCS/object storage:** source bytes and immutable derived artifacts (CIR JSON, table JSON, crops, quality reports, chunk files). Host controls encryption/retention.
- **PostgreSQL:** authoritative ingestion ledger, document/chunk metadata, provenance references, processing configs, job state, review metadata, product release manifests, and *pgvector embeddings when selected*.
- **Elasticsearch:** rebuildable search projection for BM25/full-text and optional vector search if benchmarked. Default: keep vectors in pgvector to avoid duplicating embeddings.
- **FalkorDB:** authoritative business entity/relationship graph within the Knowledge Manager's semantic model, with candidate/verified assertions clearly separated; graph indexes for traversal. Avoid putting general document chunk embeddings here by default.
- **DataHub (optional):** catalog/ownership/lineage synchronization; not an SDK prerequisite.

**Important:** 'Source of truth' is *type-specific*: original document/evidence = immutable artifact store; processing metadata = PostgreSQL; governed business relationships = FalkorDB. A Knowledge Product's manifest binds these into one auditable release.

### 10.2 PostgreSQL schema sketch

The following is implementation-oriented SQL, not a complete migration. Prefer SQLAlchemy/Alembic or equivalent with explicit composite foreign keys, migrations, and row-level security as appropriate. The sketch assumes a `vector(1024)` embedding model; **dimension must match the selected model** and cannot be changed silently.

```sql
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE documents (
  tenant_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  document_id TEXT NOT NULL,
  source_sha256 TEXT NOT NULL,
  source_uri TEXT NOT NULL,
  media_type TEXT NOT NULL,
  source_policy_ref TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, workspace_id, document_id)
);

CREATE TABLE document_generations (
  tenant_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  generation_id TEXT NOT NULL,
  document_id TEXT NOT NULL,
  parser_id TEXT NOT NULL,
  parser_version TEXT NOT NULL,
  cir_schema_version TEXT NOT NULL,
  artifact_uri TEXT NOT NULL,
  config_digest TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','partial','complete','failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, workspace_id, generation_id),
  FOREIGN KEY (tenant_id, workspace_id, document_id)
    REFERENCES documents (tenant_id, workspace_id, document_id)
);

CREATE TABLE document_chunks (
  tenant_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  chunk_generation_id TEXT NOT NULL,
  chunk_id TEXT NOT NULL,
  document_id TEXT NOT NULL,
  parent_id TEXT,
  source_policy_ref TEXT NOT NULL,
  section_path JSONB NOT NULL DEFAULT '[]'::jsonb,
  evidence_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
  display_text TEXT NOT NULL,
  embedding_text TEXT NOT NULL,
  chunk_kind TEXT NOT NULL,
  content_sha256 TEXT NOT NULL,
  PRIMARY KEY (tenant_id, workspace_id, chunk_generation_id, chunk_id),
  FOREIGN KEY (tenant_id, workspace_id, document_id)
    REFERENCES documents (tenant_id, workspace_id, document_id)
);

CREATE TABLE document_embeddings_1024 (
  tenant_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  chunk_generation_id TEXT NOT NULL,
  chunk_id TEXT NOT NULL,
  embedding_generation_id TEXT NOT NULL,
  model_id TEXT NOT NULL,
  embedding vector(1024) NOT NULL,
  PRIMARY KEY (tenant_id, workspace_id, embedding_generation_id, chunk_id),
  FOREIGN KEY (tenant_id, workspace_id, chunk_generation_id, chunk_id)
    REFERENCES document_chunks (tenant_id, workspace_id, chunk_generation_id, chunk_id)
);

CREATE INDEX ON document_chunks (tenant_id, workspace_id, document_id);
CREATE INDEX ON document_chunks (tenant_id, workspace_id, chunk_generation_id);
CREATE INDEX ON document_embeddings_1024 USING hnsw (embedding vector_cosine_ops);
```

**Indexing caution:** pgvector approximate nearest-neighbor indexes can under-return matches when restrictive metadata filtering is applied after ANN candidate selection. Benchmark filtered recall; investigate iterative scans, tenant-aware partitioning, selective exact search, or filtered index strategies supported by installed pgvector version. Do not assume `LIMIT 10` returns ten authorized results under every filter.

**RLS and policy:** use composite tenant keys consistently and enforce tenant/workspace scope in application and database. Application RLS cannot substitute for document/product ABAC checks; policy engine outcomes must apply across all storage adapters.

### 10.3 Elasticsearch document example

Store no source PDF bytes; project authorized searchable text and metadata:

```json
{
  "_id": "tenant-a|risk-ws|gen-7|chunk-abc",
  "tenant_id": "tenant-a",
  "workspace_id": "risk-ws",
  "product_release_id": "kp-risk-2026-r3",
  "chunk_generation_id": "gen-7",
  "chunk_id": "chunk-abc",
  "document_id": "doc-17",
  "title": "Incident Notification Policy",
  "section_path": ["Operational Resilience", "Notification"],
  "content": "Critical service providers must notify ...",
  "chunk_kind": "business_obligation",
  "source_policy_ref": "src-policy-112",
  "security_terms": ["classification:confidential"],
  "evidence_refs": ["ev-312"],
  "content_sha256": "..."
}
```

- Use versioned physical indices, explicit mappings and index templates, bulk indexing, and **release-specific aliases**.
- Filter by authorized tenant, product releases, document scope and source policy dimensions before forming candidate sets. Token-level ABAC must be resolved by a trusted policy layer; `security_terms` alone are not sufficient for arbitrary dynamic ABAC.
- Prefer smaller and stable postings fields for lexical indexing; cap term expansion and prevent unauthorized highlights/snippets.
- Search projection is rebuildable and cannot override canonical evidence or product policy.
- Enable native Elasticsearch vector retrieval only after demonstrating a measurable advantage over pgvector; align dimension and model generation.

### 10.4 FalkorDB graph projection

Possible graph shapes (adjust to the Knowledge Manager's existing ontology—**do not impose these labels unconditionally**):

```mermaid
flowchart LR
  D["DocumentVersion"] -->|CONTAINS| S["Section"]
  S -->|SUPPORTS| O["Obligation"]
  O -->|APPLIES_TO| A["BusinessEntity / Application"]
  O -->|GOVERNED_BY| P["Policy / Regulation"]
  O -->|HAS_EXCEPTION| E["Exception"]
  O -->|EVIDENCED_BY| R["EvidenceRegion"]
  O -->|SUPERSEDES| OLD["Previous Assertion"]
  S -->|PUBLISHED_IN| KP["KnowledgeProductRelease"]
```

**Graph write contract:**
- Use MERGE/upsert semantics keyed by composite stable IDs including tenant/workspace/product scope and assertion version.
- Materialize `candidate` and `verified` relations distinctly; serving queries exclude unapproved assertions unless explicitly requested by authorized reviewers.
- Maintain document/chunk/evidence provenance IDs as properties or evidence nodes; do not replicate full text into every graph node.
- Respect graph-wide/workspace constraints and query resource budgets; never use untrusted string concatenation in Cypher.
- Graph relationship changes are propagated from approved assertion events, not from a best-effort parser guess.
- Treat delete/retract as explicit event, and update reverse-dependency relationships as part of graph maintenance.

### 10.5 Transactional outbox, index generations and read consistency

A single ACID transaction across PostgreSQL, Elasticsearch and FalkorDB is **not** assumed. Make each downstream projection idempotent, measurable, and rebuildable.

```mermaid
sequenceDiagram
  autonumber
  participant PG as PostgreSQL + outbox
  participant Q as Projection Queue
  participant ES as Elasticsearch
  participant GR as FalkorDB
  participant G as Release Gate
  participant CT as Catalog Pointer
  PG->>PG: Commit chunk records + outbox atomically
  PG-->>Q: Deliver event, at least once
  par projections
    Q->>ES: Upsert search generation G1
    ES-->>PG: Record readiness G1
  and
    Q->>GR: Upsert graph generation G1
    GR-->>PG: Record readiness G1
  end
  G->>PG: Check counts, checksums, policy, review
  alt all generation gates pass
    G->>CT: Atomically activate release manifest G1
  else fail/timeout
    G-->>PG: Keep old release active; mark G1 failed
  end
```

- Event identity is a deterministic `(tenant, workspace, generation, entity_type, entity_id, operation, schema_version)` key. Consumers must tolerate duplicates and out-of-order delivery.
- A manifest records `document_generation`, `chunk_generation`, `embedding_generation`, `elasticsearch_index_alias`, `falkordb_projection_generation`, and a policy/ontology version.
- **No partial publication:** a release is not active until required projectors report readiness and quality gates pass. Optional graph projection failures may be tolerated only if the product contract does not require graph capabilities.
- Use staging index/alias or generation filters for ES. For FalkorDB, segregate/assert generation IDs in records and switch an active manifest pointer in the control plane; do not assume transactional atomic switching across stores.
- At request time, resolve a **single active release manifest** and pass its generation IDs to every adapter. Do not silently mix new search with old graph assertions.
- On rollback, reactivate a prior valid manifest; garbage-collect stale generations only after retention and active-reader grace periods.

### 10.6 Version diff and incremental regeneration

- New source SHA means new document version, even if filename is unchanged.
- Compare canonical blocks using stable section headings, anchor positions, normalized text hashes and approximate semantic alignment. Align for diff without mutating source version IDs.
- Re-embed only chunks whose embedding inputs changed or embedding model revision changed; cache embeddings by `(model_digest, normalized_embedding_text_digest, security_scope_if_relevant)`.
- Re-enrich only affected blocks and their dependency neighborhood; invalidate graph assertions referencing changed passages.
- A new chunker version creates a new chunk generation even when source bytes are unchanged.
- Provenance and release policy must remain bound to the correct immutable source version.
- Support GDPR/retention-driven deletion and key revocation with propagated tombstones; do not use a cache that can resurrect deleted content.

---

## 11. Hybrid and graph-aware retrieval

Retrieval is an **optional host integration**, not a mandatory responsibility of the parsing SDK. Define the cross-layer contract anyway so the SDK creates the necessary artifacts.

### 11.1 Candidate retrieval flow

```mermaid
flowchart TB
  Q["User / Agent Query"] --> AUTH["Authenticate + authorize product release"]
  AUTH --> INT["Query intent / retrieval profile"]
  INT --> LEX["Elasticsearch BM25"]
  INT --> VEC["pgvector similarity"]
  INT --> GR["FalkorDB entity / relation traversal"]
  LEX --> JOIN["Deduplicate by release + chunk ID"]
  VEC --> JOIN
  GR --> JOIN
  JOIN --> FILTER["Recheck source-level ABAC + version gates"]
  FILTER --> FUSE["Weighted RRF / hybrid fusion"]
  FUSE --> RANK["Optional reranker, deadline-bounded"]
  RANK --> PARENT["Authorized parent and table evidence expansion"]
  PARENT --> EVID["Evidence sufficiency + citation validation"]
  EVID --> OUT["Governed Context Bundle"]
```

**Important order:** for actual deployment, apply enforceable scope/ACL filters **inside the first-stage retrieval queries**, not only in the depicted post-join defense-in-depth filter. The graph adapter must enforce equivalent constraints before traversal and expansion. Any retrieval path that cannot enforce required ABAC must be disabled for that caller.

### 11.2 Query-adaptive profiles

| Query class | Preferred candidate strategy | Expansion |
|---|---|---|
| Exact clause / identifier | Elasticsearch BM25 + terms | Parent clause, cross-references |
| Natural-language question | BM25 + pgvector + rerank | Parent section and citations |
| Regulatory impact | Semantic lookup → verified FalkorDB traversal | Impacted services, controls, owners |
| Financial metric | Table/structured lookup + exact cell evidence | Units, periods and notes |
| Definition | Lexical exact phrase + semantic fallback | Canonical definition + effective version |
| Version change | Diff index + structured section alignment | Old/new evidence pairs |
| Multi-hop entity question | FalkorDB traversal constrained by scope | Source proof for each relationship |

### 11.3 Federation and ranking

Candidate lists must use a common identifier: `(tenant_id, product_release_id, chunk_generation_id, chunk_id)` for chunks, and stable typed IDs for graph assertions. Use independent scores rather than pretending BM25 and cosine scores are directly comparable.

**RRF sketch:** `score(d) = Σ_i weight_i / (k + rank_i(d))`, with rank window, `k`, candidate counts and weights configured and evaluated. Use Elasticsearch-native RRF only for multiple retrievers executed *inside Elasticsearch*. For BM25 in Elasticsearch plus vectors in pgvector, implement fusion in the host retrieval orchestrator.

**Reranking:** cap candidate count and token lengths; use a cheap cross-encoder or model only when within the query latency budget. Hard timeout returns the successfully fused candidate set rather than failing the whole query, with a `rerank_skipped_reason` trace attribute.

### 11.4 Retrieval response contract

```json
{
  "request_id": "req-998",
  "knowledge_product_release": "kp-risk-r3",
  "retrieval_profile": "regulatory_policy_v1",
  "chunks": [
    {
      "chunk_id": "chunk-abc",
      "document_version_id": "sha256:...",
      "text": "...",
      "section_path": ["Incident Management", "Notification"],
      "evidence_refs": ["ev-21"],
      "retrieval_sources": ["bm25", "pgvector"],
      "rank": 1
    }
  ],
  "graph_assertions": [],
  "evidence_status": "sufficient",
  "warnings": [],
  "policy_decision_id": "pdp-decision-12",
  "release_manifest_id": "manifest-50"
}
```

No answer-generation step is allowed to fabricate evidence references. When evidence is insufficient, return `insufficient_evidence` and ask the calling inference service to refrain from an unsupported assertion.

---

## 12. Workflows, jobs, and state machines

### 12.1 Hosted ingestion lifecycle

```mermaid
stateDiagram-v2
  [*] --> Received
  Received --> Validating
  Validating --> Rejected: bad format / policy / safety
  Validating --> Queued: accepted
  Queued --> Profiling
  Profiling --> Parsing
  Parsing --> Normalizing
  Normalizing --> Chunking
  Chunking --> QualityCheck
  QualityCheck --> NeedsReview: ambiguous critical content
  QualityCheck --> Projecting: accepted
  Projecting --> ReadyForPublication
  NeedsReview --> Projecting: approved
  NeedsReview --> Rejected: rejected
  ReadyForPublication --> Published: release gate passes
  Profiling --> RetryWaiting: transient fault
  Parsing --> RetryWaiting: transient fault
  Projecting --> RetryWaiting: transient fault
  RetryWaiting --> Queued: backoff
  Parsing --> Partial: unrecoverable pages
  QualityCheck --> Partial: incomplete evidence
  Partial --> NeedsReview: policy permits review
  Published --> Superseded: new release
  Queued --> Cancelled: cancellation
  Parsing --> Cancelled: cancellation
  Rejected --> [*]
  Cancelled --> [*]
  Superseded --> [*]
```

Some states are owned by the **host workflow**, not SDK. Pure SDK can emit `received/profiling/parsing/normalizing/chunking/quality/complete/partial/failed/cancelled` events; host adds `queued`, `projecting`, `review`, and `published`.

### 12.2 Work separation

- **Inline process:** file validation, metadata, preflight and small fast-path parsing under a short deadline.
- **CPU worker:** layout/text extraction, normalization, chunking, serialization, fast embeddings where cost-efficient.
- **GPU/OCR worker:** OCR, complex layout, visual models and optional cross-encoder heavy jobs.
- **Projection worker:** writes to PostgreSQL/outbox, Elasticsearch and FalkorDB; independently retryable.
- **Enrichment worker:** business entity/rule extraction and verification staging; separate quotas.
- **Workflow orchestrator:** can be Temporal or existing platform workflow engine; SDK must not depend on a particular orchestrator.

### 12.3 Idempotency, leases and retries

- Intake idempotency key: `(tenant, workspace, source_hash, pipeline_config_digest, requested_product_scope)` or an explicit client key mapped to this tuple.
- Worker claims a lease with expiration and heartbeat. Lease expiry makes task eligible for retry, not permission to produce duplicate active records.
- Persist stage checkpoints at page ranges or artifacts to allow resume without reparsing accepted pages.
- Retry transient errors with exponential backoff + jitter; no retries for password failure, malformed safety-blocked files, invalid schema or policy denied.
- Set bounded retry count and move exhausted jobs to DLQ; expose sanitized error and diagnostic ID.
- Cancellation must stop future external calls, release GPU slots and mark incomplete outputs as unusable for publication.
- A request timeout is not a cancellation guarantee if third-party native code is uninterruptible: use isolated subprocess workers and terminate after a grace period.

### 12.4 Backpressure and fairness

- Maintain separate queues for `fast_text`, `layout`, `ocr_gpu`, `embedding`, `enrichment`, `projection` with priority and tenant admission quotas.
- Use per-tenant token buckets or weighted fair scheduling to prevent one tenant monopolizing GPU/memory and queues.
- Each worker pool has bounded in-flight documents/pages; streaming results are spooled to artifacts rather than accumulated fully in RAM.
- Degrade gracefully by skipping optional enrichment or returning partial/review; **never** skip mandatory provenance, security, or quality checks.
- Apply circuit breakers for unavailable managed OCR, embedding provider or storage backend; persistent jobs remain retryable.

## 13. Security, multi-tenancy, and governance

### 13.1 Trust boundaries

```mermaid
flowchart TB
  U["Untrusted PDF / file contents"] --> PRE["Sandboxed preflight + malware checks"]
  PRE --> SDK["Least-privilege parsing workers"]
  SDK --> B["Tenant-scoped immutable artifacts"]
  B --> P["Policy enforcement point / PDP"]
  P --> IDX["Tenant + release-scoped indexes"]
  IDX --> API["Authorized retrieval / citation service"]
  S["Authenticated user / workload identity"] --> P
  O["Domain owner / approved builder"] --> POL["Policy authoring + approval"]
  POL --> P
  API --> AUD["Audit + security telemetry"]
```

**Host trust contract:** the SDK must accept a trusted `ProcessingContext` issued by a host boundary; it must not infer tenant/workspace authorization from strings inside the source document, file path, PDF metadata, or user-provided arbitrary JSON. When used standalone, context can be omitted; when used behind a hosted API, context is mandatory and validated before dispatch.

### 13.2 Threat model

| Threat | Required control | Verification |
|---|---|---|
| Malicious/corrupt PDF exploiting native parser | Sandboxed process, patched libraries, constrained filesystem/network, resource limits | Fuzz/malformed corpus, container scan |
| Resource exhaustion / zip bomb / huge images | Bytes/pages/pixel/CPU/GPU/memory quotas and watchdog | Large/adversarial file tests |
| Cross-tenant data leakage | Tenant-scoped keys, auth filters, policy-checked artifact read, deny by default | Cross-tenant negative tests |
| Prompt injection in extracted text | Untrusted data isolation, typed model output, tool denial | Adversarial document prompts |
| External OCR/LLM data exfiltration | Egress opt-in by classification; allowlist; residency policy | Egress blocking tests |
| SSRF from URI input / embedded references | Controlled object loader; URL allowlist; no automatic external resources | SSRF corpus |
| Injection in metadata/SQL/Cypher | Parameterized queries, escaping, typed schemas | Security tests |
| Storage prefix breakout | No path traversal; hash-based host-controlled prefixes | Path traversal tests |
| Unauthorized citation/image crop | Citation/evidence retrieval rechecks caller and release policies | Redacted evidence tests |
| Hidden cross-document references bypass ACL | Cross-ref resolution only for authorized products/sources | Mixed-ACL fixtures |
| PII in logs, traces, events | Metadata-only telemetry, redact IDs where needed | Log snapshot tests |
| Stale knowledge after deletion/withdrawal | Tombstones, manifest invalidation, cache/index eviction, key policy | Erasure propagation tests |
| License/noncompliant engine activation | Engine allowlist, artifact metadata, approved model digests | Supply-chain policy checks |

### 13.3 Workspace and product security semantics

- **Ingestion authorization**: upload/update/read in the authoring workspace is determined by workspace and source policies.
- **Knowledge Product creation**: domain owners/builders act according to product role and workflow permissions; they can propose RBAC/ABAC policies but cannot bypass mandatory organization policies.
- **Publication authorization**: product release is approved with policy version pinned. A consumer's entitlement to the published product is separate from authoring permissions.
- **Derived-knowledge authorization**: a chunk, table or graph assertion derived from sources with disjoint permissions uses a conservative, explicit **join-of-restrictions** policy; a model summary cannot silently declassify source data.
- **Retrieval authorization**: policy enforcement occurs in entry gateway, candidate retrieval filters, graph traversal, parent expansion, evidence fetch and final context packaging.
- **Policy changes**: re-evaluate active products if source access rules change; invalidate caches immediately (or deny until rebuild) and schedule projections/reindex where policy terms are materialized.
- **Cross-product joins**: only compute over combinations the caller is entitled to see. Never disclose that a hidden entity exists via hit counts or graph degree.

### 13.4 Data classification and PII

- Support classification labels such as `public/internal/confidential/restricted` as **host-configured labels**, not hardcoded universal policies.
- PII detection/redaction is an optional processing step governed by host policy. Store unredacted source only within its approved security boundary; avoid sending unredacted spans to lower-trust embedding or cloud OCR providers.
- Embedding and semantic cache keys must include the relevant security scope if deduplication could reveal whether an inaccessible document was processed.
- For legal hold, data residency, sovereignty and retention, rely on host policy; SDK only exposes metadata and deletion hooks.
- Treat model-generated visual descriptions and embeddings as potential sensitive derivatives.

### 13.5 Provenance, audit and accountability

Each hosted ingestion emits append-only audit events with actor/workload identity, source hash, tenant/workspace/product, engine/model versions, plugin configuration digest, policy decision IDs, timestamps, review decisions, release manifest and outcome. Avoid raw content, passwords, OCR text or vector values in audit events. Define retention and deletion with the host governance team.

---

## 14. Latency, throughput, and capacity engineering

### 14.1 Define latency precisely

**Three distinct user-facing experiences:**

1. **Time to acceptance:** upload validated, source persisted and job ID returned. Measured from API receive to HTTP 202, excluding client upload time only if explicitly stated.
2. **Time to useful preview:** enough pages/sections available to review; may precede full enrichment and publication.
3. **Time to searchable Knowledge Product:** approved release manifest activated and query-visible in all *required* stores.

Separate **queue wait**, **cold start/model load**, **compute**, **I/O**, **indexing**, **review wait**, and **publication delay**. Review wait cannot be promised within a machine SLO.

### 14.2 Proposed latency SLO candidates (not measured claims)

The numbers below are **initial engineering targets** for controlled reference hardware and benchmark fixtures; confirm with measured load tests before making external commitments. Distinguish warm vs cold paths and 50th/95th percentile. The target is *not* a guarantee for every PDF.

| Operation | Benchmark input | Candidate warm p95 target | Exclusions/notes |
|---|---|---|---|
| Preflight profile | 10-page digital PDF, ≤5 MB | ≤0.8 s | No deep OCR |
| Fast native extraction | 10-page single-column digital PDF | ≤3.0 s | Warm CPU worker, no OCR |
| CIR normalization + baseline chunking | 10-page, 8k words | ≤1.5 s | Excludes embeddings |
| Local SDK parse+chunk | 10-page digital PDF | ≤5.0 s | Warm, fixed hardware |
| Ingest API acceptance | Pre-uploaded object reference | ≤0.7 s | No document parsing inline |
| First preview | 20-page digital PDF | ≤6 s | Under low queue load |
| Complete 20-page digital searchable generation | 20-page typical PDF | ≤20 s | Warm workers, no human review |
| Search retrieval, no LLM generation | 95% typical queries | ≤700 ms p95 | Under specified store and load conditions |
| OCR-heavy 20-page PDF | 20-page scanned document | **Measure, no fixed target yet** | Hardware/model/language strongly affect latency |

Record targets in a versioned benchmark profile (`hardware`, `parser config`, `model digests`, `dataset class`, `concurrency`). Publishing a p95 number without these qualifiers is invalid.

### 14.3 Sample critical-path budget

For a **10-page native-text warm processing target of 5 seconds**, an initial profiling budget might be:

| Stage | Planning allocation (ms) | Optimize by |
|---|---:|---|
| MIME/safety validation + profile | 500 | Bounded samples, cached fingerprint |
| Parser selection | 50 | In-process rules |
| Text/layout parse | 2,800 | Native fast path, warm workers |
| CIR normalization | 550 | Single-pass streaming normalization |
| Hierarchy-aware chunking | 500 | Tokenizer reuse, avoid per-sentence model calls |
| Serialization + result assembly | 350 | Efficient structured encoders |
| Reserved slack | 250 | Scheduling variability |
| **Total** | **5,000** | **Excludes** network upload, queueing, embeddings, indexing |

The sum is an **allocation**, not a set of independently measured percentile guarantees. Aggregated p95 requires end-to-end measurement. For hosted full ingestion, track an additional embedding/indexing budget and queue delay separately.

### 14.4 Throughput and capacity formulas

For each work class `i`:

```text
arrival_rate_i = documents_per_second_i
mean_service_time_i = worker_seconds_per_document_i
steady_state_concurrency_i ≈ arrival_rate_i × mean_service_time_i
required_workers_i ≈ concurrency_i / measured_parallel_efficiency_i × headroom_factor
```

This is a Little's Law/throughput approximation. In production, size using p95/p99 service-time distributions, worker memory, page variance, autoscaling lag and target utilization. A sustained 100%-busy pool causes large queues; keep planned headroom.

Example capacity **illustration**: 12,000 digital pages/hour with a measured rate of 8 pages/second per warm CPU worker implies an ideal minimum of `12,000 / (8×3,600) ≈ 0.42` continuously busy workers. At 60% target effective utilization and with redundancy, provision at least two workers in this simplified example. Real sizing requires document-size mix, model cost and queue bursts; do not extrapolate the 8 pages/sec assumption without measurement.

### 14.5 Latency optimization backlog, priority order

1. **Route simple digital PDFs to a lightweight engine**; reserve OCR and visual models for failing pages.
2. **Preflight on a sample**, not a whole-document visual pass.
3. **Avoid repeated work**: fingerprint source and memoize stable parse/chunk/embedding generations.
4. **Run page-level parallelism only when safe**, preserving order and limiting memory; benchmark per engine.
5. **Warm model workers** with bounded concurrency; model loading must not occur per page.
6. **Separate CPU, GPU and I/O-heavy queues**, with autoscaling based on weighted backlog and processing time.
7. **Stream partial results and artifacts** rather than constructing giant in-memory JSON graphs.
8. **Batch embeddings** by token budgets and provider rate limits, not naive fixed document counts.
9. **Use efficient bulk indexing** with backpressure and index refresh strategy; avoid per-chunk synchronous commits.
10. **Avoid unconditional semantic chunk splitting**: it can require many model calls and does not help every document type.
11. **Store parent sections once**, not repeated as large literals in every child chunk; deduplicate context at retrieval.
12. **Use approximate similarity selectively** based on real corpus size/filtering/recall; exact pgvector search may be adequate for small collections.
13. **Limit graph neighborhood traversal** by depth, max nodes, query timeout and caller permissions.
14. **Shed optional stages under load** (e.g. visual captions, expensive enrichment), never security/evidence checks.
15. **Compile and reuse tokenizers/config** within process; measure serialization overhead and avoid repeated Markdown conversions.

### 14.6 Why fast parsing alone does not determine business latency

Total processing time depends on `parse + normalize + chunk + embeddings + index + authorization + release gate + queue`. A parser 2× faster may have marginal effect if embedding/indexing dominates. Use traces to rank bottlenecks under real document-class mixes. In some cases a slightly slower structured parser reduces manual corrections enough to deliver lower *time-to-trusted-knowledge*.

### 14.7 Dynamic budget controller

Each processing request should carry:

```yaml
processing_budget:
  priority: interactive            # interactive | batch | background
  accuracy_tier: balanced          # fast | balanced | high
  deadline_seconds: 30
  max_fallback_pages: 5
  max_ocr_pages: 10
  max_model_tokens: 25000
  max_external_cost_usd: 0.0       # zero => no paid external calls
  on_timeout: return_partial       # or fail_closed
```

The controller allocates stage budgets based on profile and job queue depth. It must avoid committing an entire time budget to the first slow parser before deciding fallback. For critical structured extraction, a `high_accuracy` profile may prioritize completeness over strict deadlines and therefore run asynchronously.

### 14.8 Latency-aware query serving

Use a separate target for retrieval-time context resolution:

```text
Request auth/policy resolution     ~50 ms
Query embedding (cached/warm)      ~80 ms
BM25 + pgvector in parallel       ~180 ms
Graph expansion (when requested)  ~100 ms
Fusion and scope check            ~40 ms
Optional reranker                  ~150 ms
Parent/evidence fetch             ~50 ms
Budget headroom                   ~50 ms
------------------------------------------
Illustrative total                ~700 ms
```

These are planning budgets for *representative* warm requests, not vendor guarantees or measured values. The real critical path is determined by **parallel** versus sequential operations. Graph expansion may depend on semantic candidate IDs; implement a distinct DAG by query class and measure both tail latency and recall. Include timeouts, cancellation and policy-aware caching. Retrieval SLAs must exclude subsequent LLM answer generation unless explicitly bundled.

### 14.9 Scale testing scenarios

- 1, 8, 32, 128 concurrent small digital PDFs, with steady-state and burst loads.
- Mixed workload: 70% text, 20% complex tables/layout, 10% scanned (illustrative mix; replace with empirical mix).
- 10 tenants with one noisy tenant; compare fairness before/after quotas.
- Documents from 1 page to configured maximum with long-page outliers.
- Cold start versus warm workers; autoscaling under step-load; failed third-party OCR provider.
- 100k, 1m, 10m chunks to test retrieval filter selectivity and pgvector ANN recall.
- Large multimodal tables, cross-page tables, corrupted PDFs, non-Latin OCR and low-confidence scans.
- Replay of duplicate events, out-of-order projection, release rollback and index rebuild.

**Must report** p50/p90/p95/p99 latency, queue age, pages/sec, CPU/GPU-seconds per page, RAM peak, tokens/document, $/1,000 pages, error and fallback rates, retrieval recall, policy violations, and review minutes/doc.

---

## 15. Deployment and operations

### 15.1 Reference Kubernetes/GCP topology

```mermaid
flowchart LR
  LB["API Gateway / LB"] --> API["FastAPI Intake + Status Pods"]
  API --> PG["PostgreSQL + pgvector"]
  API --> GCS["GCS Objects"]
  PG --> OUT["Outbox Publisher"]
  OUT --> PUB["Pub/Sub / Work Queue"]
  PUB --> FAST["CPU Fast-Path Worker Pool"]
  PUB --> LAYOUT["CPU Layout Worker Pool"]
  PUB --> GPU["GPU OCR/Visual Worker Pool"]
  PUB --> EN["Enrichment Worker Pool"]
  FAST --> GCS
  LAYOUT --> GCS
  GPU --> GCS
  FAST --> PG
  LAYOUT --> PG
  GPU --> PG
  EN --> PG
  PUB --> PROJ["Projection Worker Pool"]
  PROJ --> ES["Elasticsearch"]
  PROJ --> FG["FalkorDB"]
  PROJ --> PG
  OT["OpenTelemetry Collector"] <---> API
  OT <---> FAST
  OT <---> LAYOUT
  OT <---> GPU
  OT <---> PROJ
```

### 15.2 Deployment characteristics

- Minimal `api` pods only validate and enqueue; avoid importing GPU packages in API images.
- `worker-fast` uses small CPU images with native parser dependencies; `worker-layout` loads Docling-capable stack; `worker-gpu` uses separate GPU node pools and controlled model artifacts.
- Autoscaling may use HPA/KEDA driven by queued pages, estimated service seconds and CPU/GPU signals—not raw queue message count alone.
- Pod resource requests/limits must be based on empirical parser memory profiles. Use dedicated worker subprocesses for unstable native parsers and liveness/timeout policies.
- Support disruption budgets, rolling/canary updates, version pinning, graceful stop, queue lease handoff, and schema compatibility.
- Use workload identity, secret manager and private connectivity; workers normally have no public internet egress.
- Object storage keys should be content-addressed, scoped by tenant/workspace and immutable for retained versions. Use lifecycle policies for temporary crops and intermediate images.

### 15.3 Capacity and cost controls

- Per-tenant daily page, OCR-page, GPU-seconds and model-token quotas, plus surge capacity policy.
- Separate infrastructure metrics from billable/chargeback business metrics; report cost per *accepted* page and cost per *published* Knowledge Product, not just raw requests.
- Estimate cost using measured worker utilization, storage growth, embedding tokens, external OCR calls and review labor. Reprocess or OCR only changed/failing pages.
- GPU workers should batch requests when model supports it, but enforce max queue delay for interactive workloads.
- Restrict model download and package installation to build time or controlled artifact cache, not production request time.

### 15.4 Availability and disaster recovery

- Rebuild Elasticsearch projections from canonical Postgres + immutable artifacts; rebuild FalkorDB derived assertions from approved assertion ledger when feasible, while preserving graph-authoritative business facts as backed up separately.
- Back up PostgreSQL and authoritative FalkorDB data; test restores and manifest consistency.
- Queue is at-least-once and not durable source truth; all jobs and outbox events persist in Postgres.
- On object storage outage: reject new source uploads or queue safely; never indicate successful durable acceptance until source writes are verified.
- Recovery should replay projection generations and verify counts/checksums before activating a release.

---

## 16. Observability, quality, and evaluation

### 16.1 OpenTelemetry traces

Example span tree:

```text
ingest.request
  ├── intake.validate
  ├── source.persist
  ├── job.enqueue
  └── worker.process
       ├── preflight.profile
       ├── parser.route
       ├── parser.execute
       │    ├── parser.page_batch[0]
       │    └── parser.fallback
       ├── cir.normalize
       ├── chunker.execute
       ├── quality.validate
       ├── artifact.persist
       ├── embedding.batch
       └── index.publish
            ├── postgres.upsert
            ├── elasticsearch.bulk
            ├── falkordb.upsert
            └── release.gate
```

Avoid one span per token/word; sample page-level spans for large documents and retain aggregate metrics. Use low-cardinality dimensions (`parser_engine`, `document_class`, `stage`, `status`, `policy_tier`, `worker_pool`) for metrics. Tenant IDs, document IDs and source filenames should not be high-cardinality metric labels; where tracing requires IDs, apply retention and sensitivity policy.

### 16.2 Metric specification

| Metric | Type | Dimensions (bounded) |
|---|---|---|
| `doc_ingest_total` | Counter | outcome, document_class |
| `doc_pages_processed_total` | Counter | parser, worker_pool |
| `doc_stage_duration_seconds` | Histogram | stage, parser, document_class |
| `doc_queue_wait_seconds` | Histogram | queue, priority |
| `doc_processing_seconds_per_page` | Histogram | parser, complexity_bucket |
| `doc_parser_fallback_total` | Counter | primary, fallback, reason |
| `doc_ocr_pages_total` | Counter | engine, language_group |
| `doc_quality_findings_total` | Counter | severity, finding_type |
| `doc_partial_processing_total` | Counter | reason |
| `doc_chunk_token_count` | Histogram | chunk_profile, kind |
| `doc_evidence_coverage_ratio` | Histogram | parser, document_class |
| `doc_projection_lag_seconds` | Histogram | store, generation_state |
| `doc_index_generation_ready_total` | Counter | target, status |
| `doc_cost_estimate_usd` | Histogram | stage, worker_pool |
| `retrieval_duration_seconds` | Histogram | query_class, strategy |
| `retrieval_empty_due_to_filter_total` | Counter | store, filter_class |
| `doc_policy_denied_total` | Counter | operation, policy_stage |

### 16.3 Quality dimensions and gates

Separate scores; **do not aggregate everything into one misleading confidence value**:

1. Text integrity: character/word completeness, replacement characters, broken Unicode, duplicate OCR layers.
2. Layout/order: reading order agreement and structural adjacency.
3. Tables: cell existence, merged-cell spans, header linkage, numeric exact match and units.
4. Evidence: percentage of blocks/chunks with valid source regions and resolvable page coordinates.
5. Chunk utility: coherence, correct atomicity, token-budget compliance and parent mapping.
6. Business extraction: field-level precision/recall, unsupported assertion rate, human correction rate.
7. Retrieval: Recall@k, nDCG@k, answer groundedness, correct citation, false-negatives due to ACL filters.
8. Operations: latency, cost, retries, partial-result and escalation rates.

A **quality gate** is a profile-specific policy, e.g. strict regulatory products require evidence for 100% of published obligations, accepted or reviewed critical tables, no unresolved high-severity parse warnings, and human approval for ambiguous exception extraction. The exact thresholds must be validated with business owners and recorded in the product release manifest.

### 16.4 Gold dataset design

Build a fixture suite with **150–300 representative PDFs** for the first serious benchmark, including:

- Clean text-native policy documents; long legal clauses with nested exceptions.
- Financial reports: merged headers, negative values, footnotes, multiple currency/scale units and cross-page tables.
- Two- and three-column reports, sidebars and floating captions.
- Scanned/rotated/noisy documents, with multi-language OCR as applicable.
- PDF forms, images, diagrams, charts, formula-heavy technical reports.
- PDFs with embedded malicious instructions, malformed objects, suspicious links, encryption, enormous page sizes and corrupted fonts.
- Different ACL/tenancy contexts and multiple versions of the same policy.

For each fixture, annotate enough ground truth to measure extraction, tables, section hierarchy, evidence bounding boxes and retrieval tasks. Maintain copyright/security permissions for benchmark files.

### 16.5 Evaluation matrix

Run reproducible experiments across:

```text
parser: PyMuPDF4LLM | Docling | Marker | MinerU | approved managed OCR
chunker: fixed | hierarchy | hybrid | hybrid+semantic | rule-aware | table-aware
retrieval: BM25 | pgvector | BM25+pgvector | +graph | +reranker
profile: fast | balanced | high_accuracy
```

Do not run the full Cartesian product blindly. Eliminate incompatible/expensive variants early using staged screening. Use paired evaluations on the same inputs and bootstrap confidence intervals or other appropriate uncertainty estimates. The primary selection criterion is **business task correctness subject to cost/latency/security constraints**, not vendor benchmark scores.

### 16.6 End-to-end golden questions

Examples of evaluation tasks:

- Find a 24-hour reporting obligation **and its 72-hour exception** (fictional test policy).
- Return financial `FY2026 revenue` with exact unit/period and cite cells.
- Identify changed clauses between versions and list impacted verified graph entities.
- Retrieve the right definition among multiple sections with identical terminology.
- Return **no result** for a document unavailable to the caller, even if graph edges or parent context connect it to an authorized document.
- Show correct PDF bounding box when clicking a cited chunk.

For each test, score exact fact correctness, evidence validity, unauthorized disclosures, source-version correctness, and latency under controlled load.

---

## 17. Error taxonomy and resilience

### 17.1 Typed exceptions

```text
DocumentSDKError
  ├── InputValidationError
  │    ├── UnsupportedFormatError
  │    ├── FileTooLargeError
  │    ├── EncryptedDocumentError
  │    └── MalformedDocumentError
  ├── SecurityPolicyError
  │    ├── UnauthorizedSourceError
  │    └── ExternalProcessingForbiddenError
  ├── ResourceLimitError
  │    ├── PageLimitExceededError
  │    ├── MemoryBudgetExceededError
  │    └── DeadlineExceededError
  ├── ParserError
  │    ├── EngineUnavailableError
  │    ├── OCRUnavailableError
  │    └── ExtractionQualityError
  ├── ChunkingError
  │    ├── StructuralInvariantError
  │    └── TokenizerMismatchError
  ├── ArtifactError
  │    └── EvidenceIntegrityError
  └── AdapterError
       ├── StorageUnavailableError
       ├── IndexProjectionError
       └── PolicyEnforcementUnavailableError
```

Every error has a stable machine code, safe user message, diagnostic trace ID, retryable boolean, stage, document/page context (where permitted), and sanitized detailed exception for authorized operators.

### 17.2 Fault table

| Failure | Retry? | Result semantics | Recovery |
|---|---|---|---|
| Invalid/corrupt PDF | Usually no | Failed / possibly partial | Quarantine, request new file |
| Parser native crash | Yes, bounded | Retry or partial | Isolated subprocess, alternate approved engine |
| OCR provider throttling | Yes | Queued/retry | Backoff, rate limiter |
| Deadline exceeded | Depends | Partial or failed | Checkpoint and resume |
| Some pages unreadable | Not blindly | Partial, review-required | Page-level fallback/review |
| Elasticsearch unavailable | Yes | Parse complete, not searchable | Replay projection |
| FalkorDB unavailable | Yes | Graph generation not ready | Replay projection; block graph-required release |
| Embedding model mismatch | No until fixed | Generation invalid | Reconfigure/re-embed |
| Policy engine unavailable | No unsafe fallback | Deny/retry later | Restore PDP before access |
| Schema migration conflict | No until fixed | Version incompatible | Run explicit schema migration |
| User cancels | No | Cancelled | Release resources, revoke temp artifacts |

### 17.3 Resilience rules

- Parser fallback is not a generic catch-all; classify errors and only retry alternative approved engines when useful.
- A source with zero valid pages must not return `succeeded` with an empty ChunkSet unless an explicit valid-empty document type exists.
- A `partial` response includes exact successful/failed pages, reasons and evidence scopes. Strict products reject partial results.
- Failure to write one index does not corrupt previously published generations; old release remains active.
- Negative results from policy denial must not trigger broader unscoped search.
- Preserve failure artifacts only under retention and security policy; avoid persisting sensitive raw diagnostic output.

---

## 18. Configuration and feature flags

### 18.1 Example validated configuration

```yaml
sdk:
  schema_version: "1"
  default_profile: "balanced"
  allow_network: false
  deterministic: true
  max_source_bytes: 209715200
  max_pages: 2000
  max_parallel_pages: 4
  memory_budget_mb: 1024
  temp_dir_policy: "isolated_ephemeral"

preflight:
  sample_pages_max: 8
  deadline_seconds: 15
  min_native_text_suitability_for_fast_path: 0.90
  max_complexity_for_fast_path: 0.25

parsing:
  strategy: auto
  default_structured_engine: docling
  fast_engine: pymupdf4llm
  allowed_engines: [docling, pymupdf4llm]
  max_fallback_attempts: 1
  max_fallback_pages: 5
  ocr_enabled: false
  managed_external_ocr_enabled: false
  preserve_page_images: false

chunking:
  strategy: hybrid
  profile: regulatory_policy
  tokenizer_id: "<explicit-embedding-model-tokenizer>"
  target_tokens: 350
  soft_max_tokens: 650
  overlap_tokens: 40
  parent_target_tokens: 1400
  semantic_splitting: false
  contextual_prefix: true
  table_header_repeat: true
  protected_atomic_groups: true

embedding:
  enabled: false
  provider: null
  model_id: null
  dimensions: null
  batch_token_budget: 8000

quality:
  provenance_required: true
  deny_critical_missing_evidence: true
  strict_tables: true
  allow_partial_for_preview: true
  allow_partial_for_publication: false

observability:
  tracing_enabled: true
  log_source_text: false
  metric_document_ids: false

processing_budget:
  default_deadline_seconds: 30
  max_ocr_pages: 10
  max_model_tokens: 25000
  max_external_cost_usd: 0.0
```

This is a **proposed SDK-owned YAML schema**, not a claimed configuration format from Docling/PyMuPDF. The coding assistant must implement schema validation and document every field. Reject unknown security-critical config keys, conflicting settings and incompatible tokenizers at startup.

### 18.2 Configuration precedence

`hard platform policy > host runtime security config > tenant/workspace approved profile > explicit API options > SDK defaults`. The caller cannot override quotas, security labels, egress deny, tenant identity or parser allowlists by supplying request YAML. Record effective config digest with every output.

### 18.3 Feature flags

| Flag | Default | Rollout rule |
|---|---|---|
| `parser_router_v2` | Off | Shadow evaluation, then canary |
| `page_level_fallback` | On where supported | Reconciliation golden tests |
| `semantic_chunking` | Off | Retrieval uplift + cost evidence |
| `late_chunking` | Off | Approved encoder and benchmark |
| `rule_extraction` | Off | Domain owner approval |
| `visual_captioning` | Off | Model/data classification review |
| `elasticsearch_vector_projection` | Off | Compare against pgvector baseline |
| `cross_document_entity_resolution` | Off | Domain ontology + ACL verification |
| `incremental_reparse` | Off in MVP | Diff correctness and cache invalidation |

## 19. API and event contracts

### 19.1 Optional hosted REST service

The standalone SDK does not require REST; host can deploy a thin API that translates authenticated requests into SDK operations. OpenAPI 3.1 contract is required and kept in sync with Pydantic schema exports.

| Method | Endpoint | Behavior | Return |
|---|---|---|---|
| `POST` | `/v1/documents/ingestions` | Validate artifact reference, create job, idempotency | `202`, job ID and links |
| `GET` | `/v1/documents/ingestions/{job_id}` | Get stage, progress, warnings and review requirements | `200` |
| `POST` | `/v1/documents/ingestions/{job_id}/cancel` | Request cancellation | `202` |
| `GET` | `/v1/documents/{document_id}/versions` | List authorized source/parse generations | `200` |
| `GET` | `/v1/documents/{document_id}/artifacts/{generation_id}` | Fetch authorized metadata/CIR manifest, not necessarily all bytes | `200` |
| `GET` | `/v1/documents/{document_id}/chunks` | Page through authorized chunks for a pinned generation | `200` |
| `GET` | `/v1/documents/{document_id}/quality` | Quality findings and page statuses | `200` |
| `POST` | `/v1/documents/{document_id}/rechunk` | Create chunk generation without reparsing | `202` |
| `POST` | `/v1/documents/{document_id}/reprocess` | Explicitly rerun selected stages, with config | `202` |
| `GET` | `/v1/parser-capabilities` | Return approved capabilities, not internal credentials | `200` |
| `GET` | `/v1/documents/{document_id}/evidence/{evidence_id}` | Retrieve exact authorized page/region or signed short-lived crop URL | `200` |
| `GET` | `/health/live` | Liveness without store dependency | `200` |
| `GET` | `/health/ready` | Readiness including essential dependencies | `200/503` |

For large file upload, prefer the host's approved direct-to-object-storage flow (pre-signed narrowly scoped upload URL or equivalent) followed by an artifact-reference ingestion request. Never accept arbitrary public URLs and fetch them from worker without SSRF controls.

### 19.2 Intake request/response

```http
POST /v1/documents/ingestions
Authorization: Bearer <workload-or-user-token>
Idempotency-Key: f6f3ea39-c19d-4794-9c75-6a817bfae104
Content-Type: application/json

{
  "workspace_id": "risk-workspace",
  "source_artifact_id": "artifact:tenant-a:sha256:...",
  "document_type_hint": "regulatory_policy",
  "pipeline_profile": "balanced",
  "chunking_profile": "regulatory_policy",
  "publish_intent": "draft_only",
  "requested_capabilities": ["parse", "chunk", "quality"]
}
```

```json
{
  "job_id": "job-a16c",
  "status": "queued",
  "idempotency_replayed": false,
  "status_url": "/v1/documents/ingestions/job-a16c",
  "request_id": "req-b71a"
}
```

`tenant_id`, actor and security context are resolved from verified credentials/host policy, not accepted from an untrusted body field. `publish_intent=draft_only` never causes automatic publication; any `publish` action belongs to Knowledge Manager's governed product workflow.

### 19.3 Job status response

```json
{
  "job_id": "job-a16c",
  "state": "quality_check",
  "progress": {
    "pages_total": 120,
    "pages_completed": 102,
    "pages_accepted": 99,
    "pages_review_required": 3,
    "stage": "quality_check"
  },
  "parser_decisions": [
    {"range": [1, 100], "engine": "pymupdf4llm", "reason": "text_native"},
    {"range": [101, 120], "engine": "docling", "reason": "layout_complexity"}
  ],
  "quality": {"status": "pending", "high_severity_findings": 0},
  "result_generation_id": null,
  "retry_after_seconds": 5
}
```

### 19.4 Event envelope (at-least-once)

```json
{
  "event_id": "evt-sha256-stable-identity",
  "event_type": "document.chunk_generation.ready.v1",
  "event_version": "1.0",
  "occurred_at": "2026-11-19T08:00:00Z",
  "tenant_id": "tenant-a",
  "workspace_id": "risk-workspace",
  "aggregate_id": "doc-a16c",
  "generation_id": "chunk-gen-2",
  "causation_id": "job-a16c",
  "correlation_id": "req-b71a",
  "traceparent": "00-...",
  "artifact_manifest_uri": "gcs://.../manifest.json",
  "source_policy_ref": "src-policy-112",
  "schema_ref": "schemas/events.v1.schema.json"
}
```

Keep events *small*: the envelope contains metadata and pointers, **not raw PDF bytes, whole text or embeddings**. Event payload validation and idempotent processing are required. Include source policy references but do not interpret them as authorization grants.

### 19.5 Event types

```text
document.ingestion.accepted.v1
document.profile.completed.v1
document.parsing.partial.v1
document.parsing.completed.v1
document.chunk_generation.ready.v1
document.quality.review_required.v1
document.assertions.candidates_ready.v1
document.index_projection.requested.v1
document.index_projection.ready.v1
document.index_projection.failed.v1
document.release_eligible.v1
document.processing.failed.v1
document.processing.cancelled.v1
document.source.superseded.v1
document.source.deleted.v1
```

### 19.6 CLI interface

The SDK CLI should work without a service:

```bash
kdocs inspect ./policy.pdf --output profile.json
kdocs parse ./policy.pdf --engine auto --output document.json
kdocs chunk ./document.json --profile regulatory_policy --output chunks.json
kdocs process ./policy.pdf --config knowledge_docs.yaml --out-dir artifacts/
kdocs validate ./document.json --strict
kdocs benchmark --fixtures benchmarks/fixtures_manifest.yaml --report benchmark.json
kdocs engines list --approved-only
```

CLI stdout is machine-readable when `--output -` is selected; logging and progress go to stderr. Exit codes distinguish invalid input, policy denied, transient processing error, partial results, and success. `--help` must document resource/network side effects.

---

## 20. Implementation milestones and acceptance tests

The coding assistant should implement **incrementally**, running tests after every milestone. Do not scaffold every external integration before a working standalone SDK exists.

### M0 — Foundation and contracts (first shippable base)

**Build**
- Repository, build system, Python 3.11+ CI matrix and lint/type/test tooling.
- Core Pydantic models and schema exports; configuration validation; error taxonomy.
- `DocumentClient` sync/async facades, in-memory adapters, parser/strategy registry.
- A tiny baseline PDF parser adapter sufficient to exercise the canonical contract; avoid loading heavyweight model stacks in tests.
- Deterministic IDs, artifact export and input limits.
- `README.md`, `AGENTS.md`, sample usage, version policy, dependency/license inventory.

**Acceptance**
- `pip install -e .` works offline once dependencies are provisioned.
- Core import does not import Docling/Marker/PyMuPDF or contact network.
- A 1–5 page PDF parses into canonical pages/blocks/evidence with predictable IDs.
- Sync and async APIs return schema-valid results; invalid input produces typed errors.
- Test suite has no database/cloud dependencies; SDK can run with fake parser.

### M1 — Structured parsing and provenance

**Build**
- Approved Docling and PyMuPDF4LLM adapters, capability registry and preflight profile.
- Router baseline with reason codes; page coordinate normalization and source fidelity.
- CIR normalizers for headings, paragraphs, lists, footers and tables, page order.
- Golden fixtures for digital and complex layout PDFs; parser warnings and quality checks.
- Parser subprocess isolation where needed; timing instrumentation.

**Acceptance**
- Every produced non-synthetic chunk maps to original page/region evidence.
- Repeated parse on same pinned engine/config reproduces identical content digests and block IDs (modulo explicitly non-deterministic metadata such as wall-clock execution timestamps).
- Golden page number and bounding-box tests pass.
- Missing parser dependency fails with useful error, not import crash at SDK initialization.
- Fast versus structured path selected by visible, testable profile rules.

### M2 — Hybrid chunking and user-visible evidence

**Build**
- Hierarchical packer, tokenizer-aware budgets, table slicer and rule/exception grouping.
- Parent-child pointers, heading ancestry, evidence maps and contextual prefixes.
- Chunk generation hashes, re-chunk without re-parse, default profiles and validation.
- Visual citation helper returning exact region box for source PDF viewer.
- Chunking golden tests: no orphaned header/units/exception, stable IDs.

**Acceptance**
- Fixed-token baseline and hybrid chunker both run on test corpus.
- All protected groups preserved or explicitly linked and flagged.
- Parent expansion respects security boundary metadata.
- Table slicing preserves raw numeric strings, units and period headers.
- Markdown export is clearly documented as lossy; CIR JSON is lossless contract.

### M3 — Hosted ingestion and operational safety

**Build**
- FastAPI adapter, GCS artifact adapter, ingestion ledger and transactional outbox.
- Background worker pools, retries, leases, idempotency, checkpoints and cancellation.
- Tenant/workspace host context, security/quotas, egress restrictions and audit.
- Health probes, readiness, OTel traces, metrics, structured logs and charts.
- Docker/Kubernetes/Helm deployment and resource classes.

**Acceptance**
- Duplicate ingestion key produces one logical job and immutable artifact generation.
- Kill/restart a worker during parsing; job eventually resumes/retries without duplicate active data.
- Policy-denied files never enter processing workers or object projection.
- OCR/model service unavailability never silently publishes an invalid result.
- Tenant and authorization negative tests pass across all API endpoints.

### M4 — PostgreSQL/pgvector, Elasticsearch, FalkorDB integration

**Build**
- Postgres schema + migrations + chunk/embedding storage adapters.
- Elasticsearch lexical projection and bulk indexer with generation-aware alias strategy.
- FalkorDB candidate/verified assertion projection against existing graph ontology.
- Outbox projection consumers, reconciliation, readiness and release-gate status.
- Host retrieval orchestration using Elasticsearch BM25 and pgvector, optional graph traversal, RRF, evidence expansion.

**Acceptance**
- A pinned release returns evidence-consistent results across available stores.
- Projection worker interruption is recoverable and idempotent.
- Old published release stays active when one new projection fails.
- Strict tenant/product/source ACL tests pass under search, graph traversal and parent expansion.
- Vector dimension/model mismatch is detected before index commit.

### M5 — High-accuracy fallback and enrichment

**Build**
- Page-level parser escalation to approved OCR/visual engine, optional Marker/MinerU.
- Table confidence and reconciliation; complex scans and multilingual evaluation.
- Optional entity/rule/temporal enrichment with candidate assertions and review states.
- Semantic and contextual chunker experiments under feature flags.
- Version diffs and selective reprocessing/reindexing where justified.

**Acceptance**
- Measurable quality uplift versus M2 on the difficult corpus at acceptable cost.
- Critical candidate assertions link to valid source evidence and explicit approval state.
- External model processing never activates without allowlist and privacy policy.
- Reprocess only changed/failed pages where engine and cache semantics allow it.

### M6 — Production hardening and reusable release

**Build**
- Full performance matrix, load/chaos/security and dependency/license audits.
- Cost, utilization and p95/p99 SLO dashboards; runbooks and on-call alerts.
- Stable Python wheel, internal package registry, semver migration guide and SDK examples.
- Version compatibility tests, consumer-driven contracts, canary rollout and rollback.
- Multi-project example: one independent app consumes SDK with no Knowledge Manager imports.

**Acceptance**
- Enterprise architectural/security review signed off.
- SDK install/use tested in two independent consumer apps.
- Published APIs and JSON schemas pass backward-compatibility checks.
- All mandatory benchmark/latency/policy gates pass for target workload.
- Product and documentation are sufficient for a new developer to extend a parser or chunker without touching SDK core.

### 20.1 Mandatory automated tests

| Test group | Must include | Gate |
|---|---|---|
| Unit | Models, hash stability, tokenizer limits, hierarchy, bbox transforms | CI required |
| Contract | Parser/Chunker protocols, Pydantic/JSON/OpenAPI schemas | CI required |
| Golden | Text, tables, multicolumn, scanned and cross-page clauses | CI required |
| Property-based | Unicode/offsets/bbox valid, chunk source coverage, sort/order invariants | CI required |
| Regression | Old fixtures unchanged after engine/chunker bump unless explicit migration | CI required |
| Security | ACL leakage, prompt injection, SSRF, path traversal, bad PDFs | CI required |
| Integration | PG, pgvector, Elasticsearch, FalkorDB, GCS via test containers/mocks | PR or nightly |
| Chaos | Worker kill, database outage, duplicate queue, timeout, DLQ | Nightly/release |
| Performance | p50/p95/p99 and resource profiles for benchmark classes | Release gate |
| Business E2E | Correct clause, exception, table value and evidence citations | Release gate |

### 20.2 Test commands / developer ergonomics

```bash
# Proposed commands; coding assistant must implement in pyproject/Makefile.
make lint             # Ruff etc.
make typecheck        # mypy or pyright
make test-unit
make test-contract
make test-integration
make test-security
make benchmark-smoke
make benchmark-full  # explicit opt-in, may use substantial compute
make build
```

**Coverage target:** 90%+ line coverage for pure core logic is a starting gate, but do not treat coverage as a substitute for golden correctness and adversarial tests. Report coverage separately for adapters/native libraries.

### 20.3 Detailed product acceptance criteria

An accepted enterprise SDK release must demonstrate:

- **Reuse:** same wheel processes document fixtures in a standalone script and within Knowledge Manager.
- **Latency:** budgeted warm fast-path document scenario meets measured p95 target on declared reference hardware and workload; fallback path is separately measured.
- **Accuracy:** hybrid chunking retrieval benchmark improves or is non-inferior to fixed-token baseline within agreed latency/cost; no regression on critical tables and exceptions.
- **Traceability:** 100% of published critical facts/chunks have resolvable source version, page and region; cited viewer highlights match gold evidence.
- **Governance:** no unauthorized document or inference context appears through any search/index/graph/parent path under automated tests.
- **Robustness:** repeated, interrupted and out-of-order ingestion creates no mixed active release or duplicate logical documents.
- **Operability:** per-stage time, parser decisions, queue delays and cost are visible without sensitive content disclosure.
- **Extensibility:** new parser plugin and new chunking strategy can be implemented without changes to core caller API.

---

## 21. Coding-assistant execution instructions

### 21.1 Starting prompt for coding assistant

> **Task:** Implement the enterprise Document Intelligence SDK described in `knowledge-document-intelligence-sdk-spec.md`. This is a reusable Python SDK with optional service and Knowledge Manager adapters. Do not bypass the canonical document model. Preserve evidence, tenant/source policies, and idempotent versioned generations. Begin by reading the full specification and any existing project `README.md`, `AGENTS.md`, and architecture ADRs. Inspect the existing repository before modifying code; adapt to its conventions. Implement **M0 only first**, run its tests, record what passed/failed, then proceed to M1 and subsequent milestones in order. Build with Python 3.11+, typed Pydantic contracts, clean dependency injection, and documented minimal examples. Never silently invent source text, citations, confidence or benchmark numbers. Make performance visible in every stage. If a requirement is ambiguous, select the safest minimal reversible implementation, record an ADR, and include a regression test.

### 21.2 Concrete first implementation batch

1. Audit existing repo and dependency stack. Report existing services/code to reuse rather than overwriting modules.
2. Create repository skeleton, build/test/lint config, `src/knowledge_docs/__init__.py` stable exports.
3. Implement source object and `ProcessingContext` with strict constructors; ensure tenant/source policy cannot be derived from PDF metadata.
4. Implement CIR Pydantic models with JSON serialization, validations, page coordinate rules and provenance invariants.
5. Implement hash/canonicalization functions with fixtures verifying stable IDs.
6. Implement capability registry, parser protocol, fake parser, and one approved real PDF parser with optional extras.
7. Implement `DocumentClient.parse`, `chunk`, `process`, `aprocess` with typed errors and deadlines.
8. Implement basic hierarchical + token-aware chunker and evidence mappings.
9. Implement CLI `inspect`, `parse`, `chunk`, `validate`, `process` with machine-readable output.
10. Add docs and examples showing the SDK used with no DB/cloud/LLM.
11. Write/run unit and golden tests, ensure no network calls or heavy parser imports at package import time.
12. Produce a milestone report: changed files, key design choices, test output, unresolved risks, next steps.

### 21.3 Guardrails for generated code

- **Never** replace the user's existing enterprise Elasticsearch/pgvector/FalkorDB with a new vector DB.
- **Never** hard-code Knowledge Manager-specific domain/entity IDs in core.
- **Never** store/retrieve a chunk without a stable source version and policy reference in hosted mode.
- **Never** use ad hoc `split(' ')` token counts as final budgets; use configured tokenizer or explicit conservative fallback.
- **Never** use unguarded remote model calls; local/offline and classification policies apply.
- **Never** fabricate PDF citations/region coordinates or downstream graph edges.
- **Never** automatically promote unverified rule extraction to authoritative graph business facts.
- **Never** permit retrieval via a less-restricted index than the source/product access policy.
- **Never** catch broad exceptions and return success/empty chunks without typed partial failure.
- **Never** assume all PDF pages can share an identical parser/quality profile.
- **Never** make the SDK import a cloud storage client as a core requirement.
- **Never** deploy version upgrades that silently change embedding dimensions, chunk IDs or CIR schema semantics.
- **Always** test changes locally and explain any environment/test execution limitation honestly.

### 21.4 Required milestone report template

```markdown
# M<n> Implementation Report

## Implemented
- [specific modules and APIs]

## Files changed
- [file path and reason]

## Architectural decisions
- [ADR references, rationale]

## Tests executed
- Command:
- Results:
- Known skips/failures:

## Performance results
- Hardware / environment:
- Dataset / fixture ID:
- Stage p50/p95/p99:
- Memory peak:
- Cost/volume proxy:

## Security and schema impact
- [tenant/ABAC/citation/compatibility issues]

## Remaining work and risks
- [actionable list]
```

### 21.5 Definition of done for any pull request

- Typed API contract and schema update, if applicable.
- Deterministic unit test and at least one realistic fixture for behavioral changes.
- Security test when data, policy, source fetching, or access behavior changes.
- Latency/cost benchmark delta when parser, tokenizer, model, chunking or storage operation changes.
- Dependency/license review on new parser/model packages.
- Documentation, examples and ADR for material behavioral decisions.
- No test regressions, no unexplained new external calls, no unbounded memory/concurrency.

---

## 22. Risks, ADRs, and unresolved choices

### 22.1 Decision records to create

| ADR | Decision topic | Proposed default | Trigger to revisit |
|---|---|---|---|
| ADR-001 | Canonical CIR ownership | SDK-owned versioned JSON/Pydantic schema | Multiple consumers need alternative standard |
| ADR-002 | Default structured parser | Docling | Golden tests show unacceptable latency/accuracy |
| ADR-003 | Fast PDF path | PyMuPDF4LLM (license permitting) | Legal review / benchmark result |
| ADR-004 | Advanced OCR fallback | Approved local model or managed engine by policy | Better accuracy/performance or residency requirements |
| ADR-005 | Chunk defaults | Structure-first with table/rule protection | Retrieval benchmark demonstrates improvement |
| ADR-006 | Primary embedding store | PostgreSQL pgvector | Evidence favors ES-native vector search |
| ADR-007 | Lexical search | Elasticsearch | Change in enterprise search stack |
| ADR-008 | Authoritative semantic graph | Existing FalkorDB knowledge graph | Ontology/product model change |
| ADR-009 | Projection consistency | Generation-pinned manifest + outbox | Stronger cross-system consistency needed |
| ADR-010 | Worker isolation | CPU and GPU pools with subprocess boundaries | Measured memory/latency cost tradeoff |
| ADR-011 | External model policy | Default deny; explicit approved host policy | Enterprise security/risk approval |
| ADR-012 | SDK distribution | Pure core wheel + opt-in extras/adapters | Dependency packaging conflicts |

### 22.2 Known trade-offs

- **Docling-first vs fast-first:** Docling can give richer structure, while a fast-native-first route can reduce costs for simple PDFs. Use document-class-aware benchmarks rather than blanket preference.
- **Page-level fallbacks:** cheaper than whole-doc fallback in many cases, but reconciliation, paragraph continuity and table spans can be difficult; benchmark quality of merged outputs.
- **Source text versus enriched context:** extra context helps retrieval but may introduce hallucinated statements. Label derived context and maintain source-only display text.
- **Parent-child indexing:** greater context fidelity but more reads and permission-sensitive expansions; index only what measurements justify.
- **Separate pgvector and Elasticsearch:** avoids duplicating embeddings by default but introduces cross-store query coordination. Benchmark tail latency and operational overhead.
- **Structured assertion extraction:** high-value for policy workflows but can have serious consequences if false; require evidence and review gates.
- **Aggressive caching:** reduces cost/latency but can violate ACL/deletion policy unless cache key includes source/policy/version semantics.
- **Immutable releases:** improves audit and rollback but costs storage. Apply tiered retention without destroying required evidence.

### 22.3 Open choices needing implementation-time validation

1. Which parser/model versions pass the enterprise security and license review?
2. What are the typical PDF sizes, document types, languages and concurrency levels?
3. What exact GPU/CPU reference instance types are approved and available?
4. Which embedding model/tokenizer and dimensionality are already in production?
5. Does Knowledge Manager enforce policies via OPA (or another policy engine)? Use the existing solution and define its decision interface.
6. What are the existing FalkorDB ontology labels, graph namespaces and authoritative entity IDs?
7. What are the business-specific quality-gate thresholds for regulated products?
8. Which artifacts may cross regions/tenants, and which require redaction before embeddings?
9. What is the allowed async workflow engine (existing Temporal, Pub/Sub, other)?
10. Does the enterprise currently need PDF only or a multi-format document abstraction from day one?

**Do not block M0–M2 on these decisions**. Use plugin contracts and safe defaults, then integrate the answers without breaking core schema.

---

## 23. Authoritative references

The links below ground current public interfaces and help maintainers verify SDK adapters against the exact versions adopted. External library APIs, licensing, and performance change over time; pin tested versions and check official documentation before implementation. No end-to-end benchmark has been run as part of writing this specification.

1. **Docling — official chunking concepts:** https://docling-project.github.io/docling/concepts/chunking/
2. **Docling — project and API docs:** https://docling-project.github.io/docling/ and https://github.com/docling-project/docling
3. **PyMuPDF4LLM — documented API:** https://pymupdf.readthedocs.io/en/latest/pymupdf4llm/api.html
4. **PyMuPDF4LLM — source/README:** https://github.com/pymupdf/pymupdf4llm
5. **Marker — code, models, restrictions and examples:** https://github.com/datalab-to/marker
6. **MinerU — official project documentation:** https://opendatalab.github.io/MinerU/ and https://github.com/opendatalab/MinerU
7. **pgvector — exact/approximate search and filtering:** https://github.com/pgvector/pgvector
8. **Elasticsearch — reciprocal rank fusion:** https://www.elastic.co/docs/reference/elasticsearch/rest-apis/reciprocal-rank-fusion
9. **Elasticsearch — retrievers overview:** https://www.elastic.co/docs/solutions/search/retrievers-overview
10. **FalkorDB — project/docs:** https://github.com/FalkorDB/docs
11. **OpenTelemetry — semantic conventions:** https://opentelemetry.io/docs/specs/semconv/
12. **OpenTelemetry GenAI semantic conventions:** https://github.com/open-telemetry/semantic-conventions-genai

---

## Final engineering principle

> **Make parsing a pluggable and measurable compiler front-end for business knowledge.** The SDK normalizes untrusted documents into a typed, source-grounded intermediate representation; chunkers create multiple reproducible retrieval views; optional enrichment creates reviewable knowledge candidates; and host integrations project authorized artifacts into PostgreSQL/pgvector, Elasticsearch and FalkorDB. Performance optimization must never compromise provenance, tenant isolation, publication consistency or business correctness.

**Recommended starting sequence:** M0 SDK contracts → M1 Docling/PyMuPDF adapters → M2 hybrid chunking → M3 hosted workers → M4 existing store integrations → M5 advanced OCR/enrichment → M6 scale/security release.
