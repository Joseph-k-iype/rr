# Knowledge Manager — Enterprise Architecture & Implementation Blueprint

**Version:** 1.0 | **Date:** 2026-11-17 | **Status:** Proposed architecture / build specification, not implemented software.

## Purpose

Build a workspace-centric enterprise Knowledge Manager. Users create isolated workspaces, obtain domain/subdomain and source permissions, ingest or connect documents, transform them into graph/vector/semantic knowledge assets, apply ontologies and inference, assemble governed knowledge products, publish immutable versions through quality and approval gates, and share those products through a policy-controlled catalog and knowledge-serving APIs.

A **workspace** is the isolation and authoring boundary. A **domain** is the business-governance boundary. A **knowledge product** is the owned, versioned consumption boundary. A **product release** is an immutable content/contract snapshot. A **policy revision** is separately versioned and may be revoked without republishing content. A **consumer** accesses only approved published interfaces; never another workspace's storage directly.

## Start here (for a coding agent)

1. Read `agent/AGENTS.md` completely. Treat security invariants and acceptance tests as non-negotiable.
2. Read `docs/00-one-page-operating-model.md`, `docs/01-system-architecture.md`, and `docs/02-domain-model.md`.
3. Implement **Milestone M0**, then M1 in `docs/12-delivery-plan.md`, one vertical slice at a time; do not attempt the whole system in one generation.
4. Follow `docs/10-api-contracts.md` and `specs/openapi.yaml`. Update both if endpoints change.
5. Use `docs/11-testing-and-threat-model.md` as the definition of done.
6. Record deviations in `docs/13-architecture-decisions.md`. Never silently weaken tenant isolation or policy checks.

## Documentation map

| File | What it specifies |
|---|---|
| `docs/00-one-page-operating-model.md` | Executive operating model, responsibilities and lifecycle |
| `docs/01-system-architecture.md` | Control/build/product/serve planes; service and event boundaries |
| `docs/02-domain-model.md` | Canonical aggregates, relationships, invariants, state machines |
| `docs/03-workspace-and-storage.md` | Workspace provision, GCS layout, identity, isolation, deletion |
| `docs/04-identity-policy-governance.md` | Domain/product entitlements, RBAC, ABAC, policy authorship, PDP/PEP |
| `docs/05-ingestion-and-knowledge-build.md` | Connectors, ingestion, provenance, ontology, extraction, inference |
| `docs/06-product-publishing-and-catalog.md` | Releases, gates, approvals, serving promotion, catalog, contracts |
| `docs/07-knowledge-exchange-and-serving.md` | Cross-product reuse, federated/materialized/derived modes, retrieval |
| `docs/08-end-to-end-workflows.md` | Detailed workflows incl. success/failure/compensation paths |
| `docs/09-data-and-event-design.md` | PostgreSQL model, outbox, events, indexing and consistency |
| `docs/10-api-contracts.md` | REST conventions, endpoint contracts, samples, errors |
| `docs/11-testing-and-threat-model.md` | Abuse cases, test suite, resilience, SLOs and security gates |
| `docs/12-delivery-plan.md` | Implementable milestones, dependencies, tickets, DoD |
| `docs/13-architecture-decisions.md` | Default decisions, trade-offs and unresolved ADRs |
| `docs/14-ui-screens-and-user-journeys.md` | User stories, pages and authorization-sensitive UX |
| `agent/AGENTS.md` | Coding-agent execution instructions |
| `specs/openapi.yaml` | Initial executable API skeleton; expand incrementally |
| `examples/*.json` | Example resource and policy payloads |

## Out-of-scope for first release

Automatic unrestricted cross-domain graph federation; arbitrary Python execution in user workflows; AI-generated policies directly applied without review; a universal enterprise ontology; mandatory deployment of both RDF and LPG engines; confidential data export into consumer workspaces by default; automatic broad permissions for workspace owners.

## Quality bar

All IDs are opaque UUIDs/ULIDs (examples use readable IDs). The server derives authorization scope from verified identities and grant records. Tenant scoping applies to SQL, objects, indexes, graph queries, cache, background jobs and logs. All policy failures fail closed. Every published result is traceable to immutable source/release versions. No cross-workspace data leakage, including errors, counts, metadata and timing-sensitive query behavior where feasible.

## Verified technical references

- [Google Cloud managed folders](https://docs.cloud.google.com/storage/docs/managed-folders)
- [GCS folder types](https://docs.cloud.google.com/storage/docs/folder-types)
- [OPA policy bundles](https://www.openpolicyagent.org/docs/management-bundles)
- [OPA integration/decision logging](https://www.openpolicyagent.org/docs/integration)
- [Temporal Workflows](https://docs.temporal.io/workflows)

These validate candidate infrastructure capabilities, not the entire architecture. Versions, costs, quotas, and enterprise compliance decisions require validation in your deployment environment.
