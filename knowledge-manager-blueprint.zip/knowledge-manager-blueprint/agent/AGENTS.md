# Coding Agent Instructions — Knowledge Manager

You are implementing the architecture described in the adjacent documentation. **This repo initially contains design specifications, not deployed software.** Do not claim implementation or test success until actual code and test output exist.

## Task execution

1. Read `README.md` and docs `00`, `01`, `02`, `03`, `04`, `11`, `12`. For task-specific work read corresponding doc and API contracts.
2. Choose one milestone from `docs/12-delivery-plan.md` and implement one vertical slice. If ambiguous architecture decisions block work, use documented safe defaults and record an ADR/open question.
3. First write acceptance tests including at least one authorization-negative or isolation-negative test per sensitive endpoint.
4. Implement in order: typed models/migrations -> authorization/resource resolver -> domain operations -> API schema -> async handler -> frontend -> operational telemetry.
5. Run tests/lint/type checks and report actual outputs, limitations and unfinished work; never fabricate passes.
6. Update OpenAPI, examples, docs, changelog and assumptions when behavior changes.

## Non-negotiable invariants

- Never accept client-supplied workspace IDs, graph names, object paths, or roles as sufficient authorization.
- Check membership, domain eligibility, product grant and policy obligations independently.
- Product/catalog discovery is not product data access; no implicit global admin bypass.
- Query/export/infer/derive are distinct scopes. All queries through PEP/PDP.
- Builder cannot override enterprise/domain mandatory policy; delegation + SoD applies.
- Product release immutable, policy revision separately mutable/activated.
- Long-running operations idempotent and compensatable; outbox on state/event mutation.
- Every result and inferred claim has version/evidence metadata; LLM output untrusted until validated.
- Don't use source files of other workspaces as a shortcut for a federated integration.
- Product release remains usable after the author workspace is removed (when serving agreement remains valid).
- Disable insecure local mocks in production via explicit environment and startup check.

## Suggested repo skeleton (create incrementally)

```text
apps/api/app/{main.py,config.py,auth/,api/,domain/,infra/,models/,services/}
apps/web/src/{app/,components/,features/,clients/}
services/worker/{workflows/,activities/,adapters/}
packages/contracts/{openapi/,schemas/,generated/}
packages/policy/{dsl/,compiler/,tests/}
infra/{compose/,terraform/,migrations/}
tests/{unit/,contract/,integration/,security/,e2e/}
```

## First implementation prompt

Implement M0 and the smallest M1 vertical slice: create an authenticated workspace, persist record, launch an idempotent provisioning workflow using a fake storage adapter in local development, poll operation status, and verify a second user cannot read it. Include migration, FastAPI route, tests and minimal React UI. Keep GCS adapter interface separate and add real cloud integration tests behind environment-gated configuration; do not claim mock tests prove cloud IAM isolation.

## Coding standards

Python 3.12+ if chosen project environment supports it; type-checked Pydantic models, explicit domain errors; SQLAlchemy/Alembic migrations; strict TypeScript; dependency injection for adapters; clean separation of domain and infrastructure; structured redacted logs; test fixtures for two tenants; secure defaults. Pin actual dependency versions at implementation time and verify compatibility instead of adopting examples as validated versions.

## Final handoff format for every milestone

Provide changed files; architecture deviations; implemented APIs and schema; security checks; test commands and actual results; configuration required; manual deployment actions; remaining backlog and blockers. Prefer runnable commands and targeted patches over broad untested scaffolding.
