# One-page operating model

## Mission and value proposition

**Create privately; publish deliberately; consume securely; govern continuously.** Knowledge Manager allows enterprise teams to turn fragmented documents, system records and existing knowledge products into reliable semantic knowledge services while preserving source ownership and policy constraints.

```mermaid
flowchart LR
  A[Create workspace] --> B[Request domain/source access]
  B --> C[Ingest & register assets]
  C --> D[Extract, resolve, map, graph, infer]
  D --> E[Validate & package product]
  E --> F[Policy simulation & approvals]
  F --> G[Immutable published release]
  G --> H[Catalog discovery]
  H --> I[Authorized query / inference / reuse]
  I --> J[Monitor, refresh, recertify, retire]
  J -. source and policy changes .-> D
```

## Five operating boundaries

| Boundary | Owner | What it controls | Non-negotiable |
|---|---|---|---|
| Enterprise control | Security, governance, platform teams | identities, domain registry, policy guardrails, audit | default deny; explicit delegation |
| Private workspace | workspace owner and members | source uploads, draft assets, executions, budgets | physical resource access never inferred from URL |
| Domain | business domain owner/steward | business rules, permitted purposes, ontology standards | workspace ownership gives no domain authority |
| Published product | product owner and delegated approvers | immutable version/contract, approved distribution | publication is a governed transition, not visibility flag |
| Serving/exchange | consumer identity + product policy | query/retrieve/infer/derive/export; metering | every operation is policy-enforced, including derived results |

## Decision rights

- **Platform security** sets enterprise mandatory policy; cannot be bypassed by product owners.
- **Domain owner** determines domain business restrictions and delegated policy-authoring powers.
- **Product owner** proposes contract, visibility, consumers, refresh obligations and policy within domain bounds.
- **Builder** creates artifacts, proposes extraction/ontology/product policy changes, and requests publish.
- **Steward** reviews ontology alignment, DQ, provenance, fitness for use, certification.
- **Publisher** approves/executes release when separation-of-duties rules permit.
- **Consumer** uses approved product interface within purpose, policy and quota limits.

## Core end-to-end transaction

1. Workspace created in `PROVISIONING`; provisioning saga creates object namespace, execution identity and logical data-store scopes; only then `ACTIVE`.
2. Workspace requests domain/subdomain grants and connector-specific source grants; reviewer approves capabilities and expiry.
3. Connector or upload registers content-addressed source version; classifications and provenance recorded; processing runs under workspace identity.
4. Build workflow creates extracts, normalized entities, mappings, graph and vector representations; inference adds evidence-linked derived claims.
5. Builder assembles a product draft and a release candidate with pinned artifact/ontology/dependency versions, contracts and quality evidence.
6. Domain/product/steward reviewers approve; policy simulation evaluates RBAC, ABAC, and mandatory restrictions; serving binding prepared.
7. An atomic activation transaction exposes approved release + approved policy revision; catalog indexes permitted metadata only.
8. Consumers request product grants. Serving PEP validates principal, workspace, product, version, interface, purpose and data conditions; logs policy decision.
9. Refresh/change/revocation/incident workflows maintain correctness; product can outlive original builder workspace.

## Enterprise measurements

- Time to first workspace; time from ingest to first validated graph; publication lead time.
- Percentage of published claims with provenance, DQ gate pass rate, lineage completeness and staleness.
- Unauthorized access decisions, policy propagation delay, permission-review turnaround, revocation latency.
- Consumer adoption, query success/p95 latency, versions consumed, upstream breakages, cost per product and per query.

## Minimum viable enterprise pilot

One organization, 2 domains, 3 workspaces, 2 connector types, an RDF **or** LPG adapter, one ontology mapping flow, one product release, one catalog, one policy-protected query endpoint, explicit approval, full audit, and tests proving isolation/revocation. **Do not call the pilot enterprise-ready unless cross-workspace negative tests pass.**
