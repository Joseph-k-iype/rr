# System architecture: planes, services, boundaries

## Context and architecture principles

Multi-tenant-by-design, domain-governed, policy-as-code, versioned assets, event-driven long-running work, data minimization, provenance by default, and API-first serving. User-facing interactions are synchronous for control operations; lengthy processing and approvals are asynchronous resources with queryable status.

```mermaid
flowchart TB
 subgraph UX[Clients]
 UI[Web UI] SDK[SDK / CLI] BOT[AI agents]
 end
 GW[API gateway + verified identity]
 UI --> GW
 SDK --> GW
 BOT --> GW
 subgraph CP[CONTROL PLANE]
 WM[Workspace Manager]
 DR[Domain Registry / Entitlements]
 POL[Policy Manager + PDP]
 PR[Product Registry / Catalog]
 AP[Approval / Workflow Coordinator]
 AUD[Audit / Metering]
 end
 subgraph BP[BUILD PLANE]
 ING[Connectors + Ingestion]
 WORK[Durable Workflow Engine]
 ENR[Extraction + Entity Resolution]
 ONT[Ontology Registry + Alignment]
 GB[Graph/Vector Builder]
 INF[Inference + DQ Evaluation]
 end
 subgraph SP[SERVING + EXCHANGE]
 PEP[Serving Policy Enforcement Point]
 EX[Knowledge Exchange]
 QUERY[Graph/Vector/Hybrid Query]
 END[Product Endpoint Router]
 end
 subgraph DP[DATA PLANE]
 META[(PostgreSQL metadata)]
 GCS[(GCS isolated objects)]
 GRAPH[(Graph store)]
 VEC[(Vector indexes)]
 BUS[(Event bus/outbox)]
 end
 GW --> WM & DR & PR & AP & PEP
 WM & DR & POL & PR & AP --> META
 ING --> WORK --> ENR --> ONT --> GB --> INF
 WORK --> GCS & GRAPH & VEC
 CP --> BUS
 PEP --> POL
 PEP --> END --> QUERY
 END --> EX
 QUERY --> GRAPH & VEC
 EX --> GCS
 AUD --> META
```

## Service inventory and ownership

| Service/module | Responsibilities | Synchronous API | Async events/jobs |
|---|---|---|---|
| Workspace Manager | create, provision, suspend, archive, delete, members, quotas, resource bindings | workspaces | workspace.created, provisioning events |
| Domain Governance | hierarchical domain registry, entitlement requests, delegation | domains, access requests | grant.approved/revoked |
| Identity/Policy | PEP/PDP, RBAC/ABAC, policy drafts, simulation, approval, audit | policy eval; policy revisions | policy.activated/revoked |
| Asset Registry | source and derived assets, classifications, hashes, provenance | assets | asset.registered/versioned |
| Connector Manager | connector configuration, secret references, scheduling, sync cursor | connectors | connector.sync_requested/completed |
| Workflow Manager | immutable templates, runs, retries, cancellation, checkpointing | workflow runs | workflow state changes |
| Semantic Builder | extraction, resolution, ontology mapping, graph/vector conversion | templates/runs | asset build events |
| Ontology Registry | enterprise/domain/workspace ontology versions, mappings | ontologies | ontology.released |
| Quality & Inference | DQ, SHACL, deterministic and probabilistic reasoning, evidence | evaluation/infer | evaluation.complete |
| Product Registry | drafts, immutable versions, dependencies, contract and metadata | products/releases | release.candidate_created |
| Publication Manager | gates, reviewer approvals, serving provisioning/activation | publication requests | release.activated |
| Catalog | authorization-filtered search, product metadata, request access | discovery | index refresh |
| Exchange & Gateway | query, retrieve, infer, derive/import under policy | knowledge APIs | materialization jobs |
| Observability | audit, run telemetry, cost attribution, SLA signals | admin metrics | all lifecycle events |

## Trust boundaries

1. **Client-to-control:** validate JWT/OIDC, issuer, audience, expiry, actor type, and security claims. Never trust caller-specified membership or namespace.
2. **Control-to-worker:** issue minimal short-lived task identity scoped to workspace, run and resource bindings; worker fetches secrets through a broker.
3. **Worker-to-storage:** managed folder/bucket IAM plus service-level resource resolver and object-prefix validation. No cross-workspace reads.
4. **Catalog-to-serving:** metadata visibility ≠ query permission. PDP authorizes interface and row/entity-level scope.
5. **Exchange-to-builder:** federated query or explicit licensed snapshot; derived policies compose rather than broaden.
6. **LLM/external services:** classify prompt content, restrict outgoing data, treat retrieved text as untrusted, store model/version and evidence.

## Deployment profiles

**Local development:** Docker Compose with Postgres, MinIO GCS-compatible adapter (for development semantics only), Temporal dev server, OPA, graph adapter, FastAPI, React. Mocks MUST preserve policy decisions; never assume MinIO reproduces GCS IAM semantics.

**GCP pilot:** Cloud Run (control APIs), Cloud Run Jobs/GKE for processing, Cloud SQL Postgres, GCS managed folders, Pub/Sub, Secret Manager, KMS, identity provider/OIDC, managed logs/metrics; pick one graph engine and pgvector initially. Choose regional deployment, backups, key policy, workload identity, VPC boundaries.

**Regulated/high sensitivity:** dedicated projects/buckets/compute/db instances by isolation tier, private connectivity, stronger KMS control, independent audit retention, key rotation, DLP review, egress controls and legal-hold procedures.

## Cross-cutting semantics

- IDs: globally unique opaque IDs; public slugs are metadata, not authorization paths.
- Time: UTC timestamps; duration and expiry evaluated on server.
- Versioning: immutable source versions, workflow template versions, graph snapshots, ontology versions, product releases; mutable alias `current` points to approved version.
- Idempotency: `Idempotency-Key` required for creating long-lived resources and promotion requests.
- Consistency: transactional Postgres + outbox, at-least-once event delivery, idempotent consumers, reconciliation workers. No distributed ACID claim across GCS and graph store.
- Search: eventually consistent catalog index; primary registry is source of truth.
- Feature gating: fail closed if policy/entitlement unavailable; publishing can be paused without blocking private drafting.
