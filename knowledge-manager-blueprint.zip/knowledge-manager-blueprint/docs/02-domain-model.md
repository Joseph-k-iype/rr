# Canonical domain model and lifecycle invariants

## Aggregates and relationships

```mermaid
classDiagram
 class Domain {id; parent_id; owner_principal; policy_baseline_version}
 class Workspace {id; owner; state; isolation_profile; quota}
 class DomainGrant {id; workspace_id; domain_id; capabilities; expires_at}
 class KnowledgeAsset {id; workspace_id; kind; classification}
 class AssetVersion {id; asset_id; digest; source_lineage}
 class KnowledgeProduct {id; owning_domain; product_owner; builder_workspace; state}
 class ProductRelease {id; product_id; semver; manifest_digest; lifecycle}
 class PolicyRevision {id; product_id; revision; state; effective_at}
 class AccessGrant {id; principal_or_workspace; product_id; actions; expires_at}
 class ProductDependency {upstream_release; downstream_release; usage_mode}
 Domain "1" --> "0..*" Workspace : eligible_scope
 Workspace "1" --> "0..*" DomainGrant
 Workspace "1" --> "0..*" KnowledgeAsset
 KnowledgeAsset "1" --> "1..*" AssetVersion
 Workspace "1" --> "0..*" KnowledgeProduct : builds
 KnowledgeProduct "1" --> "0..*" ProductRelease
 KnowledgeProduct "1" --> "0..*" PolicyRevision
 ProductRelease "1" --> "0..*" ProductDependency
 KnowledgeProduct "1" --> "0..*" AccessGrant
```

## Resource definitions

**Organization:** security/administrative root and billing jurisdiction. 

**Domain:** hierarchical taxonomy (`risk/operational-risk/control-testing`), domain owner, stewards, ontology standards, data classification baseline and approved policy delegates. Parent domain does not imply unrestricted access to children.

**Workspace:** authoring tenant with members, state, approved domain scopes, GCS namespace mapping, database/graph/vector bindings, compute identity, budget and retention. A user may belong to multiple workspaces; an active workspace may have multiple builders.

**KnowledgeAsset / AssetVersion:** type `SOURCE_DOCUMENT|STRUCTURED_DATASET|EXTRACT|ONTOLOGY|GRAPH_SNAPSHOT|VECTOR_INDEX|RULESET|DQ_REPORT|INFERENCE_OUTPUT|OTHER`, producer run, input versions, checksum, classification, provenance, schema. The version record is immutable.

**WorkflowDefinition / WorkflowRun:** immutable definition revision, run identity, input asset versions, queue, state, retries, logs, outputs, cost and failure reason.

**KnowledgeProduct:** globally stable ID, owning domain, builder workspace, product owner, stewards, current active release and published status. Product identity survives workspace deletion if approved release is independently hosted.

**ProductRelease:** immutable manifest with semver, exact asset/ontology/dependency versions, contract, artifact integrity checksums, quality evidence and intended exposure. Publication state (candidate/approved/active/deprecated/retired) lives in release status records or registry pointers; never mutate release manifest.

**PolicyRevision:** separately versioned RBAC, ABAC, obligations, target operations, authoritative scope, approvers, activation status and effective interval. Runtime always evaluates latest active mandatory policy, subject to explicit pin/compatibility semantics, not historical release snapshot alone.

**AccessGrant:** principal (user, group, service identity, consumer workspace), product/interface/action, purpose, conditions, issuer/approver and expiry/revocation. A domain grant is not a substitute for a product grant.

**ProvenanceClaim:** source asset version, extract span or record key, assertion type, confidence, transformation/inference method, temporal validity, policy tags and human review.

## State machines

```text
Workspace: REQUESTED -> PROVISIONING -> ACTIVE -> SUSPENDED -> ARCHIVING -> ARCHIVED -> DELETING -> DELETED
  PROVISIONING -> PROVISION_FAILED (retry or compensate)
  SUSPENDED -> ACTIVE (only after revalidation)

WorkflowRun: QUEUED -> RUNNING -> SUCCEEDED | FAILED | CANCELLED | TIMED_OUT
  FAILED -> RETRYING -> RUNNING (within policy)

PublicationRequest: DRAFT -> SUBMITTED -> VALIDATING -> AWAITING_APPROVAL -> APPROVED -> ACTIVATING -> ACTIVE
  VALIDATING -> CHANGES_REQUIRED
  AWAITING_APPROVAL -> REJECTED
  ACTIVATING -> ACTIVATION_FAILED (compensate and retry)

AccessRequest: REQUESTED -> IN_REVIEW -> APPROVED | DENIED | CANCELLED
  APPROVED -> GRANT_ACTIVE -> EXPIRED | REVOKED

PolicyRevision: DRAFT -> TESTED -> SUBMITTED -> APPROVED -> ACTIVE -> SUPERSEDED | REVOKED
```

## Hard invariants

- A workspace cannot execute workloads until all mandatory resource bindings and isolation tests pass.
- A product cannot be `ACTIVE` until serving bindings, policy revisions, domain governance approvals, contract, quality evidence and catalog metadata are prepared.
- A product contract is pinned to a release digest; downstream consumers never silently switch to breaking versions.
- A builder can propose policy only to extent permitted by delegated `policy.propose`; cannot activate self-authored policy if separation of duties required.
- No release can depend on private upstream drafts outside same workspace unless a specifically approved shared mode exists; public release must depend only on authorized published upstream releases or authorized source agreements.
- Catalog `discover` does not grant `query`; `query` does not grant `export`, `derive`, or `infer`.
- Deleting workspace must not destroy active published product serving assets; require independent promotion/transfer before deletion.
- All derived graph statements inherit source classification/usage constraints; applying declassification requires explicit authorized decision and traceable transformation.

## Semantic version guidance

`MAJOR` for breaking ontology/interface/contract changes; `MINOR` for backward-compatible entities or operations; `PATCH` for correction/metadata/content refresh with unchanged interfaces. Semantic versioning is a convention—not a substitute for machine compatibility tests. Source updates should also have monotonically versioned snapshots independent of semver.
