# Workspace design, GCS filesystem, isolation and lifecycle

## Workspace request and provisioning

Input: name, description, owner principal, domain affiliation (not entitlement), isolation profile (`STANDARD|RESTRICTED|DEDICATED`), region, retention class, storage/compute quota, requested members. Result: asynchronous `workspace_id`, `operation_id`, state initially `PROVISIONING`.

Provisioning saga with compensation: (1) reserve ID + DB row; (2) create service/workload identity; (3) provision GCS namespace with least-privileged IAM; (4) allocate graph namespace/vector collection/metadata scope; (5) establish secrets scope/compute policy/quotas; (6) verify cross-workspace negative access from workload identity; (7) write bindings+manifest; (8) mark ACTIVE and emit event. On failure move to `PROVISION_FAILED`, revoke incomplete credentials, schedule cleanup, preserve audit.

## Virtual workspace file system

```text
/workspace/                                 # logical API only
  sources/uploads/{source_id}/{version_id}/
  sources/connectors/{connector_id}/{sync_id}/
  staging/{workflow_run_id}/
  datasets/{asset_id}/{version_id}/
  ontologies/{ontology_id}/{version_id}/
  graphs/{graph_id}/{snapshot_id}/
  vectors/{index_id}/{index_version}/
  rules/{ruleset_id}/{version}/
  workflows/{workflow_id}/{run_id}/
  products/{product_id}/drafts/{revision}/
  quality/{evaluation_run_id}/
  inference/{run_id}/
  artifacts/{artifact_id}/{version}/
  manifests/{snapshot_id}/
  trash/{deletion_job_id}/
```

Physical examples:

```text
gs://km-workspaces-prod/workspaces/{workspace_id}/sources/...
gs://km-publications-prod/releases/{product_id}/{release_id}/...
```

Never concatenate untrusted user path strings into a storage URI. The resolver accepts validated typed asset IDs and translates them to canonical object names. Reject `..`, ambiguous unicode normalization, extra separators, encoded slashes, control characters and unsupported absolute paths. Object writes use conditional generation preconditions and immutable version IDs. Store object generation, checksum, KMS identity and content classification in DB.

## GCS choices

- `STANDARD` (recommended default): uniform-bucket-level access + dedicated managed folder `workspaces/{id}/` with IAM restricted to workspace-specific workload identity; beware inherited project/bucket grants remain additive.
- `RESTRICTED`: separate bucket or project/identity per sensitivity domain, stronger ingress/egress boundaries and optionally customer-managed encryption keys. Choose based on threat model, not label alone.
- `DEDICATED`: workspace-specific project/bucket/compute and database instances for strict contractual isolation, with higher cost and operational burden.
- Hierarchical Namespace (HNS) creates actual folder resources and can support filesystem-style operations; managed folders primarily confer IAM. A logical home-folder design does **not** require HNS. Verify bucket-mode compatibility and operational restrictions before enabling.

## Other storage isolation (independent of GCS)

| Store | Standard isolation | Higher isolation | Enforcement |
|---|---|---|---|
| PostgreSQL | workspace_id FK + mandatory RLS policies | dedicated schema/database | API scope + RLS role & integration tests |
| Graph | one graph/database namespace per workspace | dedicated database/cluster | server-side query compiler/proxy; scoped credentials |
| Vector | namespace/collection + mandatory workspace filters | dedicated collection/service | inject filter server-side; filter before ranking and output |
| Object | managed folder per workspace | dedicated bucket/project | least privilege; no broad inherited reader grants |
| Cache | principal/workspace/policy-version keyed | isolated cache instance | short TTL, invalidation on revocation |
| Job | scoped run identity, temp volume and limits | dedicated node pool | no arbitrary credential passing |

## Member roles

`workspace.owner`: manage membership, settings and lifecycle; `workspace.admin`: manage connections/workflows with bounds; `workspace.builder`: upload, build, draft; `workspace.viewer`: see permitted drafts; `workspace.auditor`: read approved audit/metadata. These do not confer domain or product grants.

## Domain grant request

Fields: `workspace_id`, `domain_id`, `capabilities[]` (`discover|consume|derive|publish_propose`), `purpose`, `business_justification`, `expires_at`, `data_classification_ceiling`, `approver`, `state`. When approved, grant permits eligibility only; a source connector and published product still require their own grants. Approval changes are logged and dispatched for effective policy/cache updates.

## Suspend, archive, delete

- **Suspend:** stop new jobs and connector sync; existing jobs checkpoint/cancel; deny workspace build mutations; do not silently suspend independently served published releases.
- **Archive:** snapshot configuration and artifact manifest, disable credentials, apply retention; indexed and graph records marked read-only.
- **Delete:** run impact analysis: active published dependencies, materialized copies, legal hold, retention policies, ongoing jobs. Block deletion when serving transfers are incomplete. Revoke identities, stop runs, delete resources per storage lifecycle, tombstone identifiers and retain minimal audit evidence.
- **Restore:** under strict permissions, new credential issuance and revalidation of grants; never blindly reinstate expired access.

## Required negative tests

User A cannot list B's workspace; workload A cannot read B's objects directly; run A cannot select graph B; vector A cannot return embeddings B; PostgreSQL connection missing tenant setting returns no rows or errors; cache A cannot return B results; archived workspace cannot execute connectors. Tests must run against real GCS IAM in integration environment, not just local emulator.

## Operations and limits

Quotas: bytes/objects, connector sync rate, concurrent workflow runs, tokens, vector count, graph triples/nodes, query QPS, cost budgets. Use soft alerts and hard fail-safe limits. Maintain immutable audit of provisioning principal, identity bindings, region, encryption setup, grant changes and deletion. Never put secrets in manifests or workflow logs.
