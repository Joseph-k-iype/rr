# Identity, RBAC, ABAC and product-owned business rule governance

## Model

**PAP (Policy Administration Point):** Policy Studio drafts/version/reviews rules. **PDP (Policy Decision Point):** deterministic decisions using verified attributes. **PEP (Policy Enforcement Point):** API, graph/vector/LLM/query/export gateways; cannot bypass PDP. **PIP (Policy Information Point):** authoritative attributes from IdP, domain registry, grant registry, product contract, classification and workspace state.

Authentication: OIDC/JWT with strict audience/issuer, key validation and token expiry. Service-to-service uses workload identities. Authorization decisions use principal identity + authenticated consumer workspace + target product/release/interface + action + purpose + context + provenance/classification obligations. Do not trust domain, role or classification labels supplied by client.

## Distinct entitlements

- Organization/tenant membership: who may use platform.
- Workspace membership: who may collaborate on private draft assets.
- Domain/subdomain grant: which business scope the workspace is eligible to act within.
- Source entitlement: which connector/source assets may be ingested and under what usage rights.
- Product discover grant: find permitted catalog metadata.
- Product operational grant: `query`, `retrieve`, `infer`, `derive`, `export`, `subscribe`, etc., potentially limited by release, interface, purpose and data predicates.
- Policy authoring delegation: who can `policy.propose`, `simulate`, `approve`, `activate`, `delegate`, `revoke` for a target scope.

## Roles / authorities

| Role | Allowed policy influence | Not inherently allowed |
|---|---|---|
| Enterprise Security | mandatory global floor, emergency restriction | bypass audit / unrestricted read of sensitive assets |
| Domain Owner | mandatory domain rules; delegate product policy scopes; approve cross-domain | weaken global mandatory restrictions |
| Domain Steward | quality/certification/ontology policy proposals; approve per delegation | create unconditional product grants |
| Product Owner | product interface restrictions, purpose grants, contracts and proposed releases | weaken domain/global constraints |
| Knowledge Builder | propose product-specific conditions with delegation; run tests | activate own sensitive policy or grant access by default |
| Publisher | promote approved release and approved policy revision | self-approve in prohibited SoD configurations |
| Consumer | request and use authorized operations | access draft workspace via published product |
| Platform Admin | operate infrastructure and audit service | automatic privilege to business data |

## Rule precedence and conflict resolution

Policy composition: enterprise mandatory restrictions AND owning-domain mandatory restrictions AND source-license/lineage restrictions AND approved product-specific policy AND active grant AND request-context constraints. Explicit deny > allow. Missing PIP attributes, policy bundles, or uncertain classifications => deny/safe-degrade. A product-specific allow can NEVER override mandatory domain deny. More-restrictive product rules allowed under delegated scope. Rule conflict detection must surface which policy IDs triggered deny, with explanations redacted for unauthorized callers.

## Example policy input

```json
{
  "principal": {"id":"user-17", "type":"user", "verified_groups":["risk-analysts"], "region":"IN"},
  "consumer_workspace": {"id":"ws-b", "state":"ACTIVE", "approved_domains":["risk.operational"]},
  "resource": {"product_id":"kp-ops-risk", "release_id":"rel-1", "interface":"graph-query", "classification":"CONFIDENTIAL"},
  "request": {"action":"query", "purpose":"control-testing", "requested_fields":["control_id","owner"]},
  "environment": {"timestamp":"2026-11-17T11:30:00Z"}
}
```

## Example policy response

```json
{
  "decision_id":"dec-7b1", "allow":true,
  "obligations":{"row_filter":{"allowed_domains":["risk.operational"]},"mask_fields":["personal_identifier"],"max_results":100,"prohibit_export":true,"log_level":"full"},
  "policy_revision_ids":["global-10","domain-7","product-3"],
  "decision_ttl_seconds":30
}
```

Allowed obligations must be enforced by serving adapter; if an adapter cannot apply `row_filter`, `mask_fields` or other mandatory obligations, deny the request. For graph queries, validate permitted types/edges and post-filter results as defense-in-depth; do not rely on unsafe string substitution of arbitrary SPARQL/Cypher.

## Policy lifecycle

`DRAFT -> TESTED -> SUBMITTED -> APPROVED -> ACTIVATING -> ACTIVE -> SUPERSEDED|REVOKED`. Draft includes author and source authority. Before approval: parse/schema check, lint, conflicting grants, property tests, synthetic subjects, negative access regression, blast-radius report (#current authorized subjects/queries affected), approval quorum/SoD. Activation: commit policy revision + effective timestamp; distribute bundles; verify gateway activation acknowledgment; refuse sensitive queries on stale policy revision. Revocation path must work even if catalog search is unavailable.

OPA-style rules can serve as PDP implementation, but your **business policy model** should be a typed, reviewed DSL, not unconstrained user-uploaded Rego. Compile approved DSL to evaluator/OPA bundles. Bundle distribution is eventually consistent, so revocation requires a central deny override/revision check or similarly bounded strong enforcement path.

## Template rules

- `INTERNAL_RISK_QUERY`: active workforce in Risk; required consumer workspace domain; approved product query grant; authorized purpose; region-bound.
- `NO_EXPORT`: query allowed but no raw export/materialize.
- `PROVISIONAL_INFERENCE`: inferred assertions from unvalidated sources get provisional labels and may be excluded from certified queries.
- `SENSITIVE_EDGE_REDACTION`: traversals of restricted relation types require additional entitlement.
- `SOURCE_RIGHTS`: derived products cannot expose information beyond source licensing.

## Simulator requirements

Input draft policy, target product and chosen test identities/requests; outputs before/after decision matrix, obligations, affected principals (aggregated, no unauthorized enumeration), conflict warnings, unintended escalation detection. Simulator must use a frozen snapshot of attributes and explicitly label it as a simulation—not proof of future authorization.

## Emergency access and audit

Break-glass access requires separate preapproved mechanism, time bounds, justification, least privilege, alerts and post-event audit. Do not implement generic `is_admin => allow`. Audit policy decisions using redacted attributes, decision IDs, policy revision, product release, actor/workspace identity, action, enforcement outcome and trace ID. Retain sensitive decision context only according to governance policy.
