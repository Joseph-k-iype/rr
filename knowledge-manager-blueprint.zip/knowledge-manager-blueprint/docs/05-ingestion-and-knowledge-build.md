# Ingestion, semantic construction, inference and evidence

## Source types and contract

Sources: manual upload (PDF, DOCX, CSV, JSON, TXT, HTML); managed connectors (Drive/SharePoint/S3/GCS/databases); APIs; permitted published knowledge product interfaces. Connectors use per-workspace configuration and secrets references, not embedded credentials. Every connector declares authentication type, scopes, permitted source location, sync mode, watermark, rate limits, data classification expectation and license/usage conditions. Avoid indexing unapproved third-party data.

## Ingestion workflow

1. Verify caller `workspace.assets.write` and source entitlement; verify workspace ACTIVE, quota, allowed MIME/size and policy.
2. Request resumable upload or connector sync job. Use malware scanning, content-type sniffing and zip bomb/resource limits; quarantine suspicious files.
3. Stream into temporary `staging/{run}` location, generate SHA-256 checksum and metadata. Never allow user-selected arbitrary object paths.
4. Scan for sensitive data/classification and prohibited content policies; handle encrypted/unreadable documents with explicit failure category.
5. Promote accepted source version to immutable namespace; store object generation/hash/source URI/provenance/license/ingestion time.
6. Extract text, tables, document structure and record-level provenance. Keep page/span references; OCR only when needed and legally permitted.
7. Produce `asset.registered`, queue downstream processing, write job/cost metrics.
8. Handle incremental sync using source cursor/ETag and deletion tombstones; dedupe on source+hash within authorized scope only.

## Build pipeline (versioned DAG)

```mermaid
flowchart LR
 A[Immutable input versions] --> B[Parse / normalize]
 B --> C[Chunk & entity / relationship candidates]
 C --> D[Entity resolution / canonical IDs]
 D --> E[Ontology mapping / constraint checks]
 E --> F[Asserted graph + embeddings]
 F --> G[Rules / inference]
 G --> H[DQ, evidence & human review]
 H --> I[Versioned asset manifests]
```

Every node of the DAG is a versioned action with deterministic inputs; record code/model/prompt versions, parameters, duration, output hashes, failures, and classification. LLM extraction is probabilistic and must produce evidence spans/confidence; unsupported claims should not silently become authoritative asserted edges.

## Recommended artifact schema

```json
{
  "asset_id":"asset-123", "asset_version_id":"av-2", "kind":"GRAPH_SNAPSHOT",
  "workspace_id":"ws-a", "producer_run_id":"run-9",
  "input_versions":["source-1:v4","ontology-risk:v2"],
  "checksum_sha256":"<64-hex-digest>",
  "classification":"INTERNAL", "schema_ref":"graph-contract:v1",
  "provenance_manifest_uri":"resource://manifest/91",
  "created_at":"2026-11-17T12:00:00Z"
}
```

## Ontology governance

Enterprise canonical ontology, domain ontology and workspace experimental extensions are separate authority layers. Workspace may fork/map but not overwrite domain/enterprise terms. Releases pin exact ontology versions and mapping sets. Validate namespace uniqueness, property domains/ranges, constraints, deprecated terms, compatibility with published interfaces, and ownership of new terms. `ontology.propose` and `ontology.release` are different permissions. Store OWL/RDFS/SHACL in versioned object assets; add registry metadata for search and compatibility.

## Entity resolution

Canonical entity table uses namespace-qualified IDs; mapping table stores candidate source IDs, evidence, resolution strategy, confidence, review status and temporal validity. Never merge entities across security domains solely because names are similar. A cross-domain canonical identity can be exposed only through authorized mapping product or approved exchange service. Track merge/split events, reversible mapping history, conflicting attributes and human override with approval.

## Graph design

Support an adapter boundary: `GraphRepository` with `create_namespace`, `load_snapshot`, `query_authorized`, `validate_shapes`, `delete_namespace`, `get_stats`, `promote_serving_snapshot`. Pick one concrete implementation for MVP (RDF/Fuseki **or** LPG/Neo4j); keep RDF vs LPG transforms explicit and loss reports. Graph snapshots include nodes/edges or triples, schema, provenance references, policy labels, timestamps and digest. Queries must pass through checked adapter and resource resolver.

## Inference service taxonomy

1. **Deterministic rules:** business rules and graph patterns; record rule version and premises.
2. **RDFS/OWL reasoning:** computed entailments with ontology version and reasoning profile; prohibit unsafe unrestricted reasoning on large graphs without budgets.
3. **Graph algorithms:** connectivity, centrality, reachability; results are computed metrics, not logically entailed facts.
4. **Statistical/ML inference:** predicted labels, scores or links; store calibration and model provenance.
5. **LLM inference:** proposed interpretations/claims with citations and uncertainty; require guardrails and validation before certification.
6. **Knowledge recommendations:** context-derived decisions with explicit business rule provenance; distinguish recommendation from factual assertion.

Output claims have `assertion_kind = ASSERTED|INFERRED_DETERMINISTIC|PREDICTED|GENERATED`, evidence list, confidence (if probabilistic), rule/model version, validity interval and review state. Query service exposes that distinction to consumers.

## DQ and evaluation

Metrics: null/required field completeness, duplicate rate, referential integrity, orphan nodes, shape compliance, ontology mapping coverage, provenance coverage, freshness, contradiction count, leakage checks, retrieval recall@k and hallucination/evidence support rate. Thresholds depend on product usage tier and are part of release contract. Failed gates produce actionable reports; quality scores must not hide failed mandatory security checks.

## Human-in-the-loop

Review queue for ambiguous matches, unsupported LLM claims, ontology changes, conflicts and sensitive classifications. Reviewers see evidence and source context only if individually authorized. Approve/reject with rationale, timestamp and source version. Reviewer changes are versioned transformations, not mutation of source.

## Failure and replay

Each stage is idempotent keyed by `(workflow_run_id, step_id, input_digest, code_version)`; retries use bounded exponential backoff, poison records go to dead-letter investigation, partial artifacts stay quarantined. On cancellation, stop jobs and retire temp assets. Replay cannot silently pull changed source version; require explicit `refresh` workflow to select new versions. Maintain per-run budget/timeouts and deterministic checkpoints.
