# Product assembly, publication, release and catalog

## Product vs release vs policy

`KnowledgeProduct`: stable globally unique identity, business owner/domain, description, discoverability intent and evolving versions. `ProductRelease`: immutable manifest/digest pinned to graph/vector/document assets, ontology, inference rules, source versions, lineage and consumer contract. `PolicyRevision`: independent approved and activated rules that can change without new content release. `ServingBinding`: immutable release-to-serving-resource mapping, activated via pointer swap. `CatalogEntry`: discoverable projection subject to metadata ACL, not actual permission to query data.

## Release manifest (proposed)

```yaml
apiVersion: km/v1
kind: KnowledgeProductRelease
metadata:
  productId: kp-resilience
  releaseId: rel-v1-0-0
  version: 1.0.0
  ownerDomain: risk.operational
  builderWorkspaceId: ws-risk-a
content:
  graphSnapshot: {assetVersionId: graph-v12, sha256: example_digest}
  vectorIndex: {assetVersionId: vec-v4, sha256: example_digest}
  ontology: {ontologyId: operational-risk, version: 2.2.0}
  rulesets: [{id: resilience-inference, version: 1.1.0}]
  upstreamProducts: [{productId: kp-app-inventory, releaseId: rel-2-1, useMode: federated}]
contract:
  interfaces: [graph-query, entity-lookup, hybrid-retrieval]
  schemaVersion: 1.0.0
  freshnessSloHours: 24
  classification: CONFIDENTIAL
  allowedPurposeClasses: [operational-resilience-analysis]
quality:
  evidenceBundleId: dq-run-230
  shaclPass: true
  provenanceCoverage: 0.98
governance:
  approvalRequestId: approval-56
  policyRevisionId: policy-24
  certification: domain-approved
```

Use actual SHA-256 hex digests in implementation; above values are illustrative. Manifest canonicalization and digest must be deterministic. The contract should enumerate output restrictions, interface schemas, pagination/limits, support contact, change notice period, SLA and region.

## Publication saga

**Phase 1: Prepare:** submit candidate with pinned versions; verify source usage rights; run DQ and semantic gates; compute dependency restrictions; generate policy simulation and access blast-radius report; request domain/steward/security approvals according to classification; create immutable release manifest; allocate serving snapshots/copies or stable references; perform canary queries and policy enforcement tests.

**Phase 2: Activate:** in a DB transaction, confirm approvals/policy revision still valid; update `active_release_id` and `active_policy_revision_id`, write outbox event and catalog projection cursor. Serving gateway must check active registry authoritative pointer, not search index; queries should either see prior valid release or new valid release, never partial assets. On failure, keep old release active, rollback pointer and quarantine new binding.

**Phase 3: Propagate:** index catalog, warm safe caches keyed by policy revision, notify subscribers, start monitors and cost attribution. Any failed noncritical propagation is retried by reconciliation; activation event is idempotent.

## Validation gates

| Gate | Hard/conditional | Evidence |
|---|---|---|
| Ownership / authorized source use | hard | domain ownership, licenses, original grants, source retention |
| Security / classification | hard | sensitive scan, region, encryption, egress path, restrictions |
| Data quality | configurable hard thresholds | completeness, identity conflicts, freshness, SHACL |
| Ontology compatibility | hard for declared interface | diff report, namespace validation, contract conformance |
| Inference evaluation | hard for certified inference endpoints | evidence support, rule trace, calibrated thresholds |
| Operational readiness | hard for production tier | endpoint availability, query benchmarks, SLOs, rollback |
| Contract completeness | hard | schema, documentation, supported operations, owner, version |
| Policy simulation | hard | RBAC/ABAC test matrix, escalation conflicts, deny regressions |
| Approval / SoD | hard | digitally traceable approvals and reviewer identity |

## Publish visibility vs trust

Independent axes: `lifecycle` = DRAFT/CANDIDATE/PUBLISHED/DEPRECATED/RETIRED; `visibility` = PRIVATE/NAMED_WORKSPACES/DOMAIN/ENTERPRISE; `certification` = NONE/DOMAIN_REVIEWED/CERTIFIED; `access_mode` = APPROVAL_REQUIRED/AUTOMATIC_ELIGIBLE/INVITATION. Domain visibility only affects discovery; never automatically grants query.

## Catalog entry

Searchable fields: product title, owner/steward, domain, permitted interface types, semantic concepts, description, schema, available releases, quality summary, freshness status, request-access path and consumer guides. Redact product names/descriptions where discover entitlement is absent. Never index confidential text, source paths, PII samples or restricted entity counts into public-facing catalog.

## Lifecycle beyond publish

- New release: validate interface compatibility, compare DQ, compute downstream impact, approve, canary, activate.
- Policy update: independent simulation/approval/activation; revoke and invalidate caches without new release.
- Deprecation: announce timeline; support pinned consumers; notify dependent owners.
- Retirement: assess critical dependencies, revoke serving rights, archive contract/audit, satisfy legal retention; prevent breaking dependent products without approved exception.
- Workspace deletion: serving assets are publication-owned or contractually source-managed, not deleted with builder workspace.

## Product quality passport

Provide versioned evidence links and timestamps: provenance coverage, SHACL and DQ results, freshness, ontology alignment, inference confidence validation, security review, upstream dependencies, incident history, supported operations and owner. Never convey an unqualified guarantee that all claims are true.
