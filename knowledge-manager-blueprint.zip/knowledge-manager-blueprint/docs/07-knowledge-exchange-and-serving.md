# Knowledge Exchange, secure serving and inference

## Three reuse modes

| Mode | Semantics | Minimal permission | Risks/control |
|---|---|---|---|
| Federated | query remote published endpoint live | `query` or `retrieve` | policy at source request; handle unavailability/version pin |
| Materialized import | authorized subset copied into consumer workspace | `export` plus `derive` if transformation | track classification, copies, TTL, revocation and deletion |
| Derived product | transform authorized outputs into a new product | `derive` + necessary read interface | combine upstream restrictions, dependency version and evidence |

In any mode, consumer A never receives private workspace credentials for producer B. Exchange mediates product-release interfaces only. No direct graph federation without per-product PDP evaluation and scope propagation. Published copy/export rights must be separately granted; query access alone is not permission to extract whole graph.

## Runtime request sequence

```mermaid
sequenceDiagram
 participant C as Consumer
 participant G as Gateway/PEP
 participant P as PDP
 participant R as Product Registry
 participant Q as Query/Inference
 participant D as Graph/Vector store
 C->>G: query(product, release, purpose, interface)
 G->>R: resolve authoritative release/contract
 G->>P: evaluate verified context, action, filters
 P-->>G: allow/deny + obligations + policy IDs
 alt deny or unavailable
 G-->>C: 403 / policy unavailable (safe failure)
 else allowed
 G->>Q: constrained execution plan + obligations
 Q->>D: scoped query / filtered retrieval
 D-->>Q: permitted candidate results
 Q->>Q: apply redactions, output budget, provenance checks
 Q-->>G: scoped response and trace
 G-->>C: data + provenance + release + decision id
 end
```

## Serving API principles

- Product identity and exact release resolved server-side; `latest` alias must be a checked active pointer. No arbitrary storage URI or graph namespace in external request.
- Query DSLs: prefer typed query templates and parameterized graph patterns in MVP; raw SPARQL/Cypher requires parser/AST authorization, strict timeouts, field/relationship whitelists and tenancy guards.
- Vector search: enforce collection + security filters **before candidate retrieval/reranking** where available, and filter/redact returned citations. If engine cannot guarantee isolation, deploy separate namespace/index.
- LLM inference: retrieve authorized evidence only, guard prompt injection, attach citations and confidence, prevent secondary tool calls outside authorized product set, track token budgets, do not persist restricted context in shared cache.
- Pagination, query execution deadlines, max path length, node/edge result limits, token/result budgets, rate limits and circuit breakers.
- Audit for graph queries, inference, exports and materialization. Access decisions record attributes used and effective policy revisions with safe redaction.

## Retrieval/inference response envelope

```json
{
  "request_id":"req-77", "decision_id":"dec-7b1",
  "product_id":"kp-resilience", "release_id":"rel-1",
  "policy_revisions":["enterprise-8","risk-domain-4","product-3"],
  "results":[{
    "entity_id":"app:1024", "relation":"supports_service", "target_id":"svc:29",
    "assertion_kind":"INFERRED_DETERMINISTIC", "source_refs":["kp-app-inventory:rel-2-1"],
    "evidence_ids":["evidence-2"], "valid_at":"2026-11-17T10:00:00Z"
  }],
  "warnings":[], "next_cursor":null
}
```

Opaque IDs only in response if permitted; source references may themselves be sensitive and must be redacted or translated into authorized citations.

## Product dependency graph

Capture `consumer_product_version -> upstream_release` with usage mode, dependency contract, ontology compatibility, materialization snapshot, source grants and applicable policy obligations. On upstream publish/retire/revoke: calculate downstream impact and subscriber notifications, mark stale dependencies, block unsafe refresh, and schedule re-evaluation. Materialized copies cannot be 'unseen'; require governed purge/restriction workflow, audit and downstream derived-product risk handling.

## Cache design

Key by `(principal/grant scope, consumer workspace, product_id, release_id, active policy revision, purpose, interface, query fingerprint, obligations digest)` and ensure product-level invalidation. Sensitive responses should default to no shared caching. On policy update/revocation, invalidate keys and reject stale policy tokens. Audit cache hits and enforce TTLs.

## Federated availability

Per-product SLOs, circuit breaker, timeout, partial-result disclosure (never silently claim completeness), source failure annotations and retry only idempotent queries. Pinned product versions may become unavailable under policy revocation; availability cannot override authorization.

## Connector to consumption interfaces

MVP: `entity.lookup`, `graph.query_template`, `knowledge.retrieve`, `knowledge.infer_rules`, `product.context`. Later: `graph.traverse`, `relationship.explain`, `subscribe.changes`, `derived.materialize`. Enforce separately authorized actions for every endpoint, including agent tool invocation.
