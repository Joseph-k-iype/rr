# End-to-end workflow catalog: implementation playbooks

## Standard workflow contract

Each workflow has: `workflow_id`, `type`, `workspace_id?`, `product_id?`, `actor_id`, `request_id`, `idempotency_key`, `input_manifest`, `state`, `current_step`, `checkpoint`, `deadlines`, `retry_policy`, `approval_tasks[]`, `output_asset_versions[]`, `events[]`, `error_code`, `audit_trace_id`. Orchestrator provides durable progress; approval signals are authenticated events, not unauthenticated HTTP callbacks. Every workflow has timeout, retry exhaustion path, compensating actions and an operator-visible run history.

### WF-01 Workspace provision

**Trigger:** authorized create request. **Preconditions:** enterprise membership, quota, unique slug policy, permissible isolation profile. **Activities:** reserve record; create identity; allocate GCS managed folder/bucket, graph/vector namespaces, metadata bindings; apply IAM; validate negative access; register quotas; mark active. **Success:** `workspace.active`, URL/resource metadata available. **Failure:** `PROVISION_FAILED`, revoke credentials and clean incomplete resources; retry idempotently. **Audit:** requester, owner, region, identity, resource bindings.

### WF-02 Domain/subdomain access

**Trigger:** workspace requests eligibility. **Preconditions:** authorized owner/member, domain exists. **Activities:** submit purpose, capabilities, classification ceiling, duration; route to domain owner/delegates; approval/denial; grant registry update; notify policy cache; set expiration timer. **Success:** scoped `DomainGrant`; product/source access still separate. **Failure:** denial/revocation; no source access. **Compensation:** revoke grants, invalidate derived query caches, evaluate existing source rights.

### WF-03 Upload or connector synchronization

**Trigger:** manual upload or scheduled sync. **Preconditions:** workspace active, connector credential valid, source rights, budget. **Activities:** stream, scan, classify, checksum, register immutable source version, dedupe within authorization scope, watermark update, emit ingestion event. **Success:** assets and provenance manifest. **Failure:** quarantine/partial sync report; do not advance cursor past unprocessed records. **Compensation:** clean staging objects; cursor rollback where possible.

### WF-04 Document to knowledge graph

**Trigger:** builder selects asset versions and workflow template. **Preconditions:** ontology+source version pinned, sufficient quota. **Activities:** parse, chunk, extract candidates, evidence spans, entity resolution, mapping, shape validation, graph load into private namespace, build vector index, quality report. **Success:** immutable graph/vector asset versions. **Failure:** checkpoint/retry, preserve prior published index, quarantine partial build. **Human review:** uncertain matches, ungrounded claims.

### WF-05 Ontology proposal and release

**Trigger:** builder proposes extension or mapping. **Activities:** identify owning ontology, compare versions, check namespace/constraints, run compatibility tests on dependent products, steward review, publish canonical version or reject. **Success:** ontology version and deprecation notices. **Failure:** fork remains workspace-private. **Guard:** workspace cannot mutate domain namespace directly.

### WF-06 Inference and evidence review

**Trigger:** rule/model evaluation or query. **Activities:** authorize sources, load pinned graph/rules, execute bounded reasoning, materialize derived claims with evidence, classify uncertainty, validate constraints, route ambiguous findings to reviewers. **Success:** inference version with explanation chain. **Failure:** preserve asserted graph, mark derived output invalid, never silently promote LLM output to certified fact.

### WF-07 Product assembly / publication

**Trigger:** owner submits candidate. **Activities:** pin source/graph/vector/ontology/rules, compute manifest digest, DQ and security tests, compile policies and simulate access, ensure licenses and source grants, request approvals, build stable serving binding, canary, activate registry pointer and policy revision, publish metadata and notifications. **Success:** immutable active release + authorized endpoints. **Failure:** revert pointer, invalidate canary, leave previous release active. **Guard:** policy approval must not be self-approved if SoD requires.

### WF-08 Product access request

**Trigger:** discoverable catalog product, consumer requests capability. **Activities:** capture actor/workspace/purpose/interface/expiry, check domain eligibility, route owner approval, commit grant, update PDP. **Success:** scoped time-bound grant; still re-evaluate at every request. **Failure:** deny; never expose private source in approval details.

### WF-09 Consumption and federated query

**Trigger:** user/agent query. **Activities:** verify identity/consumer workspace, resolve active release, PDP decisions+obligations, constrained query plan, filter authorized results before response, attach provenance, audit/meter. **Success:** policy-scoped result. **Failure:** fail closed; rate-limit and timeouts; never fallback to direct graph endpoint.

### WF-10 Materialized import / derived knowledge

**Trigger:** builder adds existing product as source. **Activities:** request `derive` and optional `export`, approve bounded snapshot/mode, policy-filter data and license metadata, snapshot into consumer workspace, align ontology, preserve lineage/obligations and revocation reconciliation record, build derived product. **Success:** controlled derived asset versions. **Failure:** remove partial snapshot and block downstream promotion. **Guard:** query access alone cannot copy data.

### WF-11 Product change propagation

**Trigger:** connector update, ontology update, upstream release or ruleset change. **Activities:** traverse dependency graph, calculate impacted versions/consumers, check compatibility, schedule incremental or full rebuild, validate DQ/security, approve release, notify and invalidate stale caches. **Success:** updated release and subscriber change event. **Failure:** mark stale/at-risk, alert owner; never overwrite previously approved release without approval.

### WF-12 Policy edit, simulation and activation

**Trigger:** delegated domain/product role drafts ABAC/RBAC. **Activities:** verify author scope, validate DSL, simulate allow/deny and obligations on regression matrix, estimate blast radius, collect approver signatures, compile signed bundle, activate revision, enforce consistency/revocation path, audit. **Success:** activated policy. **Failure:** old policy stays active or emergency deny applies; no unapproved grants.

### WF-13 Incident, revoke and quarantine

**Trigger:** suspicious access, source license withdrawal, classification error, security incident. **Activities:** issue deny override, stop new queries, invalidate caches and queued exports, identify materialized copies/derived products, suspend releases when needed, notify owners, record incident, follow retention/legal hold. **Success:** access ceased and remediation tracked. **Failure:** escalation to fail-closed serving mode. **Guard:** do not promise deletion of data already externally exported; audit and contractual response required.

### WF-14 Re-certification and SLA breach

**Trigger:** periodic timer, quality/freshness regression, model/rule change, upstream critical update. **Activities:** rerun evidence checks, compare thresholds, refresh trust passport, downgrade certification/restrict interface if necessary, notify owner and consumers. **Success:** renewed certification with timestamp and evidence. **Failure:** stale badge removed or access constrained according to policy.

### WF-15 Archive/retire/delete

**Trigger:** owner request/retention expiry. **Activities:** inspect active consumers/dependencies/legal holds, approve migration plan, signal deprecation, revoke grants and endpoints, transfer publication-owned assets, archive evidence, delete private workspace resources in dependency-safe order. **Success:** tombstoned state and audit. **Failure:** deletion blocked with actionable dependencies. **Guard:** preserve product release independent of source workspace until lifecycle explicitly retired.

## Required test scenarios (cross-workflow)

1. Domain owner adds deny rule while active query is running: future/new requests deny; streaming semantics documented; no new pages after revocation.
2. Product owner publishes release then builder workspace is deleted: product continues serving from publication-owned resources.
3. Source becomes restricted after materialized import: dependent products flagged; access appropriately denied; copy reconciliation initiated.
4. Approved draft passes quality but serving snapshot preparation fails: no catalog exposure or active pointer change.
5. Policy bundle distribution delayed: gateway reads authoritative revision and denies when stale beyond threshold.
6. Same workflow submitted twice with same idempotency key: one logical operation, no duplicate provisioning.
7. Cross-tenant vector retrieval with intentionally identical embeddings: result filters exclude unauthorized tenant before ranking/output.
8. Upstream ontology major version changes: dependent product pinned to previous release, compatibility alert raised.
