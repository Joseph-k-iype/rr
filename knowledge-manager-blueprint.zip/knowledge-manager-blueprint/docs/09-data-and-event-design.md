# Data design, persistence, lineage and event contracts

## PostgreSQL baseline model

Prefer UUID PKs; timestamps `created_at`, `updated_at`, `deleted_at` where appropriate; optimistic `row_version`; constraints and relationships defined in migrations. Workspace-owned tables require `workspace_id NOT NULL` and Row Level Security policies. Cross-domain product tables use dedicated product entitlements and authorization service, not workspace RLS alone.

| Table | Key columns | Constraints/indexes |
|---|---|---|
| organizations | id, name, region | unique ID |
| principals | id, issuer, subject, type | unique (issuer, subject) |
| domains | id, parent_id, owner_id, path, policy_id | unique path; cycle guard |
| workspaces | id, org_id, owner_id, state, isolation_profile, region | (org_id, id); state check |
| workspace_members | workspace_id, principal_id, role | composite PK |
| resource_bindings | id, workspace_id, kind, provider, opaque_ref, state | unique (workspace,kind,ref) |
| domain_access_requests | id, workspace_id, domain_id, state, purpose | index approver/state |
| domain_grants | id, workspace_id, domain_id, capabilities, expires_at | active time index |
| connectors | id, workspace_id, type, config, secret_ref, cursor | never store plaintext secrets |
| assets | id, workspace_id, kind, classification | tenant/kind index |
| asset_versions | id, asset_id, digest, metadata, storage_ref, producer_run_id | unique(asset_id,digest) as appropriate |
| workflows | id, workspace_id, definition_ref, state | state/date index |
| workflow_runs | id, workflow_id, input_manifest, output_manifest, state | idempotency key unique |
| ontology_versions | id, scope, owner_domain, semantic_version, digest | unique ontology/version |
| products | id, owner_domain, builder_workspace_id, owner_id, active_release_id | slug unique per domain |
| product_releases | id, product_id, semver, manifest_digest, manifest_ref | unique (product_id, semver), immutable |
| publication_requests | id, product_id, release_id, state, requested_by | approvals ref |
| approvals | id, target_type, target_id, reviewer_id, decision, evidence | SoD constraints |
| policy_revisions | id, product_id, revision, signed_bundle_ref, state | unique product/revision |
| access_grants | id, subject_type, subject_id, product_id, actions, scope, expiry | active and revocation indexes |
| product_dependencies | downstream_release_id, upstream_release_id, mode, contract | composite PK |
| provenance_claims | id, asset_version_id, assertion_id, evidence_ref, method | index assertion/version |
| dq_runs | id, release_id, gate_id, evidence_ref, status | gate indexes |
| audit_events | id, actor, action, scope, decision, trace_id, ts | append only / retention |
| outbox | id, aggregate_type, aggregate_id, event_type, payload, created_at, delivered_at | undelivered index |
| inbox_dedupe | consumer, event_id, processed_at | composite PK |

## Example DDL (illustrative, migrations must complete)

```sql
CREATE TABLE workspaces (
  id uuid PRIMARY KEY,
  org_id uuid NOT NULL,
  owner_id uuid NOT NULL,
  state text NOT NULL CHECK (state IN ('PROVISIONING','ACTIVE','SUSPENDED','ARCHIVED','DELETING','DELETED','PROVISION_FAILED')),
  isolation_profile text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE assets (
  id uuid PRIMARY KEY,
  workspace_id uuid NOT NULL REFERENCES workspaces(id),
  kind text NOT NULL,
  classification text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets FORCE ROW LEVEL SECURITY;
CREATE POLICY assets_workspace_scope ON assets
  USING (workspace_id = nullif(current_setting('app.workspace_id',true),'')::uuid)
  WITH CHECK (workspace_id = nullif(current_setting('app.workspace_id',true),'')::uuid);
```

In production, run the app under a non-bypass-RLS DB role and set `app.workspace_id` in a database transaction after authorization. Connection pooling must reset tenant context; ensure service-level queries cannot override `app.workspace_id` without verified scope.

## Lineage model

`InputAssetVersion -> WorkflowRun -> OutputAssetVersion -> ProductRelease -> ConsumerProductRelease`. Include ontology version, ruleset/model/prompt, source license, classification labels and actor review actions. Avoid dependency cycles between immutable releases; introduce explicit permitted feedback workflows if needed. Graph lineage queries: impact(product version), origin(assertion), active_consumers(product), current/upstream stale versions.

## Event envelope

```json
{
  "event_id":"evt-uuid", "type":"km.product.release.activated.v1",
  "aggregate_type":"product", "aggregate_id":"kp-resilience",
  "occurred_at":"2026-11-17T12:00:00Z", "trace_id":"trace-xyz",
  "actor_id":"svc-publisher", "workspace_id":null,
  "schema_version":"1", "payload":{"release_id":"rel-1","policy_revision_id":"pr-3"}
}
```

Events: `workspace.provisioning_requested`, `workspace.active`, `workspace.suspended`, `domain.grant_approved`, `domain.grant_revoked`, `asset.version_registered`, `connector.sync_completed`, `workflow.run_completed`, `ontology.version_released`, `product.candidate_submitted`, `product.release_activated`, `policy.revision_activated`, `policy.emergency_deny`, `product.deprecated`, `product.retired`, `source.license_revoked`, `product.dependency_stale`. Keep events minimal—no sensitive source content in payloads.

## Delivery and failure semantics

Transaction writes business state + outbox event; publisher retries to Pub/Sub; consumer uses inbox dedupe keyed by event ID; events are at-least-once and may arrive out of order. Consumers must compare aggregate version and fetch authoritative current state. Maintain DLQ, manual replay, reconciliation of provisioned resources vs metadata, lineage reindex and catalog drift detection. Immutable audit retention is separate from event bus retention.

## Data retention and encryption

Classification-based retention, legal holds, TTL for temp data, storage lifecycle rules for unused artifact versions, per-tenant budgets and encryption. Keep backup/restore tests for PostgreSQL, GCS assets, graph snapshot rebuild and policy bundles. Logs must omit access tokens, secrets, raw restricted records and unredacted inference prompts unless specifically governed.
