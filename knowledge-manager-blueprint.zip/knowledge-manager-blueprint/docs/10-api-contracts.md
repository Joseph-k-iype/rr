# API contracts, REST conventions and concrete examples

## Rules

Prefix `/api/v1`. All protected requests require verified bearer credentials and a server-side resolved principal. `X-Workspace-ID` may select among caller-authorized memberships but never authorizes access. `Idempotency-Key` required on creates/long-running actions. `X-Request-ID` echoed and logged. Mutations use ETag/`If-Match` version where needed. All timestamps ISO 8601 UTC, UUID IDs. API errors use problem-details style payload. Never return storage credentials or physical URI as authorization substitute; signed upload URLs must be short-lived and narrowly scoped.

## Endpoints and capabilities

| Method and endpoint | Capability | Response |
|---|---|---|
| `POST /workspaces` | org.workspace.create | 202 provisioning operation |
| `GET /workspaces/{id}` | workspace.read | 200, status and logical quotas |
| `POST /workspaces/{id}/members` | workspace.members.manage | 201 |
| `POST /workspaces/{id}/domain-access-requests` | domain.access.request | 202 |
| `POST /workspaces/{id}/assets/uploads` | workspace.assets.write | 201 upload session |
| `POST /workspaces/{id}/connectors` | connector.manage | 201 |
| `POST /workspaces/{id}/connectors/{id}/sync` | connector.sync | 202 |
| `POST /workspaces/{id}/workflow-runs` | workflow.execute | 202 |
| `GET /workflow-runs/{id}` | workflow.read + membership | 200 |
| `POST /workspaces/{id}/products` | product.create | 201 |
| `POST /products/{id}/candidates` | product.release.propose | 202 |
| `POST /publication-requests/{id}/approvals` | publication.approve | 200/202 |
| `GET /catalog/products` | product.discover | filtered results |
| `GET /catalog/products/{id}` | product.read_metadata | filtered detail |
| `POST /products/{id}/access-requests` | product.request_access | 202 |
| `POST /products/{id}/policy-revisions` | policy.propose | 201 |
| `POST /policy-revisions/{id}/simulate` | policy.simulate | 200 matrix |
| `POST /policy-revisions/{id}/approvals` | policy.approve | 200 |
| `POST /policy-revisions/{id}/activate` | policy.activate | 202 |
| `POST /knowledge/query` | product.query | 200 result/provenance |
| `POST /knowledge/retrieve` | product.retrieve | 200 passages |
| `POST /knowledge/infer` | product.infer | 200 or 202 run |
| `POST /knowledge/derive-requests` | product.derive | 202 review/job |
| `POST /products/{id}/retirement-requests` | product.retire | 202 |

## Sample create workspace

```http
POST /api/v1/workspaces
Authorization: Bearer <token>
Idempotency-Key: 01-jkm-create
Content-Type: application/json

{"name":"Risk Analysis","description":"Controlled research","isolation_profile":"STANDARD","region":"asia-south1"}
```

```json
{"workspace_id":"81a408fb-ea18-4a32-b79e-13ae35f7922c","state":"PROVISIONING","operation_id":"op-01"}
```

## Domain access and product access

Domain request input: `{ "domain_id": "risk.operational", "capabilities": ["consume"], "purpose": "control-evidence", "expires_at": "2027-02-01T00:00:00Z" }`. Domain approval authorizes eligibility only.

Product request input: `{ "consumer_workspace_id": "ws-b", "actions": ["query"], "interfaces": ["graph-query"], "purpose": "control-evidence", "expires_at": "2027-01-15T00:00:00Z" }`. PDP must re-check grants at query time.

## Query request

```json
{
  "product_id":"kp-resilience", "release":"active",
  "consumer_workspace_id":"ws-b", "purpose":"control-evidence",
  "interface":"graph-query", "query_template_id":"get-service-dependencies",
  "parameters":{"service_id":"svc:29"}, "limit":50
}
```

Response: `request_id`, `decision_id`, `product_id`, exact `release_id`, `results[]` with authorized provenance, `warnings`, `next_cursor`, `execution_ms`. When denied use `403` and a non-revealing reason; when required attribute/PDP unavailable use `503` but fail-closed, no data. Filtered discovery may return `404` to avoid existence disclosure. Do not return exact classification or policy details to unauthorized callers.

## Error contract

```json
{
  "type":"https://docs.example.invalid/errors/policy-denied",
  "title":"Access denied", "status":403,
  "code":"POLICY_DENIED", "detail":"The requested operation is not permitted",
  "request_id":"req-789"
}
```

Error codes: `AUTH_REQUIRED`, `POLICY_DENIED`, `DOMAIN_GRANT_REQUIRED`, `PRODUCT_GRANT_REQUIRED`, `WORKSPACE_NOT_ACTIVE`, `ISOLATION_PROVISION_FAILED`, `VALIDATION_FAILED`, `DQ_GATE_FAILED`, `APPROVAL_REQUIRED`, `POLICY_ENGINE_UNAVAILABLE`, `RELEASE_NOT_READY`, `DEPENDENCY_RESTRICTED`, `RATE_LIMITED`, `CONFLICT`, `IDEMPOTENCY_CONFLICT`, `NOT_FOUND`, `INTERNAL_ERROR`.

## Async semantics

`202 Accepted` includes operation ID and status URL; `GET /operations/{id}` returns state, progress, error and links to produced resources. Job cancellation requires state-aware authorization and cancellation request; do not imply hard interruption of external source sync without adapter confirmation.

## Pagination and filtering

Cursor pagination with opaque signed cursor bound to actor, filter, product scope and policy revision; enforce max page size. Sorting must not permit unauthorized entity existence inference. Use typed request validators (Pydantic models) and generate OpenAPI from code; keep YAML contract synchronized.
