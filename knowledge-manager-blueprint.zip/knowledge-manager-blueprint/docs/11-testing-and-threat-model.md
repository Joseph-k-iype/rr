# Test strategy, threat model, release gates and operations

## Principal threats

1. Cross-workspace object read through broad bucket inheritance or crafted object key.
2. Cross-tenant SQL leakage due to missing RLS/incorrect pooled connection tenant context.
3. Graph or vector isolation failure through arbitrary query or missing pre-filter.
4. Confused-deputy authorization: workspace owner/worker uses permission from unrelated product/domain.
5. Policy escalation: builder publishes permissive rules or overrides mandatory domain denial.
6. Policy cache stale after revoke; approved grants retained longer than validity.
7. Data exfiltration through LLM prompts, logs, connector webhooks or downstream derived products.
8. Prompt injection in ingested docs and malicious ontology/rule artifacts.
9. Dependency poisoning or supply-chain changes in connectors/build images/workflow templates.
10. Publication serving partial release; deletion removes assets used by published product.
11. Sensitive metadata exposed by catalog, error messages, graph traversal or result counts.
12. Unbounded graph algorithms/LLM requests cause denial of service and cost amplification.

## Essential defenses

Short-lived workload identity, no broad bucket/project grants, allowlisted egress, content scanning, scoped resource resolver, typed query templates, independent PDP at every serving interface, fail-closed policy checks, immutable manifest hashes, signed/approved policy bundles, data-classification-aware logging and cache, bounded job quotas, separation of duties, audit and reconciliation.

## Test pyramid

| Level | Must cover | Environment |
|---|---|---|
| Unit | all domain models, state transitions, policy precedence, version compatibility | pytest |
| Property-based | path traversal, attribute combinations, policy conflict cases, IDs | Hypothesis |
| API contract | auth, validation, errors, idempotency, pagination, ETags | FastAPI test client |
| Integration | PostgreSQL RLS, outbox, workflow retries, graph/vector scoped queries | compose |
| Cloud IAM | real GCS managed folder inheritance/deny behavior, workload access | disposable GCP test project |
| E2E | complete author/publish/consume/refresh/revoke and workspace deletion | staging |
| Security | fuzz query, file upload, injection, SSRF, privilege escalation, egress | isolated test runners |
| Load/resilience | p95 latency, concurrent jobs, policy outage, broker duplicate events | staging |

## Required acceptance tests

```text
T01: ws-A cannot list/read ws-B objects, documents, graph, embeddings, workflow metadata.
T02: Owner of ws-A without domain grant cannot read classified domain source.
T03: Domain grant without product grant does not permit query.
T04: product.discover without product.query shows only approved catalog metadata.
T05: policy explicit deny overrides product-specific allow.
T06: builder cannot self-approve product policy if SoD condition applies.
T07: revoked grant denies subsequent queries and page continuation, despite cached allow.
T08: product release activation fails safely if policy bundle or serving binding unready.
T09: published product remains available after builder workspace deletion.
T10: materialized derived product records license, classification and upstream release.
T11: source license revocation blocks prohibited new use and flags known materializations.
T12: duplicate events do not create duplicate publications or grants.
T13: retrying ingest with same idempotency key returns same logical result.
T14: LLM-generated unsupported claim cannot pass certified quality gate.
T15: graph traversal and vector queries cannot reveal hidden entities via result/count/citation.
T16: role/scope changes immediately affect relevant product and workspace operations.
T17: previous active version remains stable if new version fails canary.
T18: expired domain/product grants fail regardless of cached session or JWT role.
T19: raw Cypher/SPARQL injection and object-key traversal are rejected.
T20: audit trail links principal, workflow, artifact versions, release and policy revision.
```

## Operational SLO proposals (validate with stakeholders)

- Control-plane API availability 99.9%; authorization PDP p95 under 100 ms at normal operating load.
- Basic catalog/search p95 under 750 ms; simple entity lookup p95 under 1.5 s at tested dataset scale.
- Revocation effective for newly initiated queries within 60 seconds under healthy control plane; emergency deny path faster as a stricter target. **Do not promise this SLO before load and failure testing.**
- Publication API acknowledgment under 2s; actual approval/promotion asynchronous.
- Source processing and inference batch jobs have per-template budgets and individual SLOs, not global latency guarantees.
- Backup RPO/RTO determined by business criticality; perform restore game days and cross-region/residency review.

## CI/CD gates

Formatting/static analysis/type checks, unit/contract tests, graph/vector negative tests, migration backward compatibility, SBOM/secret/dependency scan, IAM policy checks, tenant isolation tests, publish rollback test, signed image/policy artifact attestation and reviewer approval. Security issues are release blockers, not deferred UX tickets.

## Incident playbooks

Policy engine outage => deny data-serving operations where decision unavailable, alert on-call, preserve minimal health endpoint. Key compromise => rotate identity/secret, revoke grants/bundles, inspect audit, invalidate cache. Data misclassification => quarantine assets/releases, propagate restrictions to derived products, audit materialized copies. GCS resource drift => disable affected workspace execution until reconciliation verifies IAM. Product integrity mismatch => fail query and rollback serving binding.
