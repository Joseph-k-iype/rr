# Stepwise implementation plan for Codex or engineering team

## Engineering default stack

Monorepo: `apps/web` (React/Next.js + TypeScript), `apps/api` (FastAPI/Pydantic), `services/worker` (Python/Temporal), `packages/contracts` (generated OpenAPI client + JSON schemas), `packages/policy` (policy DSL/types + compiler), `infra/` (Terraform and Compose), `tests/`. PostgreSQL with RLS; pgvector; one graph adapter (choose RDF/Jena or Neo4j before M2); GCS via storage adapter; OPA or deterministic in-process PDP initially with same API contract; OIDC verification in API; OpenTelemetry. Prefer modest modular services until justified.

## M0 — Repository and development harness

**Stories:** bootstrap web/API/worker; typed config and env templates; docker compose; Postgres migrations; OIDC dev test issuer/mocked identity only in dev; lint/tests/CI; generated OpenAPI; trace IDs; ADR register.

**Acceptance:** `make dev`, `make test`, `make lint`, `make migrate` work from clean checkout; no hard-coded secrets; auth middleware denies absent token in non-test environment.

## M1 — Workspace MVP (first usable vertical slice)

**Stories:** domain and principal registry; workspace create/list/read/suspend; workspace memberships; resource binding resolver; GCS managed folder provisioner with mock and cloud adapter; PostgreSQL RLS; workspace admin UI; audit; provisioning saga and compensation.

**Acceptance:** T01/T02/T13, two real test workspaces and workload identities. `POST /workspaces` returns async operation; isolation tests pass against real cloud in integration project.

## M2 — Secure ingestion and semantic builder

**Stories:** uploads and source versions; connector SPI (start with file upload + one connector); source classification and immutable assets; workflow engine run/stop/status; extraction adapter, ontology registry/mappings, entity resolution review; graph adapter; inference rule and DQ evaluation; provenance evidence.

**Acceptance:** user uploads source, launches workflow, inspects candidate entity/edge evidence, and gets graph snapshot in own workspace. T04/T14/T19; enforce processing budgets and source grant.

## M3 — Product release, catalog and governance

**Stories:** product drafts and contract, candidate validation gates, owner/steward approvals, policy Studio DSL and simulation, RBAC/ABAC PDP + PEP, version registry and publication-owned bindings, catalog listing filtered by `discover`, release activation/rollback.

**Acceptance:** two different domains can publish restricted product versions; only specifically granted consumer can query. T03/T05/T06/T08/T17/T18.

## M4 — Secure knowledge serving and exchange

**Stories:** typed graph query/entity lookup/retrieval endpoints; provenance-aware response; query templates and obligations; consumer product access request; federated reference; governed derived request; audit/metering; policy revocation and cache invalidation.

**Acceptance:** complete workspace A publish -> workspace B request -> approved federated query; no direct cross-workspace storage access. T07/T10/T15.

## M5 — Continuous knowledge operations

**Stories:** product dependency graph, source refresh/rebuild, change impact, DQ recertification, product trust passport, subscription notifications, archive/retire, workspace deletion safety, cost attribution, dashboards and incident playbooks.

**Acceptance:** upstream update triggers impact report and controlled new release; builder workspace deletion preserves independent published assets; source rights withdrawal propagates restrictions. T09/T11/T12/T16/T20.

## M6 — Advanced features (optional)

Agent-facing inference tools with constrained scopes, ontology-driven product recommendations, federated semantic joins, policy copilot with review gate, knowledge graph of product dependencies, evaluation harness for statistical inference.

## Sprint tickets template

Every ticket includes: business user story; API contract; model/migration changes; authorization check and policy inputs; isolation/resource-binding impact; async failure/retry behavior; audit event; test cases; UX/operability; done criteria. Never implement endpoint without matching authorization and negative tests.

## Development workflow per milestone

1. Read docs and select milestone; list assumptions and tasks.
2. Create migration + typed model + API schema before UI.
3. Implement core business logic and resource resolver; add policy decision contract.
4. Add background workflow for long-running tasks; compensations.
5. Write unit and tenant-negative tests and run locally.
6. Update OpenAPI/examples/ADR and README.
7. Demonstrate E2E user journey with reproducible commands and evidence.
8. Stop for architectural review before introducing a new infrastructure dependency.

## Definition of done

Runnable testable code, generated API docs, migrations and rollback plan, telemetry, meaningful tests including forbidden cases, no secret leakage, resource quotas, audit, documented assumptions, and a local demo. Architecture docs are **design specifications**, not proof that the system or its tests already exist.
