# Architecture decision records (proposed)

## ADR-001: Workspace is isolation unit

Decision: each workspace has server-managed resource bindings and workload identity. Standard tier uses managed folder and logical namespace; sensitive tiers may use dedicated resources. Rationale: economical tenancy with optional stronger separation. Risks: IAM inheritance, shared database isolation. Mitigation: real cloud negative tests, RLS, scoped query gateways, separate egress and workloads. Status: proposed.

## ADR-002: Logical filesystem not direct GCS paths

Decision: users see `/workspace/...`; resolver maps typed asset IDs to GCS objects. Rationale: storage portability and prevention of path-based privilege escalation. Alternative: expose raw bucket keys (rejected). Status: proposed.

## ADR-003: Immutable release, independent policy revision

Decision: product identity stable; release manifest immutable; policy revision independently activated/revoked; active release points to stable publication-owned serving binding. Rationale: emergency revocation and independent product lifecycle. Alternative: all metadata in single mutable product (rejected). Status: proposed.

## ADR-004: RBAC + ABAC + delegated authorship

Decision: enterprise/domain mandatory restrictions; product owner/builder rules only within delegation; explicit deny wins; missing attributes fail closed. Use policy administration + PDP/PEP. Rationale: business-owned governance without unrestricted builder power. Risks: complex policy conflicts/bundle lag. Mitigation: typed DSL, simulation, signed revisions, authoritative revocation check. Status: proposed.

## ADR-005: Federated consumption by default

Decision: use published interfaces first; materialization requires explicit rights. Rationale: source authority, less duplication, easier revocation. Tradeoff: source uptime/latency and dependent service coupling. Status: proposed.

## ADR-006: Modular monolith control plane with durable workers

Decision: initially FastAPI modular services/Postgres/Temporal or equivalent with outbox; independently scale heavy pipelines and serving. Rationale: operational simplicity and cohesive transactions. Alternative: immediate dozens of microservices (deferred). Status: proposed.

## ADR-007: One primary graph implementation for MVP

Decision: choose RDF/SHACL stack if semantic standards/ontology reasoning central; choose Neo4j property graph if traversal and application ergonomics central. Provide adapter boundary; do not pretend complete equivalence. Status: open (must decide before M2).

## ADR-008: Catalog projection is not authority

Decision: registry + PDP are source of truth; catalog is metadata/read projection. Rationale: eventual consistency and metadata leakage risks. Status: proposed.

## ADR-009: Source provenance as immutable evidence

Decision: every derived claim records supporting source record/span, producer run, rule/model and version. Rationale: audit, quality and explainability. Privacy risk: evidence itself may be restricted. Mitigation: provenance references access-controlled. Status: proposed.

## ADR-010: Build-to-serve promotion boundary

Decision: published product survives private workspace deletion by owning stable serving bindings or managed source contracts. Rationale: enterprise continuity. Status: proposed.

## ADR-011: ABAC/graph granularity

Decision needed: which labels and edge/attribute filters are enforceable by chosen graph backend? Prototype edge-level access in representative data before claiming fine-grained support. Fallback: physically partition by classification and serving view. Status: open (blocks confidential graph serving).

## ADR-012: Region, retention and data residency

Decision needed: deployment region(s), backup region, cross-region copies, sensitive data policies, legal holds, KMS options, audit retention and use of external AI services. Obtain security/legal owner signoff. Status: open (blocks production deployment).

## ADR-013: Product owner vs domain owner authority

Decision needed: which delegated actions are permitted per role for each classification, and exact approval quorum/SoD? Default: builders propose, product owners approve non-sensitive product rules, domain owner approves mandatory restrictions/cross-domain exposure, stewards approve certification; security review for highly sensitive assets. Status: open for enterprise policy review.
