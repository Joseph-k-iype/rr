# UX, navigation and detailed product journeys

## Navigation

Global: Organization switcher; Workspaces; Catalog; Access Requests; Domain Governance (authorized roles); Policies; Audit/Operations. Workspace: Overview, Members, Domains, Sources, Connectors, Assets, Ontologies, Graph Explorer, Inference, Workflows, Draft Products, Quality, Activity and Settings. Product: Overview, Versions, Contract, Interfaces, Trust Passport, Provenance, Dependencies, Policies, Entitlements, Analytics, Incidents, Retirement.

## Workspace creation wizard

Inputs name, owner/team, optional domain affiliation, isolation profile, region and quotas. Clear warning that selecting a domain does not grant access to it. Show provisioning progress by step (identity/storage/graph/vector/policy verification) and remediation on partial fail. Never expose cloud credentials.

## Domain access request

Select domain/subdomain tree; show classification/use restrictions; request `discover|consume|derive|propose_publish`, business purpose, desired expiry; submit; track approver, expiry and status. Once granted, show explicitly which product grants are still needed. Avoid a single misleading green 'access to domain' badge that implies unrestricted data visibility.

## Source and build canvas

Source browser with upload and connector creation. Asset detail shows version history, classification, provenance, extraction status. Workflow canvas supports source input -> extraction -> entity resolution -> ontology mapping -> graph build -> inference -> DQ. Each node shows pinned version, inputs/outputs, errors, duration, and cost. Human review queue shows disputed claims with authorized evidence.

## Knowledge product draft

Builder selects graph/vector/assets, ontology and ruleset versions, sets business purpose, data contracts and allowed interfaces. Product preview can run authenticated canary queries within workspace. Show version pinning and upstream source rights warnings prominently.

## Policy Studio

Tabbed RBAC matrix, ABAC condition builder, business rule templates, policy authorship/delegation, obligations, test matrix, before/after simulation, impact report, approvals and activated revisions. Role selector must communicate whose permission the current user is exercising; disable controls for unauthorized policy changes. Distinguish **drafted**, **approved**, **activated**, and **deployed to gateway** statuses.

## Publishing wizard

Stages: candidate package -> automated validation -> policy simulation -> reviewers -> serving readiness -> release activation. Each gate has pass/fail reason and link to evidence. Show any pending approval, prevent self-approval when SoD applies, show rollback action with audit. Do not expose product as active until registry + policy + serving pass.

## Catalog and product detail

Catalog search by domain, concepts, interface, trust status and classification metadata permitted for the viewer. Cards show owner, release, freshness, certification, available interfaces and access status. Detail includes documentation, contracts, lineage and `Request access`. If user can discover but not consume, show access workflow, not a clickable graph query.

## Consumption and knowledge explorer

Query templates, entity lookup, graph traversal if allowed, hybrid search and inference with evidence/citations. Display exact product/release, data provenance, provisional vs deterministic claims, confidence and authorization-safe redactions. Export/download appears only with separate `export` grant; do not rely on hidden UI for actual security.

## Operations cockpit

Product ownership dashboard: freshness breaches, connector failures, stale dependencies, pending recertification, cost anomalies, expiring grants and access denial trends. On incident, authorized operator can quarantine release, trigger emergency deny, notify consumers and initiate remediation. Show history and affected downstream releases.

## Primary journeys

- Builder: create workspace -> domain request -> upload -> workflow -> graph explorer -> product candidate -> gate corrections -> submit.
- Domain Owner: review request -> delegate policy authority -> inspect policy simulation -> approve publication -> review periodic exceptions.
- Steward: inspect DQ and ontology diff -> review evidence -> certify/downgrade -> recertify on change.
- Consumer: discover product -> request entitlement -> query authorized interface -> inspect provenance -> subscribe to changes.
- Operator: investigate source failure -> see dependency impact -> prevent bad publication -> restore/publish safe release.

## Accessibility and privacy

Keyboard navigability, meaningful status labels, table filtering, accessible errors, WCAG-aligned contrast and audit trails. Unauthorized user must not see restricted product title, source URI, owner email or sensitive statistic merely because the catalog index contains them.
